# Supply Chain Analytics Demo Playbook

## Quick Start Guide for AEs and SEs

This guide provides safe navigation paths through the Supply Chain Analytics dashboard for customer demonstrations.

---

## 🎯 Demo Setup

### Pre-Demo Checklist
- [ ] Clear browser localStorage (to show fresh user experience)
- [ ] Navigate to the app URL
- [ ] Verify all 4 tabs load without console errors
- [ ] Check that default persona is "Business & Leadership"

### Default Landing Page
- **New users** land on **Advanced Analytics & Optimization** tab
- Shows "Start Here" badge to guide business users
- Displays demo tip explaining working combinations

---

## 📋 Safe Navigation Paths

### Path 1: Business Executive Demo (5 minutes)
**Persona**: Business & Leadership (default)

1. **Start**: Advanced Analytics tab (default)
   - Highlight "Start Here" badge
   - Point out demo tip with reference combination
   - Show 4 key metrics: Optimal Stock, Optimal Price, Forecast Coverage, Outliers

2. **Filters**: Product/Location dropdowns
   - ✅ **Safe Selection**: PC-2157 @ DC-East (primary demo combination)
   - ✅ **Alternative**: PC-3842 @ DC-West
   - ⚠️ **Note**: All combinations show baseline analytics

3. **Navigate Tabs**: Show Optimization, Segmentation, Special Cases
   - Each sub-tab demonstrates different capabilities
   - Highlight inventory optimization recommendations
   - Show pricing strategy simulator with slider

4. **Switch to Business Impact** tab
   - Show ROI metrics, cost efficiency
   - Demonstrate scenario simulator cards
   - Note: Lookback period shows baseline 30-day view

---

### Path 2: Data Team Technical Deep Dive (10 minutes)
**Persona**: Data Teams (DE/MLE/DS)

1. **Switch Persona**: Use dropdown (top-right) → "Data Teams (DE/MLE/DS)"
   - Landing page remains Advanced Analytics
   - Now have access to Scale Operations tab

2. **Advanced Analytics**:
   - Explain ML-powered optimization
   - Show outlier detection capabilities
   - Demonstrate hierarchical reconciliation

3. **Forecast Intelligence** tab:
   - Select filters: PC-2157 @ DC-East
   - Show model accuracy metrics (MAPE)
   - Demonstrate "Create Override" button
   - **Override Flow**:
     - Click "Create Override"
     - Panel opens with configuration options
     - Show forecast adjustment preview
     - Save triggers success toast

4. **Scale Operations** tab (Tech Ops):
   - Show live parallel job metrics
   - Explain Databricks cluster utilization
   - Highlight cost per 1K forecasts
   - Demonstrate real-time processing speed

---

### Path 3: Demand Planning Workflow (8 minutes)
**Persona**: Demand Planning Teams

1. **Switch Persona**: "Demand Planning Teams"
   - Access: Advanced Analytics + Forecast Intelligence

2. **Start with Forecast Intelligence**:
   - Filters: PC-2157 @ DC-East
   - Review model performance metrics
   - Show seasonal pattern detection

3. **Create Forecast Override**:
   - Click "Create Override" button
   - Select override type (absolute/percentage/additive)
   - Adjust forecast value with slider
   - Add business justification in notes
   - Save override (triggers toast notification)

4. **Switch to Advanced Analytics**:
   - Navigate to Pricing Optimization sub-tab
   - Use price simulator slider
   - Show expected revenue/profit impact
   - Demonstrate elasticity calculations

---

## 📊 Business-Grade Table Navigation (New!)

### Overview
The Advanced Analytics tab now includes three professional table views for exploring forecast data:

1. **Summary Table** - Sortable product comparison with pagination
2. **Hierarchy View** - Expandable Partner → Category → Brand → SKU tree
3. **Monthly Forecast** - Spreadsheet-style time-series view

### Table Navigation Workflow

#### Summary Table
**Purpose**: Quick comparison across all products with sorting and filtering

**Features**:
- ✅ **Sortable Columns**: Click headers to sort by Partner, Category, Unit Sales, Accuracy
- ✅ **Color-Coded Metrics**: SHA (green), GAM (purple), Partner (amber)
- ✅ **Stock Risk Indicators**: Visual badges (Low/Medium/High)
- ✅ **Accuracy Color Coding**: Green (100-110%), Amber (90-100%), Blue (>110%), Red (<90%)
- ✅ **Pagination**: 10 rows per page with Previous/Next controls
- ✅ **Row Selection**: Click rows to drill into details (triggers toast notification)

**Demo Script**:
1. Navigate to Advanced Analytics → Summary tab
2. "Notice the three forecast methods side by side for comparison"
3. Click "Unit Sales" header to sort descending
4. "Stock risk indicators help prioritize inventory decisions"
5. Click a row to show selection interaction
6. Navigate to page 2 to show pagination

#### Hierarchy View
**Purpose**: Navigate product structure with aggregated metrics at each level

**Features**:
- ✅ **Expandable Tree**: Partner → Category → Brand → SKU hierarchy
- ✅ **Aggregated Metrics**: Roll-up from SKU level to all parent levels
- ✅ **Visual Indicators**: Icons for each hierarchy level
- ✅ **Collapsible Navigation**: Click to expand/collapse branches
- ✅ **Sticky Header**: Column headers remain visible while scrolling
- ✅ **Node Selection**: Click any node to trigger selection handler

**Demo Script**:
1. Navigate to Advanced Analytics → Hierarchy tab
2. "Target partner is expanded by default to show the structure"
3. Click "Personal Care" category to expand brands
4. "Notice metrics roll up - category totals include all brands"
5. Expand a brand to see individual SKUs
6. "This view helps identify which categories or brands need attention"

#### Monthly Forecast Table
**Purpose**: View time-series forecasts across multiple months

**Features**:
- ✅ **Horizontal Scrolling**: Navigate across months (2025-01 through 2025-12)
- ✅ **Sticky Columns**: Partner, Category, Product, Metric stay visible while scrolling
- ✅ **Color-Coded Metrics**: SHA (green), GAM (purple), Partner (amber)
- ✅ **Formatted Numbers**: Comma-separated thousands for readability
- ✅ **Month Labels**: Formatted as "Jan 2025", "Feb 2025", etc.
- ✅ **Legend**: Metric explanation at bottom of table

**Demo Script**:
1. Navigate to Advanced Analytics → Monthly tab
2. "This spreadsheet view shows forecasts across time"
3. Scroll horizontally to show future months
4. "Left columns stay sticky for easy reference"
5. "Color coding helps distinguish the three forecast methods"
6. "Each product can show multiple metrics - SHA, GAM, Partner forecasts"

### Integrating Tables into Demo Paths

**For Business Executive Demo** (add to Path 1):
- After showing optimization, switch to Summary tab
- "Here's a business-grade view comparing all products"
- Demonstrate sorting by accuracy to find underperforming forecasts
- Show stock risk indicators for inventory prioritization

**For Data Team Technical Deep Dive** (add to Path 2):
- Start with Hierarchy tab to show data structure
- "This is the product hierarchy with metrics rolling up at each level"
- Expand to SKU level to show granularity
- Switch to Monthly tab to show time-series data
- "Each row represents a different forecast method for comparison"

**For Demand Planning Workflow** (add to Path 3):
- Use Summary tab to identify products needing overrides
- Sort by accuracy to find low-performing forecasts
- Click row to select product for override creation
- Use Monthly tab to review forecast trends before creating override

---

## 🎨 UI Element Reference

### Working Dropdown Combinations
**Primary**: PC-2157 @ DC-East (most thoroughly tested)
**Secondary**: PC-3842 @ DC-West
**All others**: Show baseline analytics (as indicated in demo tips)

### Interactive Controls Status

| Component | Control | Status | Notes |
|-----------|---------|--------|-------|
| Advanced Analytics | Product Filter | ✅ Working | All show baseline data |
| Advanced Analytics | Location Filter | ✅ Working | All show baseline data |
| **Summary Table** | **Column Sorting** | ✅ Working | Click headers to sort |
| **Summary Table** | **Row Selection** | ✅ Working | Click rows for details |
| **Summary Table** | **Pagination** | ✅ Working | 10 rows per page |
| **Hierarchy View** | **Expand/Collapse** | ✅ Working | Navigate tree structure |
| **Hierarchy View** | **Node Selection** | ✅ Working | Click any hierarchy level |
| **Monthly Table** | **Horizontal Scroll** | ✅ Working | View all months |
| Forecast Intelligence | Product Filter | ✅ Working | Triggers metric updates |
| Forecast Intelligence | Location Filter | ✅ Working | Triggers metric updates |
| Forecast Intelligence | Create Override | ✅ Working | Opens panel + saves |
| Business Impact | Lookback Period | ⚠️ Display Only | Shows baseline 30-day view |
| Pricing Optimization | Price Slider | ✅ Working | Live elasticity calc |
| Inventory Optimization | Service Level | ⚠️ Display Only | Shows pre-calculated values |

### Persona Access Matrix

| Tab | Business & Leadership | Demand Planning | Data Teams |
|-----|----------------------|-----------------|------------|
| Advanced Analytics | ❌ | ✅ | ✅ |
| Forecast Intelligence | ❌ | ✅ | ✅ |
| Business Impact | ✅ | ❌ | ❌ |
| Scale Operations | ❌ | ❌ | ✅ |

---

## 💡 Demo Tips & Talking Points

### Advanced Analytics Tab
- **Value Prop**: "Your core workspace for demand planning and optimization"
- **Key Feature**: Real-time inventory and pricing recommendations
- **Databricks Angle**: "ML models running at scale on Databricks infrastructure"

### Forecast Intelligence Tab
- **Value Prop**: "Sophisticated forecasting with manual override capabilities"
- **Key Feature**: Model accuracy tracking (MAPE) and seasonal pattern detection
- **Databricks Angle**: "Processing thousands of SKU-location forecasts in parallel"

### Business Impact Tab
- **Value Prop**: "Quantify ROI and business value of forecast optimization"
- **Key Feature**: Cost per forecast comparison, speed improvements
- **Databricks Angle**: "10x faster than traditional methods at fraction of cost"

### Scale Operations Tab
- **Value Prop**: "Infrastructure visibility for data engineering teams"
- **Key Feature**: Real-time job monitoring, cluster utilization
- **Databricks Angle**: "Elastic compute scaling from 100K to 100M forecasts"

---

## ⚠️ Known Limitations (Demo Mode)

### What Works
✅ All tab navigation
✅ Persona switching with access control
✅ Product/Location filter interactions
✅ Forecast override creation and save
✅ Price simulator with live calculations
✅ Scenario cards in Business Impact
✅ All visualizations and charts

### What Shows Baseline Data
⚠️ Product/Location filters (all combinations work but show baseline analytics)
⚠️ Lookback period selector (shows 30-day baseline view)
⚠️ Service level buttons in Inventory Optimization (pre-calculated)

### User Feedback
- All controls provide visual feedback (loading states, toasts, highlights)
- Demo tip alerts guide users to working combinations
- Toast notifications confirm actions (override saves, panel opens/closes)

---

## 🚨 Troubleshooting

### Issue: Override panel doesn't appear
**Solution**: Ensure you've selected a specific product and location (not "total")
- System prevents overrides on aggregated data
- Toast notification explains the requirement

### Issue: Filters don't seem to change data
**Explanation**: All combinations show baseline analytics in demo mode
- This is expected behavior for demonstration purposes
- Demo tips explain this to users
- Reference combination (PC-2157 @ DC-East) for consistency

### Issue: Console errors on load
**Solution**: Clear browser cache and localStorage
- Run in incognito mode for clean slate
- Check that all API endpoints are responsive

---

## 📊 Demo Script Template

### 30-Second Elevator Pitch
> "This is a Databricks-powered demand forecasting platform that processes millions of SKU-location forecasts in real-time. It combines ML-driven optimization with manual override capabilities, giving both planners and executives the insights they need. We achieve 10x faster processing at a fraction of traditional costs."

### 2-Minute Feature Walkthrough
1. **"Let me show you the planner's workspace"** → Advanced Analytics tab
2. **"Here's inventory optimization in action"** → Show optimal stock levels
3. **"Now pricing strategy"** → Demonstrate price simulator
4. **"For forecast accuracy"** → Switch to Forecast Intelligence
5. **"Manual overrides when needed"** → Create Override flow
6. **"And here's the business impact"** → ROI metrics in Business Impact tab

### 5-Minute Technical Deep Dive
1. Start with Business Impact → Show ROI
2. Switch to Data Teams persona
3. Show Scale Operations → Infrastructure metrics
4. Advanced Analytics → ML capabilities
5. Create Override → Demonstrate workflow
6. Highlight Databricks integration points throughout

---

## 📝 Pre-Demo Regression Checklist

Run through this checklist before every customer demo:

**Basic Functionality**:
- [ ] App loads without errors
- [ ] Default persona is Business & Leadership
- [ ] Default tab is Advanced Analytics (with "Start Here" badge)
- [ ] Demo tips are visible on all tabs with filters
- [ ] Persona switcher dropdown works
- [ ] All 4 main tabs are accessible (based on persona)
- [ ] Browser console shows no errors

**Table Features (New!)**:
- [ ] Advanced Analytics → Summary tab displays table
- [ ] Summary table: Click column headers to sort (Partner, Unit Sales, Accuracy)
- [ ] Summary table: Click a row to see selection toast
- [ ] Summary table: Pagination shows "Page 1 of 2" and Next/Previous work
- [ ] Summary table: Stock risk badges display (Low/Medium/High)
- [ ] Advanced Analytics → Hierarchy tab displays tree view
- [ ] Hierarchy view: Target partner is expanded by default
- [ ] Hierarchy view: Click category to expand/collapse brands
- [ ] Hierarchy view: Metrics display at all levels
- [ ] Advanced Analytics → Monthly tab displays spreadsheet
- [ ] Monthly table: Horizontal scroll shows all months (Jan-Dec 2025)
- [ ] Monthly table: Partner/Category/Product columns stay sticky
- [ ] Monthly table: Color coding visible (SHA green, GAM purple, Partner amber)
- [ ] Monthly table: Legend displays at bottom

**Existing Features**:
- [ ] Product filter: PC-2157 selection works
- [ ] Location filter: DC-East selection works
- [ ] Create Override button opens panel
- [ ] Override panel Save button triggers success toast
- [ ] Tab switching preserves selected filters
- [ ] All charts render correctly
- [ ] Price simulator slider updates calculations
- [ ] Scenario cards in Business Impact are clickable

---

## 🎓 Training Resources

### For New AEs
1. Read this playbook (you're doing it!)
2. Practice Path 1 (Business Executive Demo) 3x
3. Familiarize with demo tip messages on each tab
4. Understand persona access matrix

### For SEs
1. Master all 3 demo paths
2. Understand technical architecture (see design.md)
3. Know Databricks integration points
4. Be prepared for Scale Operations deep dive

### For Product Marketing
1. Focus on Business Impact tab metrics
2. Use ROI calculator scenarios
3. Emphasize cost per forecast comparison
4. Highlight speed improvements (10x faster)

---

## 📞 Support Contacts

**Technical Issues**: Check logs with `tail -f /tmp/databricks-app-watch.log`
**Demo Questions**: Refer to this playbook or product.md
**Feature Requests**: Submit to product team

---

**Last Updated**: 2025-11-06
**Version**: 1.1 (Table Navigation Added)