#!/usr/bin/env python3
"""
Setup script to create and populate supply chain tables in Databricks.
Uses the test_data_generation.sql file to create Paula's Choice supply chain data.
"""

import os
import sys
from pathlib import Path
from databricks.sdk import WorkspaceClient
from databricks.sdk.core import DatabricksError


def get_databricks_client():
    """Initialize and return a Databricks client using PAT authentication."""
    host = os.getenv('DATABRICKS_HOST')
    token = os.getenv('DATABRICKS_TOKEN')
    
    if not host or not token:
        raise Exception(f"Missing Databricks credentials. HOST: {'SET' if host else 'MISSING'}, TOKEN: {'SET' if token else 'MISSING'}")
    
    return WorkspaceClient(host=host, token=token)


def execute_sql_script(client, script_content, warehouse_id):
    """Execute a SQL script by splitting it into individual statements."""
    print(f"🚀 Executing SQL script with warehouse: {warehouse_id}")
    
    # Split the script into individual statements
    statements = []
    current_statement = []
    
    for line in script_content.split('\n'):
        # Skip comments and empty lines
        stripped_line = line.strip()
        if not stripped_line or stripped_line.startswith('--'):
            continue
            
        current_statement.append(line)
        
        # If line ends with semicolon, it's the end of a statement
        if stripped_line.endswith(';'):
            statement = '\n'.join(current_statement).strip()
            if statement:
                statements.append(statement)
            current_statement = []
    
    # Add any remaining statement
    if current_statement:
        statement = '\n'.join(current_statement).strip()
        if statement:
            statements.append(statement)
    
    print(f"📊 Found {len(statements)} SQL statements to execute")
    
    successful = 0
    failed = 0
    
    for i, statement in enumerate(statements, 1):
        try:
            print(f"🔄 Executing statement {i}/{len(statements)}...")
            
            # Show first line of statement for context
            first_line = statement.split('\n')[0][:100]
            print(f"📝 Statement preview: {first_line}...")
            
            response = client.statement_execution.execute_statement(
                warehouse_id=warehouse_id,
                statement=statement,
                wait_timeout='50s'  # Maximum allowed timeout
            )
            
            if hasattr(response, 'status') and response.status:
                if str(response.status.state) == 'StatementState.SUCCEEDED':
                    print(f"✅ Statement {i} completed successfully")
                    successful += 1
                else:
                    print(f"❌ Statement {i} failed with status: {response.status.state}")
                    failed += 1
            else:
                print(f"✅ Statement {i} completed (no status returned)")
                successful += 1
                
        except DatabricksError as e:
            print(f"❌ Databricks error on statement {i}: {e}")
            failed += 1
            
            # If it's a table already exists error, that's OK
            if "already exists" in str(e).lower():
                print(f"ℹ️ Table already exists - continuing...")
                successful += 1
                failed -= 1
        except Exception as e:
            print(f"❌ Error executing statement {i}: {e}")
            failed += 1
    
    print(f"\n🏆 Execution Summary:")
    print(f"✅ Successful: {successful}")
    print(f"❌ Failed: {failed}")
    print(f"📊 Total: {len(statements)}")
    
    return successful, failed


def main():
    """Main function to setup supply chain database."""
    try:
        print("🚀 Starting Supply Chain Database Setup")
        print("=" * 50)
        
        # Get the SQL script path
        script_dir = Path(__file__).parent.parent
        sql_script_path = script_dir / "test_data_generation.sql"
        
        if not sql_script_path.exists():
            raise Exception(f"SQL script not found: {sql_script_path}")
        
        print(f"📄 Loading SQL script: {sql_script_path}")
        
        # Read the SQL script
        with open(sql_script_path, 'r') as f:
            script_content = f.read()
        
        print(f"📊 Script size: {len(script_content)} characters")
        
        # Initialize Databricks client
        print("🔌 Connecting to Databricks...")
        client = get_databricks_client()
        
        # Get warehouse ID
        warehouse_id = os.getenv('SQL_WAREHOUSE_ID', '8baced1ff014912d')
        print(f"🏭 Using warehouse: {warehouse_id}")
        
        # Check warehouse status
        try:
            warehouse_info = client.warehouses.get(warehouse_id)
            print(f"🏭 Warehouse state: {warehouse_info.state}")
            
            if warehouse_info.state != 'RUNNING':
                print(f"⚠️ Warehouse is not running. Current state: {warehouse_info.state}")
                print("ℹ️ You may need to start the warehouse manually in the Databricks UI")
        except Exception as e:
            print(f"⚠️ Could not check warehouse status: {e}")
        
        # Execute the SQL script
        print("\n🎯 Executing SQL script...")
        successful, failed = execute_sql_script(client, script_content, warehouse_id)
        
        if failed == 0:
            print("\n🎉 Supply chain database setup completed successfully!")
            print("✅ All tables created and populated with Paula's Choice data")
        else:
            print(f"\n⚠️ Setup completed with {failed} failures")
            print("ℹ️ Some failures may be expected (e.g., tables already exist)")
        
        # Verify the setup by checking a few key tables
        print("\n🔍 Verifying setup...")
        verify_tables = [
            'retail_demand_forecasting.supply_chain.products',
            'retail_demand_forecasting.supply_chain.locations',
            'retail_demand_forecasting.supply_chain.inventory_levels',
            'retail_demand_forecasting.supply_chain.sales'
        ]
        
        for table_name in verify_tables:
            try:
                response = client.statement_execution.execute_statement(
                    warehouse_id=warehouse_id,
                    statement=f"SELECT COUNT(*) as count FROM {table_name}",
                    wait_timeout='30s'
                )
                
                if response.result and response.result.data_array:
                    count = response.result.data_array[0][0]
                    print(f"✅ {table_name}: {count} rows")
                else:
                    print(f"❌ {table_name}: No data returned")
            except Exception as e:
                print(f"❌ {table_name}: Error checking - {e}")
        
        print("\n🎯 Next Steps:")
        print("1. Backend services can now connect to retail_demand_forecasting.supply_chain schema")
        print("2. Run the application to test the new supply chain dashboard")
        print("3. Check logs for any connection issues")
        
    except Exception as e:
        print(f"❌ Setup failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()