#!/usr/bin/env python3
"""
Verification script to check supply chain tables in Databricks.
"""

import os
from databricks.sdk import WorkspaceClient


def main():
    """Verify the supply chain database setup."""
    try:
        # Initialize client
        host = os.getenv('DATABRICKS_HOST')
        token = os.getenv('DATABRICKS_TOKEN')
        warehouse_id = os.getenv('SQL_WAREHOUSE_ID', '8baced1ff014912d')
        
        if not host or not token:
            print("❌ Missing Databricks credentials")
            return
            
        client = WorkspaceClient(host=host, token=token)
        print(f"✅ Connected to {host}")
        
        # List tables in the supply_chain schema
        print("\n🔍 Checking supply_chain schema...")
        
        try:
            response = client.statement_execution.execute_statement(
                warehouse_id=warehouse_id,
                statement="SHOW TABLES IN retail_demand_forecasting.supply_chain",
                wait_timeout='30s'
            )
            
            if response.result and response.result.data_array:
                print(f"📊 Found {len(response.result.data_array)} tables:")
                for row in response.result.data_array:
                    table_name = row[1]  # table name is typically in the second column
                    print(f"  - {table_name}")
                    
                    # Check row count for each table
                    try:
                        count_response = client.statement_execution.execute_statement(
                            warehouse_id=warehouse_id,
                            statement=f"SELECT COUNT(*) FROM retail_demand_forecasting.supply_chain.{table_name}",
                            wait_timeout='30s'
                        )
                        
                        if count_response.result and count_response.result.data_array:
                            count = count_response.result.data_array[0][0]
                            print(f"    📈 {count} rows")
                        else:
                            print("    ❌ Could not get count")
                    except Exception as e:
                        print(f"    ❌ Error getting count: {e}")
            else:
                print("❌ No tables found or no data returned")
                
        except Exception as e:
            print(f"❌ Error listing tables: {e}")
        
        # Test a few key queries that the dashboard will use
        print("\n🧪 Testing key queries...")
        
        test_queries = [
            ("Products count", "SELECT COUNT(*) FROM retail_demand_forecasting.supply_chain.products"),
            ("Suppliers count", "SELECT COUNT(*) FROM retail_demand_forecasting.supply_chain.suppliers"),  
            ("Locations count", "SELECT COUNT(*) FROM retail_demand_forecasting.supply_chain.locations"),
            ("Sales sample", "SELECT COUNT(*) FROM retail_demand_forecasting.supply_chain.sales LIMIT 5"),
        ]
        
        for name, query in test_queries:
            try:
                response = client.statement_execution.execute_statement(
                    warehouse_id=warehouse_id,
                    statement=query,
                    wait_timeout='30s'
                )
                
                if response.result and response.result.data_array:
                    result = response.result.data_array[0][0]
                    print(f"✅ {name}: {result}")
                else:
                    print(f"❌ {name}: No data")
            except Exception as e:
                print(f"❌ {name}: {e}")
    
    except Exception as e:
        print(f"❌ Verification failed: {e}")


if __name__ == "__main__":
    main()