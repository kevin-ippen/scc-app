"""FastAPI application for Databricks App Template."""

import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from server.routers import router
from server.routers.supply_chain import router as supply_chain_router


# Load environment variables from .env.local if it exists
def load_env_file(filepath: str) -> None:
  """Load environment variables from a file."""
  if Path(filepath).exists():
    with open(filepath) as f:
      for line in f:
        line = line.strip()
        if line and not line.startswith('#'):
          key, _, value = line.partition('=')
          if key and value:
            os.environ[key] = value


# Load .env files
load_env_file('.env')
load_env_file('.env.local')


@asynccontextmanager
async def lifespan(app: FastAPI):
  """Manage application lifespan."""
  yield


app = FastAPI(
  title='Databricks App API',
  description='Modern FastAPI application template for Databricks Apps with React frontend',
  version='0.1.0',
  lifespan=lifespan,
)

app.add_middleware(
  CORSMiddleware,
  allow_origins=['http://localhost:3000', 'http://127.0.0.1:3000'],
  allow_credentials=True,
  allow_methods=['*'],
  allow_headers=['*'],
)

app.include_router(router, prefix='/api', tags=['api'])
app.include_router(supply_chain_router)


@app.get('/health')
async def health():
  """Health check endpoint."""
  return {'status': 'healthy'}


# ============================================================================
# SERVE STATIC FILES FROM CLIENT BUILD DIRECTORY (MUST BE LAST!)
# ============================================================================
# This static file mount MUST be the last route registered!
# It catches all unmatched requests and serves the React app.
# Any routes added after this will be unreachable!

# Try multiple possible paths for the build directory (including Databricks Apps structure)
build_paths = [
    'client/build',
    'python/source_code/client/build',
    'source_code/client/build', 
    './client/build',
    '../client/build',
    '../../client/build',
    'build',
]
static_mounted = False

print('🔍 DEBUGGING STATIC FILE SERVING:')
print(f'📂 Current working directory: {os.getcwd()}')
print('📁 Files in current directory:', os.listdir('.') if os.path.exists('.') else 'None')

# Check for any directory that contains build (excluding package directories)
def find_build_directories(start_path='.'):
  found_builds = []
  excluded_paths = ['.venv', 'venv', 'env', 'node_modules', '__pycache__', '.git', 'site-packages']
  try:
    for root, dirs, files in os.walk(start_path):
      # Skip excluded directories
      dirs[:] = [d for d in dirs if not any(excluded in os.path.join(root, d) for excluded in excluded_paths)]
      
      if 'build' in dirs:
        build_path = os.path.join(root, 'build')
        if os.path.exists(os.path.join(build_path, 'index.html')):
          # Prioritize client/build over others
          if build_path.endswith('client/build') or build_path.endswith('client\\build'):
            found_builds.insert(0, build_path)  # Put at front
          else:
            found_builds.append(build_path)
  except Exception as e:
    print(f'🚨 Error searching for build directories: {e}')
  return found_builds

found_builds = find_build_directories()
if found_builds:
  print(f'🔍 Found build directories with index.html: {found_builds}')
  # Add found directories to search paths
  build_paths.extend(found_builds)

for build_path in build_paths:
  if os.path.exists(build_path):
    index_html_path = os.path.join(build_path, 'index.html')
    if os.path.exists(index_html_path):
      print(f'✅ Found build directory at: {build_path}')
      print(f'✅ Confirmed index.html exists: {index_html_path}')
      app.mount('/', StaticFiles(directory=build_path, html=True), name='static')
      static_mounted = True
      break
    else:
      print(f'⚠️ Directory exists but no index.html: {build_path}')

if not static_mounted:
  print('❌ WARNING: No build directory found! Static files will not be served.')
  print('🔍 Searched paths:', build_paths)
  print('📂 Current directory:', os.getcwd())
  print('📁 Available files:', os.listdir('.') if os.path.exists('.') else 'None')
  if os.path.exists('client'):
    print('📁 Client directory contents:', os.listdir('client'))
  if os.path.exists('python'):
    print('📁 Python directory exists - checking structure...')
    try:
      for root, dirs, files in os.walk('python'):
        if 'client' in dirs:
          client_path = os.path.join(root, 'client')
          print(f'📁 Found client directory at: {client_path}')
          if os.path.exists(client_path):
            print(f'📁 Client contents: {os.listdir(client_path)}')
    except Exception as e:
      print(f'🚨 Error exploring python directory: {e}')
else:
  print('✅ Static files successfully mounted and ready to serve React app')
