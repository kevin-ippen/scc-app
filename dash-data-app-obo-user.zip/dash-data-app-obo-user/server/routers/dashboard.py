"""Dashboard router for demand forecasting metrics."""

from typing import Any, Dict, List

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from server.services.dashboard_service import DashboardService


class ChartDataPoint(BaseModel):
  """Model for forecast chart data point."""
  date: str
  yhat: float
  yhat_lower: float
  yhat_upper: float


class DashboardMetrics(BaseModel):
  """Model for dashboard metrics response."""
  lastUpdated: str
  projectedMonthlyRevenue: float
  totalForecastedUnits: int
  overallDemandTrend: float
  highVolatilityProducts: int
  forecastAccuracy: float
  currentStockLevels: int
  forecastChartData: List[ChartDataPoint]


class ModelPerformance(BaseModel):
  """Model performance metrics."""
  modelName: str
  mape: float
  rmse: float
  bias: float
  accuracy: float
  isActive: bool


class AccuracyMetrics(BaseModel):
  """Forecast accuracy metrics response."""
  overallMape: float
  overallRmse: float
  overallBias: float
  overallAccuracy: float
  modelPerformance: List[ModelPerformance]
  lastCalculated: str


class ComparisonDataPoint(BaseModel):
  """Single data point for predicted vs actual comparison."""
  date: str
  actualDemand: float
  predictedDemand: float
  accuracy: float


class ComparisonMetrics(BaseModel):
  """Predicted vs actual comparison metrics."""
  data: List[ComparisonDataPoint]
  overallAccuracy: float
  avgError: float
  dateRange: Dict[str, str]
  totalDataPoints: int


router = APIRouter()
dashboard_service = DashboardService()


@router.get('/metrics', response_model=DashboardMetrics)
async def get_dashboard_metrics() -> DashboardMetrics:
  """
  Get all dashboard metrics for the demand forecasting executive dashboard.
  
  Uses REAL Databricks data only. No automatic fallback to mock data.
  
  Returns:
      DashboardMetrics: Complete set of metrics including KPIs and chart data
      
  Raises:
      HTTPException: If unable to fetch metrics from Databricks data source
  """
  try:
    metrics_data = await dashboard_service.get_dashboard_metrics()
    return DashboardMetrics(**metrics_data)
  except Exception as e:
    # Enhanced error message with troubleshooting info
    error_detail = f"""Dashboard Connection Error

Unable to fetch dashboard metrics from Databricks.

{str(e)}

This error means the app cannot connect to your Databricks workspace or the required table is not accessible.

Quick fixes:
1. Check if your SQL warehouse is running
2. Verify the table retail_demand_forecasting.raw_data.dashboardmetrics exists
3. Run the dashboard metrics notebook to populate data
4. For testing only: Set USE_FALLBACK_DATA=true environment variable"""

    raise HTTPException(
      status_code=500, 
      detail=error_detail
    )


@router.post('/refresh')
async def refresh_dashboard_metrics() -> Dict[str, Any]:
  """
  Trigger a refresh of dashboard metrics.
  
  Returns:
      Dictionary containing refresh status and updated metrics
  """
  try:
    metrics_data = await dashboard_service.refresh_metrics()
    return {
      'status': 'success',
      'message': 'Dashboard metrics refreshed successfully',
      'data': metrics_data
    }
  except Exception as e:
    raise HTTPException(
      status_code=500,
      detail=f'Failed to refresh dashboard metrics: {str(e)}'
    )


@router.get('/health')
async def dashboard_health() -> Dict[str, str]:
  """
  Check the health of the dashboard service.
  
  Returns:
      Dictionary containing health status
  """
  return {
    'status': 'healthy',
    'service': 'dashboard',
    'message': 'Dashboard service is operational'
  }


@router.get('/test-connection')
async def test_databricks_connection() -> Dict[str, Any]:
  """
  Test Databricks connection, warehouse access, and table accessibility.

  Returns:
      Dictionary containing detailed connection test results
  """
  try:
    results = await dashboard_service.test_connection()
    return results
  except Exception as e:
    return {
      'error': f'Connection test failed: {str(e)}',
      'status': 'failed'
    }


@router.get('/inventory-health')
async def get_inventory_health() -> Dict[str, Any]:
  """
  Get inventory health metrics and category performance.

  Returns mock data for demonstration purposes.

  Returns:
      Dictionary containing inventory metrics and category performance data
  """
  return {
    'currentStockLevels': 125000,
    'inventoryTurnoverRate': 4.2,
    'lowStockAlerts': 12,
    'expiredStockValue': 45000,
    'avgDaysOnHand': 45,
    'categoryPerformance': [
      {
        'category': 'Serums & Treatments',
        'stockUnits': 45000,
        'forecastAccuracy': 92.5,
        'reorderLevel': 8000,
        'status': 'healthy'
      },
      {
        'category': 'Cleansers',
        'stockUnits': 32000,
        'forecastAccuracy': 89.3,
        'reorderLevel': 6000,
        'status': 'healthy'
      },
      {
        'category': 'Exfoliants',
        'stockUnits': 18000,
        'forecastAccuracy': 94.1,
        'reorderLevel': 3500,
        'status': 'warning'
      },
      {
        'category': 'Moisturizers',
        'stockUnits': 28000,
        'forecastAccuracy': 91.7,
        'reorderLevel': 5000,
        'status': 'healthy'
      },
      {
        'category': 'Sunscreens',
        'stockUnits': 15000,
        'forecastAccuracy': 87.9,
        'reorderLevel': 3000,
        'status': 'critical'
      }
    ]
  }


@router.get('/forecast-accuracy', response_model=AccuracyMetrics)
async def get_forecast_accuracy() -> AccuracyMetrics:
  """
  Get forecast accuracy metrics and model performance comparison.

  Returns detailed accuracy metrics including MAPE, RMSE, bias, and
  per-model performance indicators.

  Returns:
      AccuracyMetrics: Complete accuracy metrics and model performance data
  """
  try:
    metrics_data = await dashboard_service.get_forecast_accuracy()
    return AccuracyMetrics(**metrics_data)
  except Exception as e:
    raise HTTPException(
      status_code=500,
      detail=f'Failed to fetch forecast accuracy metrics: {str(e)}'
    )


@router.get('/predicted-vs-actual', response_model=ComparisonMetrics)
async def get_predicted_vs_actual(days: int = 30) -> ComparisonMetrics:
  """
  Get predicted vs actual demand comparison over time.

  Args:
      days: Number of days to compare (7, 30, or 90)

  Returns:
      ComparisonMetrics: Comparison data including time series, accuracy, and error statistics
  """
  try:
    if days not in [7, 30, 90]:
      raise HTTPException(
        status_code=400,
        detail='Invalid days parameter. Must be 7, 30, or 90'
      )

    comparison_data = await dashboard_service.get_predicted_vs_actual(days)
    return ComparisonMetrics(**comparison_data)
  except HTTPException:
    raise
  except Exception as e:
    raise HTTPException(
      status_code=500,
      detail=f'Failed to fetch comparison data: {str(e)}'
    )