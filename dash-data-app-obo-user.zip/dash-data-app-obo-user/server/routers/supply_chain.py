"""Supply Chain Analytics API endpoints."""

import asyncio
from datetime import datetime
from typing import Any, Dict

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from server.services.supply_chain_service import SupplyChainService

# Initialize router and service
router = APIRouter(prefix="/api/supply-chain", tags=["supply-chain"])
supply_chain_service = SupplyChainService()


@router.get("/overview")
async def get_overview_metrics() -> Dict[str, Any]:
    """
    Get supply chain overview metrics including KPI cards and category performance.
    
    Returns enterprise dashboard overview with:
    - Current stock levels, inventory turnover, alerts
    - Category performance heatmap data  
    - Low stock alerts table
    """
    try:
        return supply_chain_service.get_overview_metrics()
    except Exception as e:
        print(f"❌ Error fetching overview metrics: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch overview metrics: {str(e)}")


@router.get("/scale-metrics")
async def get_scale_metrics() -> Dict[str, Any]:
    """
    Get real-time scale processing metrics.
    
    Returns scale operations data with:
    - Active parallel jobs count
    - Forecasts per second throughput
    - Cluster utilization metrics
    - Job execution history
    """
    try:
        return supply_chain_service.get_scale_metrics()
    except Exception as e:
        print(f"❌ Error fetching scale metrics: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch scale metrics: {str(e)}")


@router.get("/forecast-intelligence")
async def get_forecast_intelligence() -> Dict[str, Any]:
    """
    Get forecast intelligence and model performance metrics.
    
    Returns forecasting data with:
    - Forecast dimensions (stores × SKUs × models)
    - Model comparison matrix
    - Predicted vs actual trends
    - Category demand distribution
    """
    try:
        return supply_chain_service.get_forecast_intelligence_metrics()
    except Exception as e:
        print(f"❌ Error fetching forecast intelligence: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch forecast intelligence: {str(e)}")


@router.get("/business-impact")
async def get_business_impact() -> Dict[str, Any]:
    """
    Get business impact and ROI metrics.
    
    Returns business impact data with:
    - Cost savings and efficiency improvements
    - Processing time comparisons
    - Scale simulator scenarios
    - Investment ROI timeline
    """
    try:
        return supply_chain_service.get_business_impact_metrics()
    except Exception as e:
        print(f"❌ Error fetching business impact: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch business impact: {str(e)}")


@router.get("/filters")
async def get_filters() -> Dict[str, Any]:
    """
    Get available filter options for dashboard components.
    
    Returns filter options including:
    - Product categories
    - Forecast models  
    - Regions and store types
    - Time horizons
    """
    try:
        return supply_chain_service.get_filters_and_options()
    except Exception as e:
        print(f"❌ Error fetching filters: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch filters: {str(e)}")


@router.get("/realtime")
async def get_realtime_metrics() -> Dict[str, Any]:
    """
    Get a single snapshot of real-time metrics.
    
    Returns current real-time metrics for dashboard updates.
    """
    try:
        return await supply_chain_service.get_realtime_stream()
    except Exception as e:
        print(f"❌ Error fetching realtime metrics: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch realtime metrics: {str(e)}")


@router.get("/stream")
async def stream_realtime_metrics():
    """
    Server-sent events stream for real-time metrics updates.
    
    Provides continuous stream of real-time metrics for live dashboard updates.
    """
    async def generate_stream():
        """Generate real-time metrics stream."""
        try:
            while True:
                # Get fresh metrics
                metrics = await supply_chain_service.get_realtime_stream()
                
                # Format as SSE
                data = f"data: {metrics}\n\n"
                yield data.encode('utf-8')
                
                # Wait 2 seconds between updates
                await asyncio.sleep(2)
                
        except Exception as e:
            print(f"❌ Error in metrics stream: {e}")
            error_data = f"data: {{\"error\": \"Stream error: {str(e)}\", \"timestamp\": \"{datetime.now().isoformat()}\"}}\n\n"
            yield error_data.encode('utf-8')
    
    return StreamingResponse(
        generate_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Cache-Control"
        }
    )