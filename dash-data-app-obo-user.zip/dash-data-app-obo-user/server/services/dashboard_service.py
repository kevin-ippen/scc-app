"""Dashboard service for demand forecasting metrics."""

import asyncio
import json
import os
import traceback
from datetime import datetime
from typing import Any, Dict, List, Optional

from databricks.sdk import WorkspaceClient
from databricks.sdk.core import DatabricksError


class DashboardService:
  """Service for fetching dashboard metrics from Databricks."""

  def __init__(self):
    """Initialize the dashboard service with Databricks client."""
    self.client: Optional[WorkspaceClient] = None
    self._initialize_client()
    self._log_configuration()

  def _initialize_client(self) -> None:
    """Initialize the Databricks client with environment variables."""
    try:
      auth_type = os.getenv('DATABRICKS_AUTH_TYPE', 'pat')
      
      if auth_type == 'pat':
        # Use PAT authentication with host and token
        host = os.getenv('DATABRICKS_HOST')
        token = os.getenv('DATABRICKS_TOKEN')

        if not host or not token:
          print('⚠️ Databricks host or token not found in environment')
          print(f'📊 DATABRICKS_HOST: {"SET" if host else "MISSING"}')
          print(f'📊 DATABRICKS_TOKEN: {"SET" if token else "MISSING"}')
          return

        self.client = WorkspaceClient(host=host, token=token)
        print(f'✅ Databricks client initialized with PAT authentication')
        print(f'📊 Host: {host}')
        print(f'📊 Token: {token[:8]}...{token[-4:] if len(token) > 12 else "***"}')
        
      elif auth_type == 'databricks-cli':
        # Use CLI profile authentication (fallback)
        profile = os.getenv('DATABRICKS_CONFIG_PROFILE', 'DEFAULT')
        self.client = WorkspaceClient(profile=profile)
        print(f'✅ Databricks client initialized with profile: {profile}')
        
      elif auth_type == 'databricks-app':
        # Use app-based authentication (for deployed apps)
        self.client = WorkspaceClient()
        print('✅ Databricks client initialized with app authentication')
        
      else:
        print(f'❌ Unknown auth type: {auth_type}')
        print('ℹ️  Supported types: pat, databricks-cli, databricks-app')
        
    except Exception as e:
      print(f'❌ Failed to initialize Databricks client: {e}')
      print(f'📊 Auth type: {os.getenv("DATABRICKS_AUTH_TYPE", "not set")}')
      print(f'📊 Host: {os.getenv("DATABRICKS_HOST", "not set")}')
      print(f'📊 Token: {"SET" if os.getenv("DATABRICKS_TOKEN") else "not set"}')

  def _log_configuration(self) -> None:
    """Log the current dashboard service configuration."""
    use_fallback = os.getenv('USE_FALLBACK_DATA', 'false').lower() == 'true'
    
    print('=' * 60)
    print('📊 DASHBOARD SERVICE CONFIGURATION')
    print('=' * 60)
    
    # Debug environment variables
    print('🔍 ENVIRONMENT VARIABLES DEBUG:')
    print(f'📊 DATABRICKS_AUTH_TYPE: {os.getenv("DATABRICKS_AUTH_TYPE", "NOT SET")}')
    print(f'📊 DATABRICKS_HOST: {os.getenv("DATABRICKS_HOST", "NOT SET")}')
    print(f'📊 DATABRICKS_TOKEN: {"SET" if os.getenv("DATABRICKS_TOKEN") else "NOT SET"}')
    print(f'📊 SQL_WAREHOUSE_ID: {os.getenv("SQL_WAREHOUSE_ID", "NOT SET")}')
    print('=' * 60)
    
    if use_fallback:
      print('⚠️  DATA SOURCE: MOCK/TEST DATA (USE_FALLBACK_DATA=true)')
      print('🚨 WARNING: This is for testing only!')
      print('🚨 WARNING: Not using real Databricks data!')
    else:
      print('✅ DATA SOURCE: REAL DATABRICKS DATA')
      print('📊 Table:', self._get_table_name())
      print('🏭 Warehouse:', os.getenv('SQL_WAREHOUSE_ID', '8baced1ff014912d'))
      print('🔐 Auth Type:', os.getenv('DATABRICKS_AUTH_TYPE', 'databricks-app'))
      print('👤 Client Initialized:', 'Yes' if self.client else 'No')
    
    print('=' * 60)

  def _get_table_name(self) -> str:
    """Get the full table name for dashboard metrics."""
    catalog = os.getenv('CATALOG_NAME', 'retail_demand_forecasting')
    schema = os.getenv('SCHEMA_NAME', 'raw_data')
    table = os.getenv('TABLE_DASHBOARD_METRICS', 'dashboardmetrics')
    return f'{catalog}.{schema}.{table}'

  def get_fallback_data(self) -> Dict[str, Any]:
    """Return fallback data matching the actual table structure."""
    print('🔄 Using fallback data - real Databricks data structure')
    
    # Chart data from actual table (truncated for performance)
    chart_data = [
      {"date": "2025-08-01", "yhat": 14025.9, "yhat_lower": 10197.9, "yhat_upper": 17855.1},
      {"date": "2025-08-02", "yhat": 15801.6, "yhat_lower": 11984.9, "yhat_upper": 19644.0},
      {"date": "2025-08-03", "yhat": 15754.1, "yhat_lower": 11933.5, "yhat_upper": 19568.4},
      {"date": "2025-08-04", "yhat": 13775.3, "yhat_lower": 9950.6, "yhat_upper": 17598.9},
      {"date": "2025-08-05", "yhat": 13680.0, "yhat_lower": 9855.1, "yhat_upper": 17531.6}
    ]
    
    return {
      'lastUpdated': '2025-08-12T22:29:38.424+00:00',
      'projectedMonthlyRevenue': 5249805.41,
      'totalForecastedUnits': 209992,
      'overallDemandTrend': -20.31,
      'highVolatilityProducts': 0,
      'forecastAccuracy': 94.5,
      'currentStockLevels': 184500,
      'forecastChartData': chart_data
    }

  async def test_connection(self) -> Dict[str, Any]:
    """Test the Databricks connection and table access."""
    results = {
      'timestamp': datetime.now().isoformat(),
      'warehouse_id': os.getenv('SQL_WAREHOUSE_ID', '8baced1ff014912d'),
      'catalog': os.getenv('CATALOG_NAME', 'retail_demand_forecasting'),
      'schema': os.getenv('SCHEMA_NAME', 'raw_data'),
      'table': os.getenv('TABLE_DASHBOARD_METRICS', 'dashboardmetrics'),
      'client_initialized': False,
      'warehouse_accessible': False,
      'warehouse_state': None,
      'table_accessible': False,
      'row_count': 0,
      'sample_data': None,
      'error': None
    }
    
    try:
      # Test client initialization
      results['client_initialized'] = self.client is not None
      print(f'📊 Client initialized: {results["client_initialized"]}')
      
      if self.client:
        warehouse_id = results['warehouse_id']
        
        # Test warehouse access
        try:
          warehouse_info = self.client.warehouses.get(warehouse_id)
          results['warehouse_accessible'] = True
          results['warehouse_state'] = warehouse_info.state
          print(f'🏭 Warehouse {warehouse_id} state: {warehouse_info.state}')
        except Exception as e:
          results['warehouse_accessible'] = False
          print(f'❌ Warehouse access failed: {e}')
        
        # Test table access with count
        try:
          table_name = self._get_table_name()
          count_query = f"SELECT COUNT(*) as cnt FROM {table_name}"
          print(f'📊 Testing table access with: {count_query}')
          
          response = self.client.statement_execution.execute_statement(
            warehouse_id=warehouse_id,
            statement=count_query,
            wait_timeout='30s'
          )
          
          if response.result and response.result.data_array:
            results['table_accessible'] = True
            results['row_count'] = response.result.data_array[0][0]
            print(f'✅ Table accessible with {results["row_count"]} rows')
            
            # Get sample data if rows exist
            if results['row_count'] > 0:
              sample_query = f"SELECT last_updated_timestamp, projected_monthly_revenue, total_forecasted_units FROM {table_name} LIMIT 1"
              sample_response = self.client.statement_execution.execute_statement(
                warehouse_id=warehouse_id,
                statement=sample_query,
                wait_timeout='10s'
              )
              if sample_response.result and sample_response.result.data_array:
                sample_row = sample_response.result.data_array[0]
                results['sample_data'] = {
                  'last_updated': sample_row[0],
                  'revenue': sample_row[1],
                  'units': sample_row[2]
                }
          else:
            results['table_accessible'] = False
            print('❌ No data returned from count query')
            
        except Exception as e:
          results['table_accessible'] = False
          print(f'❌ Table access failed: {e}')
      
    except Exception as e:
      results['error'] = str(e)
      print(f'❌ Connection test failed: {e}')
    
    return results

  async def get_dashboard_metrics_with_retry(self, max_retries: int = 3) -> Dict[str, Any]:
    """Get dashboard metrics with retry logic - REAL DATA ONLY unless explicitly configured."""
    use_fallback = os.getenv('USE_FALLBACK_DATA', 'false').lower() == 'true'
    
    if use_fallback:
      print('⚠️ WARNING: Using fallback data mode (USE_FALLBACK_DATA=true)')
      print('📊 This is for testing only - not real Databricks data!')
      return self.get_fallback_data()
    
    print('📊 Using REAL Databricks data - no automatic fallback')
    last_exception = None
    
    for attempt in range(max_retries):
      try:
        print(f'🔄 Dashboard metrics fetch attempt {attempt + 1}/{max_retries}')
        result = await self._fetch_dashboard_metrics()
        print(f'✅ Successfully fetched REAL Databricks data')
        return result
      except Exception as e:
        last_exception = e
        print(f'❌ Attempt {attempt + 1} failed: {str(e)[:200]}')
        if attempt < max_retries - 1:
          wait_time = 2 ** attempt  # Exponential backoff: 1s, 2s, 4s
          print(f'⏳ Waiting {wait_time} seconds before retry...')
          await asyncio.sleep(wait_time)
    
    # All retries failed - raise proper error instead of using fallback
    print(f'❌ All {max_retries} attempts failed to fetch REAL Databricks data')
    error_msg = f"""Failed to fetch dashboard data from Databricks after {max_retries} attempts.

Last error: {str(last_exception)}

Troubleshooting steps:
1. Check Databricks workspace connection
2. Verify SQL warehouse '{os.getenv('SQL_WAREHOUSE_ID', '8baced1ff014912d')}' is running
3. Confirm table '{self._get_table_name()}' exists and is accessible
4. Check authentication credentials

To use test data temporarily, set USE_FALLBACK_DATA=true (not recommended for production)"""
    
    raise Exception(error_msg)

  async def get_dashboard_metrics(self) -> Dict[str, Any]:
    """Main entry point for dashboard metrics with retry and fallback."""
    return await self.get_dashboard_metrics_with_retry()

  async def _fetch_dashboard_metrics(self) -> Dict[str, Any]:
    """
    Internal method to fetch dashboard metrics from Databricks table.
    
    Returns:
        Dictionary containing all dashboard metrics
        
    Raises:
        Exception: If unable to fetch data from Databricks
    """
    print(f'🔍 Starting dashboard metrics fetch at {datetime.now()}')
    
    if not self.client:
      print('❌ Databricks client not initialized')
      raise Exception('Databricks client not initialized. Check your authentication configuration.')

    try:
      table_name = self._get_table_name()
      query = f'SELECT * FROM {table_name} LIMIT 1'
      warehouse_id = os.getenv('SQL_WAREHOUSE_ID', '8baced1ff014912d')
      
      print(f'📊 Table: {table_name}')
      print(f'📝 Query: {query}')
      print(f'🏭 Warehouse ID: {warehouse_id}')
      
      # Check warehouse status first
      try:
        warehouse_info = self.client.warehouses.get(warehouse_id)
        print(f'🏭 Warehouse state: {warehouse_info.state}')
      except Exception as e:
        print(f'⚠️ Could not check warehouse status: {e}')
      
      print(f'🚀 Executing SQL query...')
      response = self.client.statement_execution.execute_statement(
        warehouse_id=warehouse_id,
        statement=query,
        wait_timeout='30s'
      )

      print(f'✅ Query executed successfully')
      print(f'📦 Response type: {type(response)}')
      print(f'📦 Has result: {hasattr(response, "result")}')
      
      # Check response status
      if hasattr(response, 'status'):
        print(f'📊 Query status: {response.status.state if response.status else "No status"}')
      
      if not response.result:
        print('❌ No result object in response')
        raise Exception('No result returned from query')
      
      print(f'📦 Result type: {type(response.result)}')
      print(f'📦 Has data_array: {hasattr(response.result, "data_array")}')
      print(f'📦 Has row_set: {hasattr(response.result, "row_set")}')
      print(f'📦 Has external_links: {hasattr(response.result, "external_links")}')
      
      # Handle different response formats
      data_rows = None
      if hasattr(response.result, 'data_array') and response.result.data_array:
        print(f'📦 Found data_array with {len(response.result.data_array)} rows')
        data_rows = response.result.data_array
      elif hasattr(response.result, 'row_set') and response.result.row_set:
        print(f'📦 Found row_set format')
        # Handle row_set format if needed
        data_rows = response.result.row_set
      elif hasattr(response.result, 'external_links'):
        print('⚠️ Large result set with external links - not supported yet')
        raise Exception('Large result set with external links not supported')
      else:
        print('❌ No data found in any expected format')
        print(f'📦 Full result object: {response.result}')
        raise Exception('No data found in dashboardmetrics table')

      if not data_rows or len(data_rows) == 0:
        print('❌ Data rows is empty')
        raise Exception('No data rows found in query result')

      # Parse the first (and only) row  
      row = data_rows[0]
      print(f'📊 Raw row data: {row}')
      print(f'📊 Row length: {len(row) if row else 0}')
      
      # Try to get columns from the result structure
      columns = []
      if hasattr(response.result, 'manifest') and hasattr(response.result.manifest, 'schema'):
        columns = [col.name for col in response.result.manifest.schema.columns]
        print(f'📊 Columns from manifest: {columns}')
      else:
        # Fallback - assume column order based on our table schema
        columns = [
          'last_updated_timestamp',
          'projected_monthly_revenue', 
          'total_forecasted_units',
          'demand_trend_percent',
          'high_volatility_count',
          'forecast_chart_data'
        ]
        print(f'📊 Using fallback columns: {columns}')
      
      if len(row) != len(columns):
        print(f'⚠️ Column count mismatch: {len(columns)} columns, {len(row)} values')
        print(f'📊 Adjusting columns to match data length')
        # Adjust columns to match actual data
        if len(row) < len(columns):
          columns = columns[:len(row)]
        elif len(row) > len(columns):
          # Add generic column names for extra values
          for i in range(len(columns), len(row)):
            columns.append(f'column_{i}')
      
      data = dict(zip(columns, row))
      print(f'📊 Parsed data keys: {list(data.keys())}')
      print(f'📊 Last updated: {data.get("last_updated_timestamp")}')
      print(f'📊 Revenue: {data.get("projected_monthly_revenue")}')
      print(f'📊 Units: {data.get("total_forecasted_units")}')
      
      # Parse the forecast chart data from JSON string
      forecast_chart_data = []
      chart_data_raw = data.get('forecast_chart_data')
      if chart_data_raw:
        print(f'📊 Chart data length: {len(str(chart_data_raw))}')
        try:
          forecast_chart_data = json.loads(chart_data_raw)
          print(f'✅ Successfully parsed {len(forecast_chart_data)} chart data points')
        except json.JSONDecodeError as e:
          print(f'⚠️ Failed to parse forecast chart data JSON: {e}')
          print(f'📊 Raw chart data preview: {str(chart_data_raw)[:200]}...')
      else:
        print('📊 No chart data found')
      
      # Format the response
      result = {
        'lastUpdated': data.get('last_updated_timestamp'),
        'projectedMonthlyRevenue': float(data.get('projected_monthly_revenue', 0)),
        'totalForecastedUnits': int(data.get('total_forecasted_units', 0)),
        'overallDemandTrend': float(data.get('demand_trend_percent', 0)),
        'highVolatilityProducts': int(data.get('high_volatility_count', 0)),
        'forecastChartData': forecast_chart_data
      }
      
      print(f'✅ Successfully formatted dashboard metrics')
      print(f'📊 Result summary: ${result["projectedMonthlyRevenue"]:,.0f} revenue, {result["totalForecastedUnits"]:,} units')
      
      return result

    except DatabricksError as e:
      print(f'❌ Databricks SDK error: {type(e).__name__}: {e}')
      raise Exception(f'Failed to connect to Databricks: {e}')
    except Exception as e:
      print(f'❌ General error in _fetch_dashboard_metrics: {type(e).__name__}: {e}')
      print(f'📊 Full traceback: {traceback.format_exc()}')
      raise Exception(f'Failed to fetch dashboard data: {e}')

  async def refresh_metrics(self) -> Dict[str, Any]:
    """
    Trigger a refresh of dashboard metrics.

    For now, this just refetches the current data.
    In a production system, this might trigger a pipeline refresh.

    Returns:
        Dictionary containing refreshed dashboard metrics
    """
    print('🔄 Refreshing dashboard metrics...')
    return await self.get_dashboard_metrics()

  async def get_forecast_accuracy(self) -> Dict[str, Any]:
    """
    Get forecast accuracy metrics with model performance comparison.

    Returns mock data for demonstration. In production, this would query
    Databricks tables for actual model performance metrics.

    Returns:
        Dictionary containing accuracy metrics and model performance data
    """
    print('📊 Fetching forecast accuracy metrics...')

    # Mock data matching the expected structure
    return {
      'overallMape': 4.2,
      'overallRmse': 1250.5,
      'overallBias': -2.1,
      'overallAccuracy': 92.3,
      'modelPerformance': [
        {
          'modelName': 'Prophet Ensemble',
          'mape': 3.8,
          'rmse': 1150.2,
          'bias': -1.5,
          'accuracy': 94.2,
          'isActive': True
        },
        {
          'modelName': 'ARIMA Seasonal',
          'mape': 5.1,
          'rmse': 1380.7,
          'bias': -2.8,
          'accuracy': 91.5,
          'isActive': True
        },
        {
          'modelName': 'XGBoost Regression',
          'mape': 4.6,
          'rmse': 1290.3,
          'bias': -1.9,
          'accuracy': 92.7,
          'isActive': False
        },
        {
          'modelName': 'LSTM Neural Net',
          'mape': 4.9,
          'rmse': 1325.8,
          'bias': -2.3,
          'accuracy': 91.8,
          'isActive': True
        }
      ],
      'lastCalculated': datetime.now().isoformat()
    }

  async def get_predicted_vs_actual(self, days: int = 30) -> Dict[str, Any]:
    """
    Get predicted vs actual demand comparison for the specified time range.

    Generates mock time series data for demonstration. In production, this would
    query Databricks tables for actual forecast vs actuals data.

    Args:
        days: Number of days to compare (7, 30, or 90)

    Returns:
        Dictionary containing comparison data, accuracy, and error metrics
    """
    from datetime import timedelta
    import random

    print(f'📊 Fetching predicted vs actual comparison for {days} days...')

    # Generate mock time series data
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)

    data_points = []
    current_date = start_date

    # Base demand with weekly pattern
    base_demand = 15000

    for i in range(days):
      # Add weekly seasonality (higher on weekends)
      day_of_week = current_date.weekday()
      weekly_factor = 1.0
      if day_of_week >= 5:  # Weekend
        weekly_factor = 1.15
      elif day_of_week == 4:  # Friday
        weekly_factor = 1.08

      # Generate actual demand with some randomness
      actual = base_demand * weekly_factor + random.randint(-1000, 1000)

      # Generate predicted demand (close but not perfect)
      prediction_error = random.randint(-800, 800)
      predicted = actual + prediction_error

      # Calculate accuracy for this point
      accuracy = 100 - abs(actual - predicted) / actual * 100

      data_points.append({
        'date': current_date.strftime('%Y-%m-%d'),
        'actualDemand': round(actual, 2),
        'predictedDemand': round(predicted, 2),
        'accuracy': round(accuracy, 1)
      })

      current_date += timedelta(days=1)

    # Calculate overall metrics
    total_error = sum(abs(p['actualDemand'] - p['predictedDemand']) for p in data_points)
    avg_error = total_error / len(data_points)
    avg_accuracy = sum(p['accuracy'] for p in data_points) / len(data_points)

    return {
      'data': data_points,
      'overallAccuracy': round(avg_accuracy, 1),
      'avgError': round(avg_error, 1),
      'dateRange': {
        'start': start_date.strftime('%Y-%m-%d'),
        'end': end_date.strftime('%Y-%m-%d')
      },
      'totalDataPoints': len(data_points)
    }