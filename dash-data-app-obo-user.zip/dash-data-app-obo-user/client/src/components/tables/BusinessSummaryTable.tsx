import { useState, useMemo } from 'react';
import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  getPaginationRowModel,
  getFilteredRowModel,
  ColumnDef,
  flexRender,
  SortingState,
  ColumnFiltersState,
} from '@tanstack/react-table';
import { ArrowUpDown, ArrowUp, ArrowDown, AlertCircle, CheckCircle, AlertTriangle } from 'lucide-react';
import { ProductForecast } from '@/data/mockForecastData';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface BusinessSummaryTableProps {
  data: ProductForecast[];
  onRowSelect?: (product: ProductForecast) => void;
  isLoading?: boolean;
}

// Format large numbers with commas
const formatNumber = (num: number): string => {
  return new Intl.NumberFormat('en-US').format(num);
};

// Get stock risk badge
const StockRiskBadge = ({ risk }: { risk: 'low' | 'medium' | 'high' }) => {
  const config = {
    low: { icon: CheckCircle, color: 'text-green-500', bg: 'bg-green-500/10', label: 'Low' },
    medium: { icon: AlertTriangle, color: 'text-amber-500', bg: 'bg-amber-500/10', label: 'Medium' },
    high: { icon: AlertCircle, color: 'text-red-500', bg: 'bg-red-500/10', label: 'High' }
  };

  const { icon: Icon, color, bg, label } = config[risk];

  return (
    <div className={`flex items-center gap-1.5 px-2 py-1 rounded ${bg}`}>
      <Icon className={`h-3.5 w-3.5 ${color}`} />
      <span className={`text-xs font-medium ${color}`}>{label}</span>
    </div>
  );
};

// Accuracy badge with color coding
const AccuracyBadge = ({ accuracy }: { accuracy: number }) => {
  const getColor = () => {
    if (accuracy >= 100 && accuracy <= 110) return 'text-green-500';
    if (accuracy >= 90 && accuracy < 100) return 'text-amber-500';
    if (accuracy > 110) return 'text-blue-500';
    return 'text-red-500';
  };

  return (
    <span className={`font-semibold ${getColor()}`}>
      {accuracy.toFixed(1)}%
    </span>
  );
};

export function BusinessSummaryTable({ data, onRowSelect, isLoading = false }: BusinessSummaryTableProps) {
  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [rowSelection, setRowSelection] = useState({});

  const columns = useMemo<ColumnDef<ProductForecast>[]>(
    () => [
      {
        accessorKey: 'partner',
        header: ({ column }) => {
          return (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
              className="h-8 px-2 -ml-2"
            >
              Partner
              {column.getIsSorted() === 'asc' ? (
                <ArrowUp className="ml-2 h-3.5 w-3.5" />
              ) : column.getIsSorted() === 'desc' ? (
                <ArrowDown className="ml-2 h-3.5 w-3.5" />
              ) : (
                <ArrowUpDown className="ml-2 h-3.5 w-3.5" />
              )}
            </Button>
          );
        },
        cell: ({ row }) => (
          <div className="font-medium text-blue-300">{row.getValue('partner')}</div>
        ),
      },
      {
        accessorKey: 'category',
        header: ({ column }) => {
          return (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
              className="h-8 px-2 -ml-2"
            >
              Category
              {column.getIsSorted() === 'asc' ? (
                <ArrowUp className="ml-2 h-3.5 w-3.5" />
              ) : column.getIsSorted() === 'desc' ? (
                <ArrowDown className="ml-2 h-3.5 w-3.5" />
              ) : (
                <ArrowUpDown className="ml-2 h-3.5 w-3.5" />
              )}
            </Button>
          );
        },
        cell: ({ row }) => (
          <div className="font-medium">{row.getValue('category')}</div>
        ),
      },
      {
        accessorKey: 'product',
        header: 'Product',
        cell: ({ row }) => (
          <div className="max-w-[200px] truncate" title={row.getValue('product')}>
            {row.getValue('product')}
          </div>
        ),
      },
      {
        accessorKey: 'unitSales',
        header: ({ column }) => {
          return (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
              className="h-8 px-2 -ml-2"
            >
              Unit Sales
              {column.getIsSorted() === 'asc' ? (
                <ArrowUp className="ml-2 h-3.5 w-3.5" />
              ) : column.getIsSorted() === 'desc' ? (
                <ArrowDown className="ml-2 h-3.5 w-3.5" />
              ) : (
                <ArrowUpDown className="ml-2 h-3.5 w-3.5" />
              )}
            </Button>
          );
        },
        cell: ({ row }) => (
          <div className="text-right font-mono">{formatNumber(row.getValue('unitSales'))}</div>
        ),
      },
      {
        accessorKey: 'forecastSHA',
        header: 'Forecast (SHA)',
        cell: ({ row }) => (
          <div className="text-right font-mono text-green-400">{formatNumber(row.getValue('forecastSHA'))}</div>
        ),
      },
      {
        accessorKey: 'forecastGAM',
        header: 'Forecast (GAM)',
        cell: ({ row }) => (
          <div className="text-right font-mono text-purple-400">{formatNumber(row.getValue('forecastGAM'))}</div>
        ),
      },
      {
        accessorKey: 'forecastPartner',
        header: 'Forecast (Partner)',
        cell: ({ row }) => (
          <div className="text-right font-mono text-amber-400">{formatNumber(row.getValue('forecastPartner'))}</div>
        ),
      },
      {
        accessorKey: 'accuracy',
        header: ({ column }) => {
          return (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
              className="h-8 px-2 -ml-2"
            >
              Accuracy
              {column.getIsSorted() === 'asc' ? (
                <ArrowUp className="ml-2 h-3.5 w-3.5" />
              ) : column.getIsSorted() === 'desc' ? (
                <ArrowDown className="ml-2 h-3.5 w-3.5" />
              ) : (
                <ArrowUpDown className="ml-2 h-3.5 w-3.5" />
              )}
            </Button>
          );
        },
        cell: ({ row }) => (
          <div className="text-right">
            <AccuracyBadge accuracy={row.getValue('accuracy')} />
          </div>
        ),
      },
      {
        accessorKey: 'stockRisk',
        header: 'Stock Risk',
        cell: ({ row }) => (
          <div className="flex justify-center">
            <StockRiskBadge risk={row.getValue('stockRisk')} />
          </div>
        ),
      },
    ],
    []
  );

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onRowSelectionChange: setRowSelection,
    state: {
      sorting,
      columnFilters,
      rowSelection,
    },
    initialState: {
      pagination: {
        pageSize: 10,
      },
    },
  });

  const handleRowClick = (row: any) => {
    const product = row.original as ProductForecast;
    if (onRowSelect) {
      onRowSelect(product);
    }
    // Toggle selection
    row.toggleSelected();
  };

  if (isLoading) {
    return (
      <div className="w-full h-64 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="rounded-md border border-border bg-card/30 backdrop-blur-sm">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id} className="border-border hover:bg-transparent">
                {headerGroup.headers.map((header) => {
                  return (
                    <TableHead key={header.id} className="text-blue-300 font-semibold">
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                    </TableHead>
                  );
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow
                  key={row.id}
                  data-state={row.getIsSelected() && 'selected'}
                  onClick={() => handleRowClick(row)}
                  className="cursor-pointer hover:bg-blue-500/10 border-border transition-colors"
                >
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={columns.length} className="h-24 text-center">
                  No products found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between px-2">
        <div className="text-sm text-muted-foreground">
          Showing {table.getState().pagination.pageIndex * table.getState().pagination.pageSize + 1} to{' '}
          {Math.min(
            (table.getState().pagination.pageIndex + 1) * table.getState().pagination.pageSize,
            table.getFilteredRowModel().rows.length
          )}{' '}
          of {table.getFilteredRowModel().rows.length} products
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage()}
          >
            Previous
          </Button>
          <div className="text-sm text-muted-foreground">
            Page {table.getState().pagination.pageIndex + 1} of {table.getPageCount()}
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => table.nextPage()}
            disabled={!table.getCanNextPage()}
          >
            Next
          </Button>
        </div>
      </div>
    </div>
  );
}
