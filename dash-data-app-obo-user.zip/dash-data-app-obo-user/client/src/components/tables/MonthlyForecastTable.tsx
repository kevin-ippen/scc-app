import { MonthlyForecast } from '@/data/mockForecastData';

interface MonthlyForecastTableProps {
  data: MonthlyForecast[];
  isLoading?: boolean;
}

// Format numbers
const formatNumber = (num: number): string => {
  return new Intl.NumberFormat('en-US').format(num);
};

// Get month names from keys
const getMonthColumns = (data: MonthlyForecast[]): string[] => {
  if (data.length === 0) return [];
  const monthlyValues = data[0].monthlyValues;
  return Object.keys(monthlyValues).sort();
};

// Format month key to display name
const formatMonth = (monthKey: string): string => {
  const [year, month] = monthKey.split('-');
  const date = new Date(parseInt(year), parseInt(month) - 1);
  return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
};

const PARTNER_COLUMN_WIDTH = 35;
const CATEGORY_COLUMN_WIDTH = 35;
const PRODUCT_COLUMN_WIDTH = 200;
const METRIC_COLUMN_WIDTH = 100;

const formatPartnerName = (name: string): string => {
  return name.replace(/\s+/g, '\u00a0');
};

// Get color for metric
const getMetricColor = (metric: string): string => {
  switch (metric) {
    case 'SHA':
      return 'text-green-400';
    case 'GAM':
      return 'text-purple-400';
    case 'Partner':
      return 'text-amber-400';
    default:
      return 'text-foreground';
  }
};

export function MonthlyForecastTable({ data, isLoading = false }: MonthlyForecastTableProps) {
  if (isLoading) {
    return (
      <div className="w-full h-64 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <div className="w-full h-64 flex items-center justify-center text-muted-foreground">
        No monthly forecast data available
      </div>
    );
  }

  const monthColumns = getMonthColumns(data);

  return (
    <div className="space-y-4">
      <div className="rounded-md border border-border bg-card/30 backdrop-blur-sm">
        <div className="flex">
          {/* Fixed columns on the left */}
          <div className="flex-shrink-0 border-r border-border">
            <table className="table-fixed">
              <thead>
                <tr className="border-b border-border">
                  <th
                    className="text-blue-300 font-semibold bg-card/90 backdrop-blur-sm h-12 pl-0 pr-0 text-left align-middle whitespace-nowrap"
                    style={{ width: PARTNER_COLUMN_WIDTH }}
                  >
                    Partner
                  </th>
                  <th
                    className="text-blue-300 font-semibold bg-card/90 backdrop-blur-sm h-12 pl-0 pr-0 text-left align-middle whitespace-nowrap -ml-4"
                    style={{ width: CATEGORY_COLUMN_WIDTH }}
                  >
                    Category
                  </th>
                  <th
                    className="text-blue-300 font-semibold bg-card/90 backdrop-blur-sm h-12 px-4 text-left align-middle"
                    style={{ width: PRODUCT_COLUMN_WIDTH }}
                  >
                    Product
                  </th>
                  <th
                    className="text-blue-300 font-semibold bg-card/90 backdrop-blur-sm h-12 px-4 text-left align-middle whitespace-nowrap"
                    style={{ width: METRIC_COLUMN_WIDTH }}
                  >
                    Metric
                  </th>
                </tr>
              </thead>
              <tbody>
                {data.map((row) => (
                  <tr key={row.id} className="border-b border-border hover:bg-blue-500/5">
                    <td
                      className="font-medium bg-card/80 backdrop-blur-sm py-4 pl-0 pr-0 align-middle whitespace-nowrap"
                      style={{ width: PARTNER_COLUMN_WIDTH }}
                      title={row.partner}
                    >
                      {formatPartnerName(row.partner)}
                    </td>
                    <td
                      className="bg-card/80 backdrop-blur-sm py-4 pl-0 pr-0 align-middle whitespace-nowrap -ml-4"
                      style={{ width: CATEGORY_COLUMN_WIDTH }}
                    >
                      {row.category}
                    </td>
                    <td
                      className="bg-card/80 backdrop-blur-sm p-4 align-middle truncate"
                      style={{ width: PRODUCT_COLUMN_WIDTH }}
                      title={row.product}
                    >
                      {row.product}
                    </td>
                    <td
                      className={`font-semibold bg-card/80 backdrop-blur-sm p-4 align-middle whitespace-nowrap ${getMetricColor(row.metric)}`}
                      style={{ width: METRIC_COLUMN_WIDTH }}
                    >
                      {row.metric}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Scrollable month columns on the right */}
          <div className="flex-1 overflow-x-auto">
            <table className="table-auto">
              <thead>
                <tr className="border-b border-border">
                  {monthColumns.map((month) => (
                    <th
                      key={month}
                      className="text-blue-300 font-semibold bg-card/90 backdrop-blur-sm h-12 px-6 text-right align-middle min-w-[120px] border-l border-border/30 whitespace-nowrap"
                    >
                      {formatMonth(month)}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.map((row) => (
                  <tr key={row.id} className="border-b border-border hover:bg-blue-500/5">
                    {monthColumns.map((month) => (
                      <td
                        key={month}
                        className={`text-right font-mono bg-card/80 backdrop-blur-sm py-4 px-6 align-middle border-l border-border/30 ${getMetricColor(row.metric)}`}
                      >
                        {formatNumber(row.monthlyValues[month])}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="text-xs text-muted-foreground px-2">
        <span className="font-semibold">Metrics:</span>{' '}
        <span className="text-green-400">SHA</span> = Seasonal Historical Average,{' '}
        <span className="text-purple-400">GAM</span> = Generalized Additive Model,{' '}
        <span className="text-amber-400">Partner</span> = Partner Forecast
      </div>
    </div>
  );
}
