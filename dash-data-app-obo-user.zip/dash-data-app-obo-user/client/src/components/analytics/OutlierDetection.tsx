import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  AlertTriangle,
  Activity,
  Shield,
  Info,
  Eye
} from 'lucide-react';
import {
  ScatterChart,
  Scatter,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
  Cell,
  ComposedChart,
  Bar
} from 'recharts';

interface OutlierDetectionProps {
  productId: string;
  locationId: string;
  data: any;
  isLoading: boolean;
}

export function OutlierDetection({
  productId,
  locationId,
  data,
  isLoading
}: OutlierDetectionProps) {
  const [detectionMethod, setDetectionMethod] = useState<'statistical'>('statistical');
  const [showOutliersOnly, setShowOutliersOnly] = useState(false);

  // Time series with outliers
  const timeSeriesData = [
    { date: 'Jan', value: 100, isOutlier: false, zScore: 0.2 },
    { date: 'Feb', value: 105, isOutlier: false, zScore: 0.4 },
    { date: 'Mar', value: 98, isOutlier: false, zScore: -0.1 },
    { date: 'Apr', value: 180, isOutlier: true, zScore: 3.2 }, // Outlier
    { date: 'May', value: 110, isOutlier: false, zScore: 0.6 },
    { date: 'Jun', value: 25, isOutlier: true, zScore: -2.8 }, // Outlier
    { date: 'Jul', value: 115, isOutlier: false, zScore: 0.8 },
    { date: 'Aug', value: 108, isOutlier: false, zScore: 0.5 },
    { date: 'Sep', value: 195, isOutlier: true, zScore: 3.6 }, // Outlier
    { date: 'Oct', value: 112, isOutlier: false, zScore: 0.7 },
    { date: 'Nov', value: 106, isOutlier: false, zScore: 0.4 },
    { date: 'Dec', value: 118, isOutlier: false, zScore: 0.9 }
  ];

  // Outlier details
  const outlierDetails = [
    {
      date: 'Apr',
      value: 180,
      expectedRange: '85-125',
      deviation: '+44%',
      possibleCause: 'Promotional spike',
      action: 'Include',
      impact: 'High'
    },
    {
      date: 'Jun',
      value: 25,
      expectedRange: '85-125',
      deviation: '-76%',
      possibleCause: 'Stock-out',
      action: 'Exclude',
      impact: 'High'
    },
    {
      date: 'Sep',
      value: 195,
      expectedRange: '85-125',
      deviation: '+56%',
      possibleCause: 'Data error',
      action: 'Investigate',
      impact: 'Medium'
    }
  ];

  // Box plot data for IQR method
  const boxPlotStats = {
    min: 25,
    q1: 98,
    median: 108,
    q3: 115,
    max: 195,
    outliers: [25, 180, 195]
  };

  const mean = 107;
  const stdDev = 15;

  return (
    <div className="space-y-6">
      <Card className={`${isLoading ? 'animate-pulse' : ''}`}>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-500" />
              Outlier Detection & Handling
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="destructive">
                {outlierDetails.length} Outliers Detected
              </Badge>
              <Button
                size="sm"
                variant={showOutliersOnly ? "default" : "outline"}
                onClick={() => setShowOutliersOnly(!showOutliersOnly)}
              >
                <Eye className="h-3 w-3 mr-1" />
                {showOutliersOnly ? 'Show All' : 'Outliers Only'}
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Statistical Methods */}
          <div className="space-y-4">
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  Using Z-score (±2.5σ) and IQR methods to identify statistical anomalies.
                </AlertDescription>
              </Alert>

              {/* Time Series with Outliers */}
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={showOutliersOnly ? timeSeriesData.filter(d => d.isOutlier) : timeSeriesData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis dataKey="date" stroke="#888" />
                    <YAxis stroke="#888" />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                    />
                    <ReferenceLine y={mean + 2.5 * stdDev} stroke="#ef4444" strokeDasharray="5 5" label="Upper Limit" />
                    <ReferenceLine y={mean} stroke="#10b981" strokeDasharray="3 3" label="Mean" />
                    <ReferenceLine y={mean - 2.5 * stdDev} stroke="#ef4444" strokeDasharray="5 5" label="Lower Limit" />
                    <Bar dataKey="value" fill="#3b82f6">
                      {timeSeriesData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.isOutlier ? '#ef4444' : '#3b82f6'} />
                      ))}
                    </Bar>
                  </ComposedChart>
                </ResponsiveContainer>
              </div>

              {/* Statistical Summary */}
              <div className="grid grid-cols-4 gap-4">
                <div className="p-3 bg-muted/50 rounded-lg">
                  <div className="text-xs text-muted-foreground">Mean</div>
                  <div className="text-lg font-bold">{mean}</div>
                  <div className="text-xs text-muted-foreground">μ</div>
                </div>
                <div className="p-3 bg-muted/50 rounded-lg">
                  <div className="text-xs text-muted-foreground">Std Dev</div>
                  <div className="text-lg font-bold">{stdDev}</div>
                  <div className="text-xs text-muted-foreground">σ</div>
                </div>
                <div className="p-3 bg-muted/50 rounded-lg">
                  <div className="text-xs text-muted-foreground">IQR</div>
                  <div className="text-lg font-bold">{boxPlotStats.q3 - boxPlotStats.q1}</div>
                  <div className="text-xs text-muted-foreground">Q3-Q1</div>
                </div>
                <div className="p-3 bg-muted/50 rounded-lg">
                  <div className="text-xs text-muted-foreground">Threshold</div>
                  <div className="text-lg font-bold text-amber-500">±2.5σ</div>
                  <div className="text-xs text-muted-foreground">Z-score</div>
                </div>
              </div>
          </div>

          {/* Outlier Details Table */}
          <div className="space-y-2">
            <h4 className="text-sm font-semibold">Detected Outliers</h4>
            <div className="space-y-2">
              {outlierDetails.map((outlier) => (
                <div key={outlier.date} className="p-3 bg-muted/30 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <AlertTriangle className={`h-4 w-4 ${outlier.impact === 'High' ? 'text-red-500' : 'text-amber-500'}`} />
                      <span className="font-medium">{outlier.date}</span>
                      <Badge variant="destructive">{outlier.value} units</Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{outlier.deviation}</Badge>
                      <Badge variant={outlier.action === 'Exclude' ? "destructive" : outlier.action === 'Include' ? "default" : "secondary"}>
                        {outlier.action}
                      </Badge>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-xs text-muted-foreground">
                    <div>Expected: {outlier.expectedRange}</div>
                    <div>Cause: {outlier.possibleCause}</div>
                    <div>Impact: {outlier.impact}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Action Summary */}
          <Alert className="border-blue-500/50">
            <Shield className="h-4 w-4" />
            <AlertDescription>
              <strong>Recommended Actions:</strong>
              <ul className="mt-2 space-y-1 text-xs">
                <li>• Exclude 1 outlier (Jun) from forecast model training</li>
                <li>• Include 1 outlier (Apr) as valid promotional spike</li>
                <li>• Investigate 1 outlier (Sep) for potential data quality issue</li>
                <li>• Apply robust forecasting methods (e.g., M-estimators) to reduce outlier impact</li>
              </ul>
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  );
}