import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  GitBranch,
  Layers,
  ArrowUp,
  ArrowDown,
  CheckCircle,
  AlertCircle,
  Shuffle
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';

interface HierarchicalReconciliationProps {
  productId: string;
  locationId: string;
  data: any;
  isLoading: boolean;
}

export function HierarchicalReconciliation({
  productId,
  locationId,
  data,
  isLoading
}: HierarchicalReconciliationProps) {
  const [reconciliationMethod, setReconciliationMethod] = useState<'topDown' | 'bottomUp' | 'optimal'>('optimal');

  // Hierarchy structure data
  const hierarchyData = {
    company: {
      forecast: 10000,
      name: 'Paula\'s Choice Total'
    },
    categories: [
      { name: 'Skincare', forecast: 6000, percentage: 60 },
      { name: 'Haircare', forecast: 2500, percentage: 25 },
      { name: 'Makeup', forecast: 1500, percentage: 15 }
    ],
    products: [
      { category: 'Skincare', name: 'Serums', forecast: 3000, stores: 5 },
      { category: 'Skincare', name: 'Moisturizers', forecast: 2000, stores: 5 },
      { category: 'Skincare', name: 'Cleansers', forecast: 1000, stores: 5 },
      { category: 'Haircare', name: 'Shampoos', forecast: 1500, stores: 4 },
      { category: 'Haircare', name: 'Conditioners', forecast: 1000, stores: 4 },
      { category: 'Makeup', name: 'Foundation', forecast: 900, stores: 3 },
      { category: 'Makeup', name: 'Lipstick', forecast: 600, stores: 3 }
    ]
  };

  // Reconciliation accuracy comparison
  const accuracyComparison = [
    { method: 'Top-Down', accuracy: data?.topDown || 0.92, coherence: 1.0, complexity: 'Low' },
    { method: 'Bottom-Up', accuracy: data?.bottomUp || 0.88, coherence: 0.95, complexity: 'Low' },
    { method: 'Optimal Combination', accuracy: data?.optimal || 0.94, coherence: 0.98, complexity: 'High' }
  ];

  // Coherence check results
  const coherenceCheck = {
    topLevel: 10000,
    sumOfParts: reconciliationMethod === 'bottomUp' ? 9850 : 10000,
    isCoherent: reconciliationMethod !== 'bottomUp',
    difference: reconciliationMethod === 'bottomUp' ? 150 : 0
  };

  // Treemap data for hierarchy visualization
  const treemapData = [
    {
      name: 'Paula\'s Choice',
      children: [
        {
          name: 'Skincare',
          size: 6000,
          children: [
            { name: 'Serums', size: 3000 },
            { name: 'Moisturizers', size: 2000 },
            { name: 'Cleansers', size: 1000 }
          ]
        },
        {
          name: 'Haircare',
          size: 2500,
          children: [
            { name: 'Shampoos', size: 1500 },
            { name: 'Conditioners', size: 1000 }
          ]
        },
        {
          name: 'Makeup',
          size: 1500,
          children: [
            { name: 'Foundation', size: 900 },
            { name: 'Lipstick', size: 600 }
          ]
        }
      ]
    }
  ];

  return (
    <div className="space-y-6">
      <Card className={`${isLoading ? 'animate-pulse' : ''}`}>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <GitBranch className="h-5 w-5 text-blue-500" />
              Hierarchical Forecast Reconciliation
            </div>
            <div className="flex gap-2">
              {['topDown', 'bottomUp', 'optimal'].map((method) => (
                <Button
                  key={method}
                  size="sm"
                  variant={reconciliationMethod === method ? "default" : "outline"}
                  onClick={() => setReconciliationMethod(method as any)}
                >
                  {method === 'topDown' && <ArrowDown className="h-3 w-3 mr-1" />}
                  {method === 'bottomUp' && <ArrowUp className="h-3 w-3 mr-1" />}
                  {method === 'optimal' && <Shuffle className="h-3 w-3 mr-1" />}
                  {method === 'topDown' ? 'Top-Down' : method === 'bottomUp' ? 'Bottom-Up' : 'Optimal'}
                </Button>
              ))}
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Method Description */}
          <Alert>
            <Layers className="h-4 w-4" />
            <AlertDescription>
              <strong>{reconciliationMethod === 'topDown' ? 'Top-Down' : reconciliationMethod === 'bottomUp' ? 'Bottom-Up' : 'Optimal Combination'}:</strong>
              {reconciliationMethod === 'topDown' && ' Forecast at company level, then disaggregate to categories and products using historical proportions.'}
              {reconciliationMethod === 'bottomUp' && ' Forecast each product individually, then aggregate up to categories and company level.'}
              {reconciliationMethod === 'optimal' && ' Combine top-down and bottom-up forecasts using optimal weights based on historical accuracy.'}
            </AlertDescription>
          </Alert>

          {/* Hierarchy Visualization */}
          <div className="grid grid-cols-2 gap-4">
            {/* Hierarchy Levels */}
            <div className="space-y-3">
              <h4 className="text-sm font-semibold">Forecast Hierarchy</h4>

              {/* Company Level */}
              <div className="p-3 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Company Total</span>
                  <span className="text-lg font-bold">{hierarchyData.company.forecast.toLocaleString()}</span>
                </div>
              </div>

              {/* Category Level */}
              <div className="space-y-2">
                {hierarchyData.categories.map((category) => (
                  <div key={category.name} className="p-2 bg-muted/50 rounded-lg flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full" />
                      <span className="text-sm">{category.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">
                        {category.percentage}%
                      </Badge>
                      <span className="text-sm font-semibold">{category.forecast.toLocaleString()}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Product Level Sample */}
              <div className="text-xs text-muted-foreground">
                + {hierarchyData.products.length} individual products across {new Set(hierarchyData.products.map(p => p.category)).size} categories
              </div>
            </div>

            {/* Accuracy Comparison */}
            <div className="space-y-3">
              <h4 className="text-sm font-semibold">Method Performance</h4>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={accuracyComparison}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis dataKey="method" stroke="#888" angle={-45} textAnchor="end" height={60} />
                    <YAxis stroke="#888" domain={[0.8, 1.0]} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                    />
                    <Bar dataKey="accuracy" fill="#3b82f6" name="Accuracy" />
                    <Bar dataKey="coherence" fill="#10b981" name="Coherence" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Coherence Check */}
          <div className="p-4 bg-muted/50 rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                {coherenceCheck.isCoherent ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-amber-500" />
                )}
                <span className="font-semibold text-sm">Coherence Check</span>
              </div>
              <Badge variant={coherenceCheck.isCoherent ? "default" : "secondary"}>
                {coherenceCheck.isCoherent ? 'Coherent' : 'Adjustment Needed'}
              </Badge>
            </div>
            <div className="grid grid-cols-3 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Top Level:</span>
                <div className="font-mono">{coherenceCheck.topLevel.toLocaleString()}</div>
              </div>
              <div>
                <span className="text-muted-foreground">Sum of Parts:</span>
                <div className="font-mono">{coherenceCheck.sumOfParts.toLocaleString()}</div>
              </div>
              <div>
                <span className="text-muted-foreground">Difference:</span>
                <div className={`font-mono ${coherenceCheck.difference === 0 ? 'text-green-500' : 'text-amber-500'}`}>
                  {coherenceCheck.difference === 0 ? '0 (Perfect)' : `${coherenceCheck.difference} units`}
                </div>
              </div>
            </div>
            {!coherenceCheck.isCoherent && (
              <Alert className="mt-3 border-amber-500/50">
                <AlertDescription className="text-xs">
                  Bottom-up forecasts don't sum to top-level forecast. Apply reconciliation to ensure coherence.
                </AlertDescription>
              </Alert>
            )}
          </div>

          {/* Reconciliation Weights (for Optimal method) */}
          {reconciliationMethod === 'optimal' && (
            <div className="p-4 bg-gradient-to-r from-purple-500/10 to-blue-500/10 rounded-lg">
              <h4 className="text-sm font-semibold mb-3">Optimal Combination Weights</h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Top-Down Weight</span>
                  <div className="flex items-center gap-2">
                    <Progress value={65} className="w-32 h-2" />
                    <span className="text-sm font-mono">65%</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Bottom-Up Weight</span>
                  <div className="flex items-center gap-2">
                    <Progress value={35} className="w-32 h-2" />
                    <span className="text-sm font-mono">35%</span>
                  </div>
                </div>
              </div>
              <div className="text-xs text-muted-foreground mt-2">
                Weights optimized based on historical forecast errors at each level
              </div>
            </div>
          )}

          {/* Implementation Notes */}
          <div className="text-xs text-muted-foreground space-y-1">
            <div>• Top-down works best when aggregate patterns are stable</div>
            <div>• Bottom-up captures product-specific trends but may lose overall coherence</div>
            <div>• Optimal combination typically provides best accuracy (94% vs 92%/88%)</div>
            <div>• Reconciliation ensures forecasts are coherent across all hierarchy levels</div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}