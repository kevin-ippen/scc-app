import { useEffect, useRef, useState, type KeyboardEvent } from 'react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { cn } from '@/lib/utils';
import { Bot, Loader2, MessageCircle, Send, Sparkles, X } from 'lucide-react';

type ChatMessage = {
  id: string;
  role: 'genie' | 'user';
  content: string;
};

const suggestedPrompts = [
  'Where are we overstocked in the next 6 weeks?',
  'Why is forecast error creeping up for wipes?',
  'How do we improve fill rate for retail promos?',
];

const responseBank: { keywords: string[]; response: string }[] = [
  {
    keywords: ['accuracy', 'mape', 'error', 'bias'],
    response:
      'Forecast accuracy is holding at ~92% MAPE with a slight bias in the Northeast. Biggest driver is promo uplift not fully captured for wipes; quick win: retrain with the latest POS and marketing calendars, then reduce safety stock on stable SKUs by 4-6%.',
  },
  {
    keywords: ['inventory', 'overstock', 'stock', 'days', 'weeks'],
    response:
      'Inventory coverage sits at 6.2 weeks overall. West DC is heavy on cleaning sprays (+22% vs target) because demand cooled after the last campaign. Recommend shifting 8-10% to Central and trimming next two POs; keeps fill rate >97% without starving store replenishment.',
  },
  {
    keywords: ['promo', 'promotion', 'marketing', 'campaign'],
    response:
      'Upcoming retail promos add ~11-13% lift on wipes and cleaners. To keep service above 97%, front-load production two weeks early and lean on regional mixing centers; avoid overbuying resin where we already have 5.5 weeks of cover.',
  },
  {
    keywords: ['fill', 'service', 'on-time', 'delivery'],
    response:
      'Fill rate is 97.4% this week; risk pockets are in Home Care due to upstream resin constraints. Shift allocation from low-velocity SKUs and keep OTIF tight by pulling forward two inbound loads to the Midwest.',
  },
  {
    keywords: ['clorox', 'wipes', 'bleach'],
    response:
      'For the Clorox stack: wipes demand is +12% week-over-week, mostly from retail promos. Bleach is stable. You can hold fill rate by reallocating 5% of wipes safety stock from e-comm to retail and batching late-week runs to avoid overtime.',
  },
  {
    keywords: ['ai', 'genie', 'assistant'],
    response:
      'Think of me as a playbook: I stitch demand signals (orders, POS, promos) and surface quick levers—where to trim safety stock, which DCs to rebalance, and which products to watch. No backend call here; it is a storyboard for the Clorox demo.',
  },
];

const fallbackResponses = [
  'Here is the fast read: demand is steady, promos add a modest uplift, and supply stays green if we rebalance stock from West to Central. Biggest lever remains tightening the promo uplift model and trimming safety stock on stable SKUs.',
  'Top moves: reduce excess on slow movers, rebalance wipes toward retail-heavy regions, and keep production flexible ahead of the next promo window. That protects fill rate while freeing 3-5% working capital.',
  'Signals I am tracking: promo uplift strength, regional demand splits, and any drift in forecast bias. Right now the plan holds with >97% service if we adjust safety stock on the low-volatility SKUs.',
];

function buildResponse(question: string) {
  const normalized = question.toLowerCase();
  const matched = responseBank.find((entry) =>
    entry.keywords.some((keyword) => normalized.includes(keyword)),
  );

  if (matched) {
    return matched.response;
  }

  const fallback =
    fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
  return fallback;
}

export function GenieAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'intro',
      role: 'genie',
      content:
        'I am the Genie for Demand Forecasting. Ask about accuracy, inventory risk, or promo impact and I will outline the playbook.',
    },
    {
      id: 'pulse',
      role: 'genie',
      content:
        'Quick pulse: accuracy holding near 92%, fill rate 97%+, mild overstock in West DC on cleaning sprays. Try asking how to course-correct.',
    },
  ]);
  const timeoutRef = useRef<number | null>(null);
  const endOfMessagesRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        window.clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  useEffect(() => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isThinking]);

  const handleSend = (promptText?: string) => {
    const text = (promptText ?? input).trim();
    if (!text || isThinking) return;

    const newUserMessage: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: text,
    };

    setMessages((prev) => [...prev, newUserMessage]);
    setInput('');
    setIsThinking(true);

    timeoutRef.current = window.setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          id: crypto.randomUUID(),
          role: 'genie',
          content: buildResponse(text),
        },
      ]);
      setIsThinking(false);
    }, 500 + Math.random() * 500);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3">
      {isOpen && (
        <div className="w-[380px] max-w-[calc(100vw-2rem)] rounded-2xl border border-border bg-card shadow-2xl backdrop-blur-xl ring-1 ring-primary/30">
          <div className="flex items-center justify-between gap-3 border-b border-border/20 px-4 py-3">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/20 text-primary">
                <Sparkles className="h-5 w-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <p className="text-base font-semibold text-foreground">
                    Genie Q&A
                  </p>
                </div>
                <p className="text-xs text-muted-foreground">
                  Ask natural questions, get the playbook instantly.
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="text-muted-foreground hover:text-foreground"
              onClick={() => setIsOpen(false)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          <div className="flex flex-col gap-3 p-4">
            <div className="flex flex-wrap gap-2">
              {suggestedPrompts.map((prompt) => (
                <button
                  key={prompt}
                  onClick={() => handleSend(prompt)}
                  className="rounded-full border border-border bg-secondary px-3 py-1 text-xs text-secondary-foreground transition hover:border-primary/40 hover:bg-primary/10"
                >
                  {prompt}
                </button>
              ))}
            </div>

            <div className="flex max-h-[320px] min-h-[260px] flex-col gap-3 overflow-hidden rounded-xl border border-border bg-background p-3">
              <div className="flex-1 space-y-3 overflow-y-auto pr-1">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={cn(
                      'flex w-full gap-2',
                      message.role === 'user' ? 'justify-end' : 'justify-start',
                    )}
                  >
                    {message.role === 'genie' && (
                      <div className="mt-1 flex h-7 w-7 items-center justify-center rounded-full border border-primary/30 bg-primary/15 text-primary">
                        <Bot className="h-4 w-4" />
                      </div>
                    )}
                    <div
                      className={cn(
                        'max-w-[80%] rounded-2xl px-3 py-2 text-sm shadow-sm backdrop-blur',
                        message.role === 'user'
                          ? 'bg-primary text-primary-foreground'
                          : 'border border-border bg-secondary text-secondary-foreground',
                      )}
                    >
                      <p className="whitespace-pre-line leading-relaxed">
                        {message.content}
                      </p>
                    </div>
                    {message.role === 'user' && (
                      <div className="mt-1 flex h-7 w-7 items-center justify-center rounded-full border border-border bg-secondary text-secondary-foreground">
                        <MessageCircle className="h-4 w-4" />
                      </div>
                    )}
                  </div>
                ))}
                {isThinking && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Genie is drafting an answer...
                  </div>
                )}
                <div ref={endOfMessagesRef} />
              </div>

              <div className="flex items-end gap-2">
                <Textarea
                  value={input}
                  onChange={(event) => setInput(event.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Ask about forecast drivers, risk, or next actions..."
                  className="min-h-[64px] resize-none border-border bg-input text-sm text-foreground placeholder:text-muted-foreground"
                />
                <Button
                  onClick={() => handleSend()}
                  disabled={!input.trim() || isThinking}
                  className="h-full px-3"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>

            </div>
          </div>
        </div>
      )}

      <button
        onClick={() => setIsOpen((open) => !open)}
        className="flex items-center gap-3 rounded-full border border-primary/30 bg-primary/15 px-4 py-2 text-sm font-semibold text-primary shadow-lg backdrop-blur transition hover:border-primary/50 hover:bg-primary/25"
      >
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-inner">
          <Sparkles className="h-4 w-4" />
        </div>
        <div className="text-left">
          <p className="leading-none">Launch Genie</p>
          <p className="text-[11px] text-primary/80">Ask anything in the demo</p>
        </div>
      </button>
    </div>
  );
}
