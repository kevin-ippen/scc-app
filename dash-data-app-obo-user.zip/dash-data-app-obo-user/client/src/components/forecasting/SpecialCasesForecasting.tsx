import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import {
  Activity,
  TrendingUp,
  BarChart2,
  Zap,
  AlertCircle,
  Info,
  GitBranch
} from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';

interface SpecialCasesForecastingProps {
  productId: string;
  locationId: string;
  data: any;
  isLoading: boolean;
}

export function SpecialCasesForecasting({
  productId,
  locationId,
  data,
  isLoading
}: SpecialCasesForecastingProps) {
  const [selectedCase, setSelectedCase] = useState<'sparse' | 'nonSeasonal' | 'short'>('sparse');

  // Sparse/Intermittent demand data (lots of zeros)
  const sparseData = [
    { month: 'Jan', demand: 0, forecast: 12, probability: 0.3 },
    { month: 'Feb', demand: 45, forecast: 12, probability: 0.3 },
    { month: 'Mar', demand: 0, forecast: 12, probability: 0.3 },
    { month: 'Apr', demand: 0, forecast: 12, probability: 0.3 },
    { month: 'May', demand: 38, forecast: 12, probability: 0.3 },
    { month: 'Jun', demand: 0, forecast: 12, probability: 0.3 },
    { month: 'Jul', demand: 52, forecast: 12, probability: 0.3 },
    { month: 'Aug', demand: 0, forecast: 12, probability: 0.3 },
    { month: 'Sep', demand: 0, forecast: 12, probability: 0.3 },
    { month: 'Oct', demand: 41, forecast: 12, probability: 0.3 },
    { month: 'Nov', demand: 0, forecast: 12, probability: 0.3 },
    { month: 'Dec', demand: 48, forecast: 12, probability: 0.3 }
  ];

  // Non-seasonal trend data (straight line or random walk)
  const nonSeasonalData = [
    { month: 'Jan', actual: 100, trend: 102, naive: 100 },
    { month: 'Feb', actual: 105, trend: 104, naive: 100 },
    { month: 'Mar', actual: 103, trend: 106, naive: 105 },
    { month: 'Apr', actual: 108, trend: 108, naive: 103 },
    { month: 'May', actual: 110, trend: 110, naive: 108 },
    { month: 'Jun', actual: 112, trend: 112, naive: 110 },
    { month: 'Jul', actual: 115, trend: 114, naive: 112 },
    { month: 'Aug', actual: 113, trend: 116, naive: 115 },
    { month: 'Sep', actual: 118, trend: 118, naive: 113 },
    { month: 'Oct', actual: 120, trend: 120, naive: 118 },
    { month: 'Nov', actual: 122, trend: 122, naive: 120 },
    { month: 'Dec', actual: 125, trend: 124, naive: 122 }
  ];

  // Short time series data (only 2-3 months)
  const shortSeriesData = [
    { month: 'Oct', actual: 85, simpleAvg: null, naive: null },
    { month: 'Nov', actual: 92, simpleAvg: null, naive: 85 },
    { month: 'Dec', actual: 88, simpleAvg: 88.5, naive: 92 },
    { month: 'Jan (F)', actual: null, simpleAvg: 88.3, naive: 88 },
    { month: 'Feb (F)', actual: null, simpleAvg: 88.3, naive: 88 },
    { month: 'Mar (F)', actual: null, simpleAvg: 88.3, naive: 88 }
  ];

  return (
    <Card className={`${isLoading ? 'animate-pulse' : ''}`}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="h-5 w-5 text-amber-500" />
          Special Cases Forecasting
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Case Type Selector */}
        <Tabs value={selectedCase} onValueChange={(v) => setSelectedCase(v as any)}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="sparse">
              <Zap className="h-4 w-4 mr-2" />
              Sparse/Intermittent
            </TabsTrigger>
            <TabsTrigger value="nonSeasonal">
              <TrendingUp className="h-4 w-4 mr-2" />
              Non-Seasonal
            </TabsTrigger>
            <TabsTrigger value="short">
              <BarChart2 className="h-4 w-4 mr-2" />
              Short Series
            </TabsTrigger>
          </TabsList>

          {/* Sparse/Intermittent Demand */}
          <TabsContent value="sparse" className="space-y-4">
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                <strong>Intermittent Demand Pattern:</strong> Product shows sporadic demand with many zero periods.
                Using Croston's method and demand probability estimation.
              </AlertDescription>
            </Alert>

            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={sparseData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="month" stroke="#888" />
                  <YAxis stroke="#888" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                  />
                  <Legend />
                  <Bar dataKey="demand" fill="#3b82f6" name="Actual Demand" />
                  <ReferenceLine
                    y={12}
                    stroke="#10b981"
                    strokeDasharray="5 5"
                    label={{ value: "Average Non-Zero Demand", position: "right", fill: "#10b981" }}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="p-3 bg-muted/50 rounded-lg">
                <div className="text-xs text-muted-foreground">Zero Periods</div>
                <div className="text-lg font-bold text-red-500">67%</div>
                <div className="text-xs text-muted-foreground">8 of 12 months</div>
              </div>
              <div className="p-3 bg-muted/50 rounded-lg">
                <div className="text-xs text-muted-foreground">Avg Non-Zero</div>
                <div className="text-lg font-bold">44 units</div>
                <div className="text-xs text-muted-foreground">When demand occurs</div>
              </div>
              <div className="p-3 bg-muted/50 rounded-lg">
                <div className="text-xs text-muted-foreground">Demand Probability</div>
                <div className="text-lg font-bold text-blue-500">33%</div>
                <div className="text-xs text-muted-foreground">Chance of demand</div>
              </div>
            </div>

            <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
              <div className="font-semibold text-sm mb-2">Croston's Method Forecast:</div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Expected Demand:</span>
                  <span className="ml-2 font-semibold">14.5 units/month</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Inter-arrival Time:</span>
                  <span className="ml-2 font-semibold">3 months</span>
                </div>
              </div>
              <div className="text-xs text-muted-foreground mt-2">
                Recommended: Hold safety stock of 50 units to cover demand spikes
              </div>
            </div>
          </TabsContent>

          {/* Non-Seasonal Pattern */}
          <TabsContent value="nonSeasonal" className="space-y-4">
            <Alert>
              <TrendingUp className="h-4 w-4" />
              <AlertDescription>
                <strong>Non-Seasonal Pattern:</strong> Product shows linear trend with no clear seasonal pattern.
                Using trend extrapolation and moving averages.
              </AlertDescription>
            </Alert>

            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={nonSeasonalData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="month" stroke="#888" />
                  <YAxis stroke="#888" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="actual"
                    stroke="#ffffff"
                    strokeWidth={2}
                    dot={{ fill: '#ffffff' }}
                    name="Actual"
                  />
                  <Line
                    type="monotone"
                    dataKey="trend"
                    stroke="#10b981"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={false}
                    name="Linear Trend"
                  />
                  <Line
                    type="monotone"
                    dataKey="naive"
                    stroke="#f59e0b"
                    strokeWidth={2}
                    strokeDasharray="3 3"
                    dot={false}
                    name="Naive Forecast"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="p-3 bg-muted/50 rounded-lg">
                <div className="text-xs text-muted-foreground">Trend Slope</div>
                <div className="text-lg font-bold text-green-500">+2.3</div>
                <div className="text-xs text-muted-foreground">Units per month</div>
              </div>
              <div className="p-3 bg-muted/50 rounded-lg">
                <div className="text-xs text-muted-foreground">R² Score</div>
                <div className="text-lg font-bold">0.94</div>
                <div className="text-xs text-muted-foreground">Linear fit quality</div>
              </div>
              <div className="p-3 bg-muted/50 rounded-lg">
                <div className="text-xs text-muted-foreground">Seasonality Test</div>
                <div className="text-lg font-bold text-red-500">Failed</div>
                <div className="text-xs text-muted-foreground">No pattern detected</div>
              </div>
            </div>
          </TabsContent>

          {/* Short Time Series */}
          <TabsContent value="short" className="space-y-4">
            <Alert className="border-amber-500/50">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>Limited History:</strong> Only 3 months of data available.
                Using simple methods with high uncertainty bounds.
              </AlertDescription>
            </Alert>

            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={shortSeriesData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="month" stroke="#888" />
                  <YAxis stroke="#888" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="actual"
                    stroke="#ffffff"
                    strokeWidth={2}
                    dot={{ fill: '#ffffff', r: 6 }}
                    name="Actual"
                  />
                  <Line
                    type="monotone"
                    dataKey="simpleAvg"
                    stroke="#3b82f6"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    connectNulls
                    name="Simple Average"
                  />
                  <Line
                    type="monotone"
                    dataKey="naive"
                    stroke="#f59e0b"
                    strokeWidth={2}
                    strokeDasharray="3 3"
                    connectNulls
                    name="Naive (Last Value)"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-lg">
              <div className="font-semibold text-sm mb-2">Forecast Methods Available:</div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Simple Average:</span>
                  <span className="font-mono">88.3 units</span>
                </div>
                <div className="flex justify-between">
                  <span>Last Value (Naive):</span>
                  <span className="font-mono">88.0 units</span>
                </div>
                <div className="flex justify-between">
                  <span>Linear Extrapolation:</span>
                  <span className="font-mono">89.5 units</span>
                </div>
              </div>
              <div className="text-xs text-amber-600 mt-3">
                ⚠️ Confidence interval: ±40% due to limited data points
              </div>
            </div>

            <Alert>
              <GitBranch className="h-4 w-4" />
              <AlertDescription className="text-xs">
                <strong>Recommendation:</strong> Combine with category-level patterns or similar products
                to improve accuracy. Continue collecting data for at least 3 more months.
              </AlertDescription>
            </Alert>
          </TabsContent>
        </Tabs>

        {/* Summary Statistics */}
        <div className="p-4 bg-background/50 rounded-lg">
          <div className="text-sm font-semibold mb-2">Special Cases in Portfolio:</div>
          <div className="grid grid-cols-3 gap-4 text-xs">
            <div className="text-center">
              <div className="text-2xl font-bold text-amber-500">{data?.sparse || 12}</div>
              <div className="text-muted-foreground">Sparse Series</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-500">{data?.nonSeasonal || 23}</div>
              <div className="text-muted-foreground">Non-Seasonal</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-500">{data?.irregular || 7}</div>
              <div className="text-muted-foreground">Irregular</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}