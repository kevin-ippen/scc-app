import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Sparkles,
  TrendingUp,
  Users,
  Package,
  AlertCircle,
  Lightbulb,
  Target
} from 'lucide-react';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';

interface NewProductForecastingProps {
  productId: string;
  locationId: string;
  data: any;
  isLoading: boolean;
}

export function NewProductForecasting({
  productId,
  locationId,
  data,
  isLoading
}: NewProductForecastingProps) {
  const [forecastMethod, setForecastMethod] = useState<'similar' | 'category' | 'ramp'>('similar');

  // Mock data for similar product matching
  const similarProducts = [
    { id: 'PC-1963', name: 'Vitamin C Booster', similarity: 92, avgSales: 450 },
    { id: 'PC-4521', name: 'Niacinamide Treatment', similarity: 87, avgSales: 380 },
    { id: 'PC-7893', name: 'Retinol Complex', similarity: 81, avgSales: 520 }
  ];

  // Ramp-up curve for new products
  const rampUpData = [
    { week: 'W1', forecast: 20, lower: 10, upper: 35 },
    { week: 'W2', forecast: 45, lower: 30, upper: 65 },
    { week: 'W3', forecast: 80, lower: 60, upper: 105 },
    { week: 'W4', forecast: 120, lower: 95, upper: 150 },
    { week: 'W5', forecast: 165, lower: 140, upper: 195 },
    { week: 'W6', forecast: 210, lower: 180, upper: 245 },
    { week: 'W7', forecast: 250, lower: 215, upper: 290 },
    { week: 'W8', forecast: 280, lower: 245, upper: 320 },
    { week: 'W9', forecast: 300, lower: 265, upper: 340 },
    { week: 'W10', forecast: 310, lower: 275, upper: 350 },
    { week: 'W11', forecast: 315, lower: 280, upper: 355 },
    { week: 'W12', forecast: 320, lower: 285, upper: 360 }
  ];

  // Category-level patterns
  const categoryPatterns = [
    { month: 'Jan', skincare: 100, haircare: 85, makeup: 120 },
    { month: 'Feb', skincare: 110, haircare: 90, makeup: 115 },
    { month: 'Mar', skincare: 125, haircare: 95, makeup: 130 },
    { month: 'Apr', skincare: 135, haircare: 105, makeup: 125 },
    { month: 'May', skincare: 140, haircare: 110, makeup: 135 },
    { month: 'Jun', skincare: 145, haircare: 115, makeup: 140 }
  ];

  const isNewProduct = productId.includes('NEW');

  return (
    <Card className={`${isLoading ? 'animate-pulse' : ''}`}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-purple-500" />
            New Product Forecasting
          </div>
          {isNewProduct && (
            <Badge variant="secondary" className="bg-purple-500/20">
              No Historical Data
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Method Selection */}
        <Tabs value={forecastMethod} onValueChange={(v) => setForecastMethod(v as any)}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="similar">
              <Users className="h-4 w-4 mr-2" />
              Similar Products
            </TabsTrigger>
            <TabsTrigger value="category">
              <Package className="h-4 w-4 mr-2" />
              Category Patterns
            </TabsTrigger>
            <TabsTrigger value="ramp">
              <TrendingUp className="h-4 w-4 mr-2" />
              Ramp-Up Curve
            </TabsTrigger>
          </TabsList>

          <TabsContent value="similar" className="space-y-4">
            <Alert>
              <Lightbulb className="h-4 w-4" />
              <AlertDescription>
                Using similar product patterns to forecast demand for new products with no history.
              </AlertDescription>
            </Alert>

            {/* Similar Products List */}
            <div className="space-y-2">
              <h4 className="text-sm font-semibold">Most Similar Products</h4>
              {similarProducts.map((product) => (
                <div key={product.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="text-sm font-medium">{product.name}</div>
                    <Badge variant="outline" className="text-xs">
                      {product.similarity}% match
                    </Badge>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Avg: {product.avgSales} units/month
                  </div>
                </div>
              ))}
            </div>

            {/* Weighted Average Forecast */}
            <div className="p-4 bg-gradient-to-r from-purple-500/10 to-blue-500/10 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Weighted Forecast</span>
                <Target className="h-4 w-4 text-purple-500" />
              </div>
              <div className="text-2xl font-bold">425 units/month</div>
              <div className="text-xs text-muted-foreground mt-1">
                Based on similarity-weighted average of comparable products
              </div>
            </div>
          </TabsContent>

          <TabsContent value="category" className="space-y-4">
            <Alert>
              <Package className="h-4 w-4" />
              <AlertDescription>
                Applying category-level seasonal patterns to new product forecast.
              </AlertDescription>
            </Alert>

            {/* Category Pattern Chart */}
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={categoryPatterns}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="month" stroke="#888" />
                  <YAxis stroke="#888" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="skincare"
                    stroke="#8b5cf6"
                    strokeWidth={2}
                    name="Skincare"
                  />
                  <Line
                    type="monotone"
                    dataKey="haircare"
                    stroke="#3b82f6"
                    strokeWidth={2}
                    name="Haircare"
                  />
                  <Line
                    type="monotone"
                    dataKey="makeup"
                    stroke="#10b981"
                    strokeWidth={2}
                    name="Makeup"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-muted/50 rounded-lg">
                <div className="text-xs text-muted-foreground">Category Growth</div>
                <div className="text-lg font-bold text-green-500">+15.3%</div>
                <div className="text-xs text-muted-foreground">YoY trend</div>
              </div>
              <div className="p-3 bg-muted/50 rounded-lg">
                <div className="text-xs text-muted-foreground">Seasonality Index</div>
                <div className="text-lg font-bold">1.18</div>
                <div className="text-xs text-muted-foreground">Current month</div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="ramp" className="space-y-4">
            <Alert>
              <TrendingUp className="h-4 w-4" />
              <AlertDescription>
                Typical ramp-up pattern for new product launches based on historical launches.
              </AlertDescription>
            </Alert>

            {/* Ramp-Up Curve */}
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={rampUpData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="week" stroke="#888" />
                  <YAxis stroke="#888" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                  />
                  <Area
                    type="monotone"
                    dataKey="upper"
                    stackId="1"
                    stroke="transparent"
                    fill="#8b5cf6"
                    fillOpacity={0.1}
                    name="Upper Bound"
                  />
                  <Area
                    type="monotone"
                    dataKey="forecast"
                    stackId="2"
                    stroke="#8b5cf6"
                    fill="#8b5cf6"
                    fillOpacity={0.4}
                    strokeWidth={2}
                    name="Forecast"
                  />
                  <Area
                    type="monotone"
                    dataKey="lower"
                    stackId="1"
                    stroke="transparent"
                    fill="#8b5cf6"
                    fillOpacity={0.1}
                    name="Lower Bound"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="text-center p-2 bg-muted/50 rounded">
                <div className="text-xs text-muted-foreground">Week 1-4</div>
                <div className="font-semibold">Launch Phase</div>
                <div className="text-xs text-amber-500">Slow adoption</div>
              </div>
              <div className="text-center p-2 bg-muted/50 rounded">
                <div className="text-xs text-muted-foreground">Week 5-8</div>
                <div className="font-semibold">Growth Phase</div>
                <div className="text-xs text-green-500">Rapid increase</div>
              </div>
              <div className="text-center p-2 bg-muted/50 rounded">
                <div className="text-xs text-muted-foreground">Week 9-12</div>
                <div className="font-semibold">Maturity Phase</div>
                <div className="text-xs text-blue-500">Stabilization</div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Recommendations */}
        <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="h-4 w-4 text-amber-500" />
            <span className="font-semibold text-sm">Forecast Confidence: Medium</span>
          </div>
          <div className="text-xs text-muted-foreground space-y-1">
            <div>• New product forecasts have higher uncertainty (±30-40%)</div>
            <div>• Monitor actual sales closely in first 4 weeks</div>
            <div>• Adjust forecast based on early adoption rate</div>
            <div>• Consider promotional activities to accelerate ramp-up</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}