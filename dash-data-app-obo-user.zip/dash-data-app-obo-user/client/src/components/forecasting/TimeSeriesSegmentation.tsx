import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BarChart3, Clock, TrendingUp, Activity, Info } from 'lucide-react';
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';

interface TimeSeriesSegmentationProps {
  productId: string;
  locationId: string;
  data: any;
  isLoading: boolean;
}

export function TimeSeriesSegmentation({
  productId,
  locationId,
  data,
  isLoading
}: TimeSeriesSegmentationProps) {
  // Mock data for different time series lengths
  const segmentationData = [
    {
      category: 'Short (<3 months)',
      count: data?.short || 15,
      percentage: 15,
      color: '#ef4444',
      models: ['Simple Average', 'Naive', 'Linear Regression'],
      accuracy: 72
    },
    {
      category: 'Medium (3-12 months)',
      count: data?.medium || 45,
      percentage: 45,
      color: '#f59e0b',
      models: ['ARIMA', 'Exponential Smoothing', 'Simple Seasonal'],
      accuracy: 85
    },
    {
      category: 'Long (>12 months)',
      count: data?.long || 40,
      percentage: 40,
      color: '#10b981',
      models: ['Prophet', 'LSTM', 'Full Seasonal', 'Ensemble'],
      accuracy: 94
    }
  ];

  // Sample forecast comparison for different history lengths
  const forecastComparison = [
    { month: 'Jan', short: 100, medium: 95, long: 98, actual: 97 },
    { month: 'Feb', short: 110, medium: 102, long: 103, actual: 104 },
    { month: 'Mar', short: 95, medium: 108, long: 107, actual: 106 },
    { month: 'Apr', short: 120, medium: 115, long: 114, actual: 115 },
    { month: 'May', short: 105, medium: 118, long: 120, actual: 119 },
    { month: 'Jun', short: 130, medium: 125, long: 123, actual: 124 }
  ];

  const totalSeries = segmentationData.reduce((sum, seg) => sum + seg.count, 0);

  return (
    <div className="space-y-6">
      {/* Overview Card */}
      <Card className={`${isLoading ? 'animate-pulse' : ''}`}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-purple-500" />
            Time Series Segmentation Analysis
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Summary Stats */}
          <div className="grid grid-cols-4 gap-4">
            <div className="text-center p-3 bg-muted/50 rounded">
              <div className="text-2xl font-bold">{totalSeries}</div>
              <div className="text-xs text-muted-foreground">Total Series</div>
            </div>
            <div className="text-center p-3 bg-red-500/10 rounded">
              <div className="text-2xl font-bold text-red-500">{data?.short || 15}</div>
              <div className="text-xs text-muted-foreground">Short Series</div>
            </div>
            <div className="text-center p-3 bg-amber-500/10 rounded">
              <div className="text-2xl font-bold text-amber-500">{data?.medium || 45}</div>
              <div className="text-xs text-muted-foreground">Medium Series</div>
            </div>
            <div className="text-center p-3 bg-green-500/10 rounded">
              <div className="text-2xl font-bold text-green-500">{data?.long || 40}</div>
              <div className="text-xs text-muted-foreground">Long Series</div>
            </div>
          </div>

          {/* Distribution Chart */}
          <div className="grid grid-cols-2 gap-4">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={segmentationData}
                    dataKey="count"
                    nameKey="category"
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    label={({ percentage }) => `${percentage}%`}
                  >
                    {segmentationData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={segmentationData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="category" stroke="#888" angle={-45} textAnchor="end" height={80} />
                  <YAxis stroke="#888" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                  />
                  <Bar dataKey="accuracy" fill="#8b5cf6" name="Accuracy %" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Model Selection by Segment */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold">Model Selection by History Length</h4>
            {segmentationData.map((segment) => (
              <div key={segment.category} className="p-3 bg-muted/30 rounded-lg space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded" style={{ backgroundColor: segment.color }} />
                    <span className="font-medium">{segment.category}</span>
                    <Badge variant="outline">{segment.count} series</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Activity className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{segment.accuracy}% accuracy</span>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  {segment.models.map(model => (
                    <Badge key={model} variant="secondary" className="text-xs">
                      {model}
                    </Badge>
                  ))}
                </div>
                <Progress value={segment.accuracy} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Forecast Comparison by History Length */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-blue-500" />
            Forecast Accuracy by History Length
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={forecastComparison}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="month" stroke="#888" />
                <YAxis stroke="#888" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="actual"
                  stroke="#ffffff"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  name="Actual"
                />
                <Line
                  type="monotone"
                  dataKey="short"
                  stroke="#ef4444"
                  strokeWidth={2}
                  name="Short History"
                />
                <Line
                  type="monotone"
                  dataKey="medium"
                  stroke="#f59e0b"
                  strokeWidth={2}
                  name="Medium History"
                />
                <Line
                  type="monotone"
                  dataKey="long"
                  stroke="#10b981"
                  strokeWidth={2}
                  name="Long History"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <Alert className="mt-4">
            <Info className="h-4 w-4" />
            <AlertDescription>
              <strong>Key Insights:</strong>
              <ul className="mt-2 space-y-1 text-xs">
                <li>• Long history {"(>12 months)"} provides {segmentationData[2].accuracy}% accuracy using advanced models</li>
                <li>• Medium history (3-12 months) achieves {segmentationData[1].accuracy}% accuracy with seasonal patterns</li>
                <li>• Short history {"(<3 months)"} limited to {segmentationData[0].accuracy}% accuracy using simple methods</li>
                <li>• Consider using similar product patterns for short history items</li>
              </ul>
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-amber-500" />
            Segmentation Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {segmentationData[0].count > 10 && (
            <Alert className="border-red-500/50">
              <AlertDescription>
                <strong>Short Series Alert:</strong> {segmentationData[0].count} products have less than 3 months of history.
                Consider using category-level patterns or similar product matching for better accuracy.
              </AlertDescription>
            </Alert>
          )}
          {segmentationData[2].count < 30 && (
            <Alert className="border-amber-500/50">
              <AlertDescription>
                <strong>Data Collection:</strong> Only {segmentationData[2].percentage}% of products have sufficient history
                for advanced forecasting. Continue collecting data to improve model performance.
              </AlertDescription>
            </Alert>
          )}
          <div className="text-sm text-muted-foreground">
            Optimal distribution: 10% short, 30% medium, 60% long history for best overall accuracy.
          </div>
        </CardContent>
      </Card>
    </div>
  );
}