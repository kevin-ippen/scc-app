import { useQuery } from '@tanstack/react-query';
import { Package, AlertTriangle, BarChart3, Clock } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface CategoryPerformance {
  category: string;
  stockUnits: number;
  forecastAccuracy: number;
  reorderLevel: number;
  status: 'healthy' | 'warning' | 'critical';
}

interface InventoryMetrics {
  currentStockLevels: number;
  inventoryTurnoverRate: number;
  lowStockAlerts: number;
  expiredStockValue: number;
  avgDaysOnHand: number;
  categoryPerformance: CategoryPerformance[];
}

const fetchInventoryMetrics = async (): Promise<InventoryMetrics> => {
  const response = await fetch('/api/dashboard/inventory-health');
  if (!response.ok) {
    throw new Error('Failed to fetch inventory metrics');
  }
  return response.json();
};

export function InventoryHealth() {
  const { 
    data: metrics, 
    isLoading, 
    error 
  } = useQuery({
    queryKey: ['inventory-health'],
    queryFn: fetchInventoryMetrics,
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'text-green-600 bg-green-100';
      case 'warning': return 'text-yellow-600 bg-yellow-100';
      case 'critical': return 'text-red-600 bg-red-100';
      default: return 'text-muted-foreground bg-muted';
    }
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('en-US').format(num);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  if (error) {
    return (
      <Card className="bg-card/50 backdrop-blur-sm border-destructive/20">
        <CardContent className="p-6">
          <div className="flex items-center space-x-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            <span>Failed to load inventory metrics</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card/50 backdrop-blur-sm border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2 text-foreground">
          <Package className="h-5 w-5 text-blue-400" />
          <span>Inventory Health</span>
        </CardTitle>
        <CardDescription>
          Real-time inventory status and category performance
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Inventory KPIs Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
            <div className="flex items-center justify-center mb-2">
              <Package className="h-4 w-4 text-blue-400" />
            </div>
            <div className="text-2xl font-bold text-foreground">
              {isLoading ? '...' : formatNumber(metrics?.currentStockLevels ?? 0)}
            </div>
            <div className="text-xs text-muted-foreground">Stock Units</div>
          </div>

          <div className="text-center p-3 rounded-lg bg-green-500/10 border border-green-500/20">
            <div className="flex items-center justify-center mb-2">
              <BarChart3 className="h-4 w-4 text-green-400" />
            </div>
            <div className="text-2xl font-bold text-foreground">
              {isLoading ? '...' : `${metrics?.inventoryTurnoverRate ?? 0}x`}
            </div>
            <div className="text-xs text-muted-foreground">Turnover Rate</div>
          </div>

          <div className="text-center p-3 rounded-lg bg-orange-500/10 border border-orange-500/20">
            <div className="flex items-center justify-center mb-2">
              <AlertTriangle className="h-4 w-4 text-orange-400" />
            </div>
            <div className="text-2xl font-bold text-foreground">
              {isLoading ? '...' : formatNumber(metrics?.lowStockAlerts ?? 0)}
            </div>
            <div className="text-xs text-muted-foreground">Low Stock</div>
          </div>

          <div className="text-center p-3 rounded-lg bg-purple-500/10 border border-purple-500/20">
            <div className="flex items-center justify-center mb-2">
              <Clock className="h-4 w-4 text-purple-400" />
            </div>
            <div className="text-2xl font-bold text-foreground">
              {isLoading ? '...' : `${metrics?.avgDaysOnHand ?? 0} days`}
            </div>
            <div className="text-xs text-muted-foreground">Avg Days on Hand</div>
          </div>
        </div>

        {/* Category Performance Table */}
        <div>
          <h4 className="text-sm font-semibold text-foreground mb-3">Category Performance</h4>
          <div className="space-y-2">
            <div className="grid grid-cols-5 gap-4 text-xs font-medium text-muted-foreground pb-2 border-b border-border/30">
              <div>Category</div>
              <div className="text-right">Stock Units</div>
              <div className="text-right">Accuracy</div>
              <div className="text-right">Reorder Level</div>
              <div className="text-center">Status</div>
            </div>
            
            {isLoading ? (
              <div className="space-y-2">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="grid grid-cols-5 gap-4 py-2 animate-pulse">
                    <div className="h-4 bg-muted/30 rounded"></div>
                    <div className="h-4 bg-muted/30 rounded"></div>
                    <div className="h-4 bg-muted/30 rounded"></div>
                    <div className="h-4 bg-muted/30 rounded"></div>
                    <div className="h-4 bg-muted/30 rounded"></div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {metrics?.categoryPerformance?.map((category, index) => (
                  <div key={index} className="grid grid-cols-5 gap-4 py-2 text-sm hover:bg-muted/20 rounded-md px-2">
                    <div className="text-foreground font-medium">{category.category}</div>
                    <div className="text-right text-foreground">{formatNumber(category.stockUnits)}</div>
                    <div className="text-right text-foreground">{category.forecastAccuracy}%</div>
                    <div className="text-right text-foreground">{formatNumber(category.reorderLevel)}</div>
                    <div className="text-center">
                      <Badge variant="outline" className={getStatusColor(category.status)}>
                        {category.status}
                      </Badge>
                    </div>
                  </div>
                )) ?? (
                  <div className="py-8 text-center text-muted-foreground">
                    No category data available
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Additional Metrics */}
        <div className="flex justify-between items-center pt-4 border-t border-border/30">
          <div className="text-sm">
            <span className="text-muted-foreground">Expired Stock Value: </span>
            <span className="text-red-400 font-medium">
              {isLoading ? '...' : formatCurrency(metrics?.expiredStockValue ?? 0)}
            </span>
          </div>
          <div className="text-xs text-muted-foreground">
            Updated every 30 seconds
          </div>
        </div>
      </CardContent>
    </Card>
  );
}