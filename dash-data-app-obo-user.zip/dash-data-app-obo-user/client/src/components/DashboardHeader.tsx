import { PersonaSwitcher } from './PersonaSwitcher';
import { ThemeToggle } from './ThemeToggle';

interface DashboardHeaderProps {
  lastUpdated?: string;
  onRefresh?: () => void;
  isLoading?: boolean;
}

export function DashboardHeader({ 
  lastUpdated, 
  onRefresh, 
  isLoading = false 
}: DashboardHeaderProps) {
  const formatLastUpdated = (timestamp?: string) => {
    if (!timestamp) return 'Never';
    
    try {
      const date = new Date(timestamp);
      return date.toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
        timeZoneName: 'short'
      });
    } catch {
      return 'Invalid date';
    }
  };

  return (
    <div className="flex items-center justify-between mb-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">
          Supply Chain Analytics
        </h1>
        <p className="text-muted-foreground text-lg">
          Enterprise-scale demand forecasting platform
        </p>
      </div>
      
      <div className="flex items-center gap-4">
        <ThemeToggle />
        <PersonaSwitcher />
      </div>
    </div>
  );
}