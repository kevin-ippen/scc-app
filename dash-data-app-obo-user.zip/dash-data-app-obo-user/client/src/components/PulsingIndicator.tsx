import { cn } from '@/lib/utils';

interface PulsingIndicatorProps {
  size?: 'sm' | 'md' | 'lg';
  color?: 'green' | 'blue' | 'purple' | 'orange' | 'red';
  className?: string;
  label?: string;
}

const sizeClasses = {
  sm: 'w-2 h-2',
  md: 'w-3 h-3', 
  lg: 'w-4 h-4'
};

const colorClasses = {
  green: 'bg-green-500',
  blue: 'bg-blue-500',
  purple: 'bg-purple-500',
  orange: 'bg-orange-500',
  red: 'bg-red-500'
};

export function PulsingIndicator({ 
  size = 'md',
  color = 'green',
  className,
  label = "Live"
}: PulsingIndicatorProps) {
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div className={cn(
        "rounded-full animate-pulse",
        sizeClasses[size],
        colorClasses[color]
      )}></div>
      {label && (
        <span className="text-sm text-muted-foreground">{label}</span>
      )}
    </div>
  );
}