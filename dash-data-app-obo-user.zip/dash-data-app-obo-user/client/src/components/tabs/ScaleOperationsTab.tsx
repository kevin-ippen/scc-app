import { useQuery } from '@tanstack/react-query';
import { Activity, Cpu, Gauge, DollarSign, Zap, Server } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MetricCard } from '@/components/MetricCard';
import { AnimatedCounter } from '@/components/AnimatedCounter';
import { PulsingIndicator } from '@/components/PulsingIndicator';

interface ScaleMetrics {
  timestamp: string;
  realtime_metrics: {
    active_jobs: number;
    forecasts_per_second: number;
    total_forecasts_today: number;
    cluster_utilization_percent: number;
    queue_depth: number;
    avg_latency_ms: number;
  };
  parallel_jobs: Array<{
    job_id: string;
    job_name: string;
    forecasts_processed: number;
    compute_nodes: number;
    status: string;
    throughput_per_second: number;
  }>;
  cluster_metrics: {
    total_nodes: number;
    active_nodes: number;
    cpu_utilization: number;
    memory_utilization: number;
  };
  cost_metrics: {
    cost_per_1k_forecasts: number;
    cost_savings_traditional: number;
    efficiency_factor: number;
  };
}

const fetchScaleMetrics = async (): Promise<ScaleMetrics> => {
  const response = await fetch('/api/supply-chain/scale-metrics');
  if (!response.ok) {
    throw new Error('Failed to fetch scale metrics');
  }
  return response.json();
};

const formatNumber = (num: number) => {
  if (num >= 1e9) return `${(num / 1e9).toFixed(1)}B`;
  if (num >= 1e6) return `${(num / 1e6).toFixed(1)}M`;
  if (num >= 1e3) return `${(num / 1e3).toFixed(1)}K`;
  return num.toLocaleString();
};

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 4,
    maximumFractionDigits: 4,
  }).format(amount);
};

export function ScaleOperationsTab() {
  const { data: metrics, isLoading } = useQuery({
    queryKey: ['scale-metrics'],
    queryFn: fetchScaleMetrics,
    refetchInterval: 3000, // Refresh every 3 seconds for live feel
  });

  return (
    <div className="space-y-6">
      {/* Hero Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <MetricCard
          title="Active Parallel Jobs"
          value={metrics ? formatNumber(metrics.realtime_metrics.active_jobs) : '0'}
          icon={Activity}
          className={`${isLoading ? 'animate-pulse' : ''} bg-gradient-to-br from-blue-500/10 to-blue-600/10 border-blue-500/20`}
          trend={metrics ? 12.5 : 0}
          trendLabel="vs last hour"
        />
        
        <MetricCard
          title="Forecasts/Second"
          value={metrics ? formatNumber(metrics.realtime_metrics.forecasts_per_second) : '0'}
          icon={Zap}
          className={`${isLoading ? 'animate-pulse' : ''} bg-gradient-to-br from-green-500/10 to-green-600/10 border-green-500/20`}
          trend={metrics ? 8.3 : 0}
          trendLabel="throughput"
        />
        
        <MetricCard
          title="Daily Forecasts"
          value={metrics ? formatNumber(metrics.realtime_metrics.total_forecasts_today) : '0'}
          icon={Gauge}
          className={`${isLoading ? 'animate-pulse' : ''} bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/20`}
          trend={metrics ? 15.7 : 0}
          trendLabel="vs yesterday"
        />
      </div>

      {/* Processing Power & Cost */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <MetricCard
          title="Compute Nodes"
          value={metrics ? `${metrics.cluster_metrics.active_nodes}/${metrics.cluster_metrics.total_nodes}` : '0/0'}
          icon={Server}
          className={`${isLoading ? 'animate-pulse' : ''} bg-gradient-to-br from-orange-500/10 to-orange-600/10 border-orange-500/20`}
        />
        
        <MetricCard
          title="Cluster Utilization"
          value={metrics ? `${metrics.realtime_metrics.cluster_utilization_percent.toFixed(1)}%` : '0%'}
          icon={Cpu}
          className={`${isLoading ? 'animate-pulse' : ''} bg-gradient-to-br from-yellow-500/10 to-yellow-600/10 border-yellow-500/20`}
        />
        
        <MetricCard
          title="Cost per 1K Forecasts"
          value={metrics ? formatCurrency(metrics.cost_metrics.cost_per_1k_forecasts) : '$0.0000'}
          icon={DollarSign}
          className={`${isLoading ? 'animate-pulse' : ''} bg-gradient-to-br from-emerald-500/10 to-emerald-600/10 border-emerald-500/20`}
        />
      </div>

      {/* Live Job Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-card/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5 text-blue-500" />
              Live Job Stream
              <div className="ml-auto">
                <PulsingIndicator color="green" size="sm" label="Live" />
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {metrics?.parallel_jobs.slice(0, 6).map((job, index) => (
                <div key={job.job_id} className="flex items-center justify-between p-3 rounded-lg bg-background/50 border">
                  <div className="flex-1">
                    <div className="font-medium text-sm">{job.job_name}</div>
                    <div className="text-xs text-muted-foreground">
                      {formatNumber(job.forecasts_processed)} forecasts • {job.compute_nodes} nodes
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                      job.status === 'RUNNING' ? 'bg-green-500/20 text-green-400' :
                      job.status === 'COMPLETED' ? 'bg-blue-500/20 text-blue-400' :
                      'bg-yellow-500/20 text-yellow-400'
                    }`}>
                      {job.status}
                    </div>
                    <div className="text-sm font-medium">
                      {formatNumber(job.throughput_per_second)}/s
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gauge className="h-5 w-5 text-purple-500" />
              Performance Metrics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium">CPU Utilization</span>
                  <span className="text-sm text-muted-foreground">
                    {metrics?.cluster_metrics.cpu_utilization.toFixed(1)}%
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${metrics?.cluster_metrics.cpu_utilization || 0}%` }}
                  ></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium">Memory Utilization</span>
                  <span className="text-sm text-muted-foreground">
                    {metrics?.cluster_metrics.memory_utilization.toFixed(1)}%
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-green-500 to-green-600 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${metrics?.cluster_metrics.memory_utilization || 0}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mt-6">
                <div className="text-center p-3 rounded-lg bg-background/50">
                  <div className="text-2xl font-bold text-blue-500">
                    <AnimatedCounter 
                      to={metrics?.realtime_metrics.avg_latency_ms || 0}
                      formatFn={(val) => `${val.toFixed(1)}ms`}
                      duration={1500}
                    />
                  </div>
                  <div className="text-xs text-muted-foreground">Avg Latency</div>
                </div>
                <div className="text-center p-3 rounded-lg bg-background/50">
                  <div className="text-2xl font-bold text-green-500">
                    <AnimatedCounter 
                      to={metrics?.realtime_metrics.queue_depth || 0}
                      formatFn={formatNumber}
                      duration={1500}
                    />
                  </div>
                  <div className="text-xs text-muted-foreground">Queue Depth</div>
                </div>
              </div>

              <div className="pt-4 border-t">
                <div className="text-sm font-medium text-center mb-2">Cost Efficiency</div>
                <div className="text-center">
                  <div className="text-lg font-bold text-emerald-500">
                    {metrics?.cost_metrics.efficiency_factor.toFixed(0)}x faster
                  </div>
                  <div className="text-xs text-muted-foreground">
                    vs traditional systems
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}