import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Package,
  DollarSign,
  TrendingUp,
  AlertTriangle,
  GitBranch,
  BarChart3,
  Sparkles,
  Layers,
  Target,
  Activity,
  Table as TableIcon,
  Network,
  Calendar
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/components/ui/use-toast';
import { InventoryOptimization } from '@/components/optimization/InventoryOptimization';
import { PricingOptimization } from '@/components/optimization/PricingOptimization';
import { TimeSeriesSegmentation } from '@/components/forecasting/TimeSeriesSegmentation';
import { NewProductForecasting } from '@/components/forecasting/NewProductForecasting';
import { SpecialCasesForecasting } from '@/components/forecasting/SpecialCasesForecasting';
import { HierarchicalReconciliation } from '@/components/analytics/HierarchicalReconciliation';
import { OutlierDetection } from '@/components/analytics/OutlierDetection';
import { BusinessSummaryTable } from '@/components/tables/BusinessSummaryTable';
import { HierarchyExplorer } from '@/components/hierarchy/HierarchyExplorer';
import { MonthlyForecastTable } from '@/components/tables/MonthlyForecastTable';
import { mockProductForecasts, mockHierarchy, mockMonthlyForecasts, ProductForecast, HierarchyNode } from '@/data/mockForecastData';

// Mock data for products and locations
const mockProducts = [
  { id: 'PC-2157', name: 'PC-2157 - CALM Restoring Serum' },
  { id: 'PC-3842', name: 'PC-3842 - BHA Liquid Exfoliant' },
  { id: 'PC-1963', name: 'PC-1963 - Vitamin C Booster' },
  { id: 'PC-4521', name: 'PC-4521 - Niacinamide Treatment' },
  { id: 'PC-7893', name: 'PC-7893 - Retinol Complex' },
  { id: 'PC-5234', name: 'PC-5234 - Hyaluronic Acid Serum' },
  { id: 'PC-NEW-001', name: 'PC-NEW-001 - NEW: Peptide Cream (No History)' },
  { id: 'PC-NEW-002', name: 'PC-NEW-002 - NEW: Vitamin E Oil (2 months)' }
];

const mockLocations = [
  { id: 'DC-East', name: 'DC-East - Distribution Center' },
  { id: 'DC-West', name: 'DC-West - Distribution Center' },
  { id: 'Store-NYC', name: 'Store-NYC - Manhattan Flagship' },
  { id: 'Store-LA', name: 'Store-LA - Beverly Hills' },
  { id: 'Store-Chicago', name: 'Store-Chicago - Michigan Ave' },
  { id: 'Warehouse-Central', name: 'Warehouse-Central - Kansas City' }
];

interface AdvancedAnalyticsData{
  timestamp: string;
  optimization: {
    inventory: any;
    pricing: any;
  };
  forecasting: {
    timeSeries: any;
    newProducts: any;
    specialCases: any;
  };
  analytics: {
    reconciliation: any;
    outliers: any;
  };
}

const fetchAdvancedAnalytics = async (productId: string, locationId: string): Promise<AdvancedAnalyticsData> => {
  // Mock API call - in production, this would fetch from /api/advanced-analytics
  return {
    timestamp: new Date().toISOString(),
    optimization: {
      inventory: {
        currentStock: 150,
        optimalStock: 235,
        safetyStock: 85,
        reorderPoint: 120,
        reorderQuantity: 200
      },
      pricing: {
        currentPrice: 29.99,
        optimalPrice: 34.99,
        elasticity: -1.5,
        expectedRevenueIncrease: 15.3
      }
    },
    forecasting: {
      timeSeries: {
        short: 15,
        medium: 45,
        long: 40,
        total: 100
      },
      newProducts: {
        count: 8,
        methodUsed: 'Similar Product Matching'
      },
      specialCases: {
        sparse: 12,
        nonSeasonal: 23,
        irregular: 7
      }
    },
    analytics: {
      reconciliation: {
        topDown: 0.92,
        bottomUp: 0.88,
        optimal: 0.94
      },
      outliers: {
        detected: 5,
        impact: 'Medium'
      }
    }
  };
};

export function AdvancedAnalyticsTab() {
  const { toast } = useToast();
  const [selectedProduct, setSelectedProduct] = useState(mockProducts[0].id);
  const [selectedLocation, setSelectedLocation] = useState(mockLocations[0].id);
  const [activeSection, setActiveSection] = useState('optimization');

  const { data, isLoading } = useQuery({
    queryKey: ['advanced-analytics', selectedProduct, selectedLocation],
    queryFn: () => fetchAdvancedAnalytics(selectedProduct, selectedLocation),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Handlers for table interactions
  const handleRowSelect = (product: ProductForecast) => {
    toast({
      title: "Product Selected",
      description: `${product.product} - ${product.category}`,
    });
  };

  const handleNodeSelect = (node: HierarchyNode) => {
    toast({
      title: "Hierarchy Node Selected",
      description: `${node.type}: ${node.name}`,
    });
  };

  return (
    <div className="space-y-6">
      {/* Header with Filters */}
      <Card className="bg-gradient-to-r from-purple-500/10 via-blue-500/10 to-green-500/10 border-purple-500/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-purple-500" />
            Advanced Analytics & Optimization
            <span className="ml-2 px-2 py-0.5 text-xs font-semibold bg-amber-500/20 text-amber-300 rounded">Start Here</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <div className="flex items-center gap-2">
              <label className="text-sm font-medium text-blue-300">Product:</label>
              <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                <SelectTrigger className="w-64 bg-background/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {mockProducts.map(product => (
                    <SelectItem key={product.id} value={product.id}>
                      {product.name}
                      {product.id.includes('NEW') && (
                        <Badge className="ml-2" variant="secondary">New</Badge>
                      )}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-2">
              <label className="text-sm font-medium text-blue-300">Location:</label>
              <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                <SelectTrigger className="w-64 bg-background/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {mockLocations.map(location => (
                    <SelectItem key={location.id} value={location.id}>
                      {location.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-4 gap-4 mt-4">
            <div className="text-center p-3 bg-background/50 rounded">
              <div className="text-2xl font-bold text-green-500">
                {data?.optimization.inventory.optimalStock || 0}
              </div>
              <div className="text-xs text-muted-foreground">Optimal Stock</div>
            </div>
            <div className="text-center p-3 bg-background/50 rounded">
              <div className="text-2xl font-bold text-blue-500">
                ${data?.optimization.pricing.optimalPrice || 0}
              </div>
              <div className="text-xs text-muted-foreground">Optimal Price</div>
            </div>
            <div className="text-center p-3 bg-background/50 rounded">
              <div className="text-2xl font-bold text-purple-500">
                {data?.forecasting.timeSeries.total || 0}%
              </div>
              <div className="text-xs text-muted-foreground">Forecast Coverage</div>
            </div>
            <div className="text-center p-3 bg-background/50 rounded">
              <div className="text-2xl font-bold text-amber-500">
                {data?.analytics.outliers.detected || 0}
              </div>
              <div className="text-xs text-muted-foreground">Outliers Detected</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Content Tabs */}
      <Tabs defaultValue="optimization" className="space-y-4">
        <TabsList className="grid w-full grid-cols-8 gap-1">
          <TabsTrigger value="summary">
            <TableIcon className="h-4 w-4 mr-2" />
            Summary
          </TabsTrigger>
          <TabsTrigger value="hierarchy">
            <Network className="h-4 w-4 mr-2" />
            Hierarchy
          </TabsTrigger>
          <TabsTrigger value="monthly">
            <Calendar className="h-4 w-4 mr-2" />
            Monthly
          </TabsTrigger>
          <TabsTrigger value="optimization">
            <Target className="h-4 w-4 mr-2" />
            Optimization
          </TabsTrigger>
          <TabsTrigger value="segmentation">
            <BarChart3 className="h-4 w-4 mr-2" />
            Time Series
          </TabsTrigger>
          <TabsTrigger value="special-cases">
            <Activity className="h-4 w-4 mr-2" />
            Special Cases
          </TabsTrigger>
          <TabsTrigger value="reconciliation">
            <GitBranch className="h-4 w-4 mr-2" />
            Reconciliation
          </TabsTrigger>
          <TabsTrigger value="outliers">
            <AlertTriangle className="h-4 w-4 mr-2" />
            Outliers
          </TabsTrigger>
        </TabsList>

        {/* Business Summary Table */}
        <TabsContent value="summary" className="space-y-4">
          <Card className="bg-card/50 border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TableIcon className="h-5 w-5 text-blue-500" />
                Product Forecast Summary
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Compare forecasts across products with sortable columns, stock risk indicators, and accuracy metrics.
              </p>
            </CardHeader>
            <CardContent>
              <BusinessSummaryTable
                data={mockProductForecasts}
                onRowSelect={handleRowSelect}
                isLoading={false}
              />
            </CardContent>
          </Card>
        </TabsContent>

        {/* Hierarchy Explorer */}
        <TabsContent value="hierarchy" className="space-y-4">
          <div className="space-y-4">
            <Alert className="bg-purple-500/10 border-purple-500/30">
              <Network className="h-4 w-4" />
              <AlertDescription className="text-sm">
                <span className="font-semibold">Navigation:</span> Click to expand categories and brands.
                All levels show aggregated metrics rolling up from SKU level.
              </AlertDescription>
            </Alert>
            <HierarchyExplorer
              data={mockHierarchy}
              onNodeSelect={handleNodeSelect}
              defaultExpanded={['target-partner']}
            />
          </div>
        </TabsContent>

        {/* Monthly Forecast Table */}
        <TabsContent value="monthly" className="space-y-4">
          <Card className="bg-card/50 border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-green-500" />
                Monthly Forecast Breakdown
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                View month-by-month forecasts for all products. Scroll horizontally to see future months.
              </p>
            </CardHeader>
            <CardContent>
              <MonthlyForecastTable
                data={mockMonthlyForecasts}
                isLoading={false}
              />
            </CardContent>
          </Card>
        </TabsContent>

        {/* Existing Analytics Tabs */}
        <TabsContent value="optimization" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <InventoryOptimization
              productId={selectedProduct}
              locationId={selectedLocation}
              data={data?.optimization.inventory}
              isLoading={isLoading}
            />
            <PricingOptimization
              productId={selectedProduct}
              locationId={selectedLocation}
              data={data?.optimization.pricing}
              isLoading={isLoading}
            />
          </div>
        </TabsContent>

        <TabsContent value="segmentation" className="space-y-6">
          <TimeSeriesSegmentation
            productId={selectedProduct}
            locationId={selectedLocation}
            data={data?.forecasting.timeSeries}
            isLoading={isLoading}
          />
          <NewProductForecasting
            productId={selectedProduct}
            locationId={selectedLocation}
            data={data?.forecasting.newProducts}
            isLoading={isLoading}
          />
        </TabsContent>

        <TabsContent value="special-cases" className="space-y-6">
          <SpecialCasesForecasting
            productId={selectedProduct}
            locationId={selectedLocation}
            data={data?.forecasting.specialCases}
            isLoading={isLoading}
          />
        </TabsContent>

        <TabsContent value="reconciliation" className="space-y-6">
          <HierarchicalReconciliation
            productId={selectedProduct}
            locationId={selectedLocation}
            data={data?.analytics.reconciliation}
            isLoading={isLoading}
          />
        </TabsContent>

        <TabsContent value="outliers" className="space-y-6">
          <OutlierDetection
            productId={selectedProduct}
            locationId={selectedLocation}
            data={data?.analytics.outliers}
            isLoading={isLoading}
          />
        </TabsContent>
      </Tabs>

      {/* Alert for new products */}
      {selectedProduct.includes('NEW') && (
        <Alert className="bg-amber-500/10 border-amber-500/30">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            This is a new product with limited or no historical data.
            Using similar product matching and category-level patterns for forecasting.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}