import { useQuery } from '@tanstack/react-query';
import { DollarSign, Clock, TrendingUp, Calculator, Award, Zap, Activity } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MetricCard } from '@/components/MetricCard';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useState, ReactNode } from 'react';

interface BusinessImpactData {
  timestamp: string;
  roi_metrics: {
    annual_cost_savings: number;
    investment_payback_months: number;
    efficiency_improvement: number;
    roi_percentage: number;
  };
  processing_comparison: {
    traditional_time_hours: number;
    databricks_time_minutes: number;
    speed_improvement_factor: number;
  };
  cost_efficiency: {
    cost_per_forecast_databricks: number;
    cost_per_forecast_traditional: number;
    cost_savings_per_million: number;
  };
  scale_simulator: {
    current_volume: number;
    max_capacity: number;
    scaling_scenarios: Array<{
      scenario: string;
      volume_multiplier: number;
      processing_time: string;
      cost_estimate: number;
    }>;
  };
  business_value: {
    inventory_optimization: number;
    demand_accuracy_improvement: number;
    stockout_reduction: number;
    customer_satisfaction_score: number;
  };
}

const fetchBusinessImpact = async (): Promise<BusinessImpactData> => {
  const response = await fetch('/api/supply-chain/business-impact');
  if (!response.ok) {
    throw new Error('Failed to fetch business impact data');
  }
  return response.json();
};

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

const formatCurrencyPrecise = (amount: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 4,
    maximumFractionDigits: 4,
  }).format(amount);
};

const formatNumber = (num: number) => {
  if (num >= 1e9) return `${(num / 1e9).toFixed(1)}B`;
  if (num >= 1e6) return `${(num / 1e6).toFixed(1)}M`;
  if (num >= 1e3) return `${(num / 1e3).toFixed(1)}K`;
  return num.toLocaleString();
};

interface BusinessImpactTabProps {
  inventoryHealth?: ReactNode;
}

export function BusinessImpactTab({ inventoryHealth }: BusinessImpactTabProps) {
  const [selectedScenario, setSelectedScenario] = useState(0);

  const { data: impact, isLoading } = useQuery({
    queryKey: ['business-impact'],
    queryFn: fetchBusinessImpact,
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  return (
    <div className="space-y-6">
      {/* ROI Hero Section */}
      <Card className="bg-gradient-to-r from-emerald-500/10 via-green-500/10 to-teal-500/10 border-emerald-500/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-center justify-center">
            <Award className="h-6 w-6 text-emerald-500" />
            Annual Business Impact
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-emerald-500 mb-1">
                {impact ? formatCurrency(impact.roi_metrics.annual_cost_savings) : '$0'}
              </div>
              <div className="text-sm text-muted-foreground">Annual Savings</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-500 mb-1">
                {impact?.roi_metrics.investment_payback_months || 0} months
              </div>
              <div className="text-sm text-muted-foreground">Payback Period</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-500 mb-1">
                {impact?.roi_metrics.efficiency_improvement || 0}%
              </div>
              <div className="text-sm text-muted-foreground">Efficiency Gain</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-500 mb-1">
                {impact?.roi_metrics.roi_percentage || 0}%
              </div>
              <div className="text-sm text-muted-foreground">ROI</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Impact Metrics - 2 column grid for symmetry */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <MetricCard
          title="Cost per Forecast"
          value={impact ? formatCurrencyPrecise(impact.cost_efficiency.cost_per_forecast_databricks) : '$0.0000'}
          icon={DollarSign}
          className={`${isLoading ? 'animate-pulse' : ''} bg-gradient-to-br from-green-500/10 to-green-600/10 border-green-500/20`}
        />

        <MetricCard
          title="Inventory Optimization"
          value={impact ? formatCurrency(impact.business_value.inventory_optimization) : '$0'}
          icon={TrendingUp}
          className={`${isLoading ? 'animate-pulse' : ''} bg-gradient-to-br from-blue-500/10 to-blue-600/10 border-blue-500/20`}
        />
      </div>

      {/* Inventory Health component - positioned above Processing Time Comparison */}
      {inventoryHealth && (
        <div className="mb-6">
          {inventoryHealth}
        </div>
      )}

      {/* Processing Time Comparison & Scale Simulator - Equal 2 column grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-card/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-orange-500" />
              Processing Time Comparison
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Traditional System */}
              <div className="flex justify-between items-center p-3 rounded-lg border border-red-500/20">
                <span className="font-medium text-red-400">Traditional Systems</span>
                <span className="text-lg font-bold text-red-400">
                  {impact?.processing_comparison.traditional_time_hours?.toFixed(1) || '0.0'} hours
                </span>
              </div>

              {/* Databricks System */}
              <div className="flex justify-between items-center p-3 rounded-lg border border-green-500/20">
                <span className="font-medium text-green-400">Databricks Platform</span>
                <span className="text-lg font-bold text-green-400">
                  {impact?.processing_comparison.databricks_time_minutes?.toFixed(1) || '0.0'} minutes
                </span>
              </div>

              {/* Difference Calculations */}
              <div className="pt-4 border-t space-y-3">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-blue-500/10 rounded-lg">
                    <div className="text-sm text-muted-foreground mb-1">Time Saved</div>
                    <div className="text-xl font-bold text-blue-500">
                      {(() => {
                        const traditionalHours = impact?.processing_comparison.traditional_time_hours || 0;
                        const databricksHours = (impact?.processing_comparison.databricks_time_minutes || 0) / 60;
                        const difference = traditionalHours - databricksHours;
                        return difference.toFixed(1);
                      })()} hours
                    </div>
                  </div>
                  <div className="text-center p-3 bg-purple-500/10 rounded-lg">
                    <div className="text-sm text-muted-foreground mb-1">Reduction</div>
                    <div className="text-xl font-bold text-purple-500">
                      {(() => {
                        const traditionalHours = impact?.processing_comparison.traditional_time_hours || 1;
                        const databricksHours = (impact?.processing_comparison.databricks_time_minutes || 0) / 60;
                        const percentDiff = ((traditionalHours - databricksHours) / traditionalHours * 100);
                        return percentDiff.toFixed(1);
                      })()}%
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5 text-purple-500" />
              Interactive Scale Simulator
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-sm text-muted-foreground mb-4">
                Click on scenarios below to see their impact on processing time and cost
              </div>
              
              {impact?.scale_simulator.scaling_scenarios.map((scenario, index) => (
                <div key={scenario.scenario} 
                     className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                       selectedScenario === index 
                         ? 'border-purple-500 bg-purple-500/10' 
                         : 'border-border bg-background/50 hover:border-purple-500/50'
                     }`}
                     onClick={() => setSelectedScenario(index)}>
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="font-medium">{scenario.scenario}</div>
                      <div className="text-sm text-muted-foreground">
                        {scenario.volume_multiplier}x current volume
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">{scenario.processing_time}</div>
                      <div className="text-sm text-muted-foreground">
                        {formatCurrency(scenario.cost_estimate)}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {/* Selected Scenario Details */}
              {impact?.scale_simulator.scaling_scenarios[selectedScenario] && (
                <div className="mt-4 p-4 rounded-lg bg-purple-500/5 border-2 border-purple-500/20">
                  <div className="text-sm font-medium mb-3 text-purple-400">Selected Scenario Impact:</div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-xs text-muted-foreground">Processing Time</div>
                      <div className="text-lg font-bold text-purple-500">
                        {impact.scale_simulator.scaling_scenarios[selectedScenario].processing_time}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground">Cost Estimate</div>
                      <div className="text-lg font-bold text-emerald-500">
                        {formatCurrency(impact.scale_simulator.scaling_scenarios[selectedScenario].cost_estimate)}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground">Volume Multiplier</div>
                      <div className="text-lg font-bold text-blue-500">
                        {impact.scale_simulator.scaling_scenarios[selectedScenario].volume_multiplier}x
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground">Total Forecasts</div>
                      <div className="text-lg font-bold text-orange-500">
                        {formatNumber((impact?.scale_simulator.current_volume || 0) * impact.scale_simulator.scaling_scenarios[selectedScenario].volume_multiplier)}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="mt-6 p-4 rounded-lg bg-background/50 border">
                <div className="text-sm font-medium mb-2">Current Capacity:</div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-purple-500 to-purple-600 h-2 rounded-full"
                    style={{ width: `${((impact?.scale_simulator.current_volume || 0) / (impact?.scale_simulator.max_capacity || 1)) * 100}%` }}
                  ></div>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>{formatNumber(impact?.scale_simulator.current_volume || 0)} forecasts</span>
                  <span>{formatNumber(impact?.scale_simulator.max_capacity || 0)} max capacity</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Business Value Metrics - 4 equal columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-card/50 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Demand Accuracy</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-500 mb-1">
              +{impact?.business_value.demand_accuracy_improvement?.toFixed(1) || '0.0'}%
            </div>
            <div className="text-xs text-muted-foreground">Improvement vs. 30-day baseline</div>
          </CardContent>
        </Card>

        <Card className="bg-card/50 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Stockout Reduction</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500 mb-1">
              -{impact?.business_value.stockout_reduction?.toFixed(1) || '0.0'}%
            </div>
            <div className="text-xs text-muted-foreground">Fewer stockouts vs. 30-day baseline</div>
          </CardContent>
        </Card>

        <Card className="bg-card/50 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Customer Satisfaction</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-500 mb-1">
              {impact?.business_value.customer_satisfaction_score?.toFixed(1) || '0.0'}%
            </div>
            <div className="text-xs text-muted-foreground">Satisfaction score</div>
          </CardContent>
        </Card>

        <Card className="bg-card/50 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Cost Savings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-500 mb-1">
              {formatCurrency(impact?.cost_efficiency.cost_savings_per_million || 0)}
            </div>
            <div className="text-xs text-muted-foreground">Per million forecasts vs. traditional systems</div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
