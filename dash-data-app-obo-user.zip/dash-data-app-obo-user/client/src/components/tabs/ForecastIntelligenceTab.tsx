import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Brain, Target, Layers, Sparkles, Package, MapPin } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { MetricCard } from '@/components/MetricCard';
import { AnimatedCounter } from '@/components/AnimatedCounter';
import { ForecastAccuracy } from '@/components/ForecastAccuracy';
import { PredictedVsActual } from '@/components/PredictedVsActual';
import { EnhancedForecastChartWithOverrides } from '@/components/EnhancedForecastChartWithOverrides';
import { ForecastSummaryTable } from '@/components/ForecastSummaryTable';
import { ForecastOverridePanel } from '@/components/ForecastOverridePanel';
import { useToast } from '@/components/ui/use-toast';

// Mock data for products and locations
const mockProducts = [
  { id: 'total', name: 'Total Product' },
  { id: 'PC-2157', name: 'PC-2157 - CALM Restoring Serum' },
  { id: 'PC-3842', name: 'PC-3842 - BHA Liquid Exfoliant' },
  { id: 'PC-1963', name: 'PC-1963 - Vitamin C Booster' },
  { id: 'PC-4521', name: 'PC-4521 - Niacinamide Treatment' },
  { id: 'PC-7893', name: 'PC-7893 - Retinol Complex' },
];

const mockLocations = [
  { id: 'total', name: 'Total Location' },
  { id: 'DC-East', name: 'DC-East' },
  { id: 'DC-West', name: 'DC-West' },
  { id: 'Store-NYC', name: 'Store-NYC' },
  { id: 'Store-LA', name: 'Store-LA' },
  { id: 'Warehouse-Central', name: 'Warehouse-Central' },
];

interface ForecastIntelligenceData {
  timestamp: string;
  forecast_dimensions: {
    stores: number;
    skus: number;
    models: number;
    total_forecasts: number;
  };
  model_performance: Array<{
    model_type: string;
    accuracy_mape: number;
    processing_time_ms: number;
    forecasts_processed: number;
    confidence_score: number;
  }>;
  coverage_metrics: {
    geographic_coverage: number;
    product_coverage: number;
    seasonal_patterns_detected: number;
  };
  accuracy_trends?: Array<{
    date: string;
    prophet: number;
    arima: number;
    xgboost: number;
    lstm: number;
    ensemble: number;
  }>;
  forecast_chart_data: Array<{
    date: string;
    yhat: number;
    yhat_lower: number;
    yhat_upper: number;
  }>;
  enhanced_forecast_data?: Array<{
    date: string;
    actual_value: number | null;
    forecast_value: number;
    forecast_lower: number;
    forecast_upper: number;
    override_value: number | null;
    final_forecast: number;
    is_historical: boolean;
  }>;
  monthly_summary?: Array<{
    month: string;
    historical_value: number | null;
    forecast_value: number | null;
    variance: number | null;
    confidence: number | null;
    is_forecast: boolean;
  }>;
  override_metadata?: {
    total_overrides: number;
    active_overrides: number;
    sample_overrides: Array<{
      product_id: string;
      product_name: string;
      location: string;
      override_date: string;
      original_forecast: number;
      override_value: number;
      reason: string;
    }>;
    default_product: string;
    default_location: string;
  };
}

const fetchForecastIntelligence = async (): Promise<ForecastIntelligenceData> => {
  const response = await fetch('/api/supply-chain/forecast-intelligence');
  if (!response.ok) {
    throw new Error('Failed to fetch forecast intelligence data');
  }
  return response.json();
};

const formatNumber = (num: number) => {
  if (num >= 1e9) return `${(num / 1e9).toFixed(1)}B`;
  if (num >= 1e6) return `${(num / 1e6).toFixed(1)}M`;
  if (num >= 1e3) return `${(num / 1e3).toFixed(1)}K`;
  return num.toLocaleString();
};

export function ForecastIntelligenceTab() {
  const { toast } = useToast();

  // Filter State
  const [selectedProduct, setSelectedProduct] = useState('total');
  const [selectedLocation, setSelectedLocation] = useState('total');

  // Override Panel State (fixes undefined variable bug)
  const [selectedForecastDate, setSelectedForecastDate] = useState<string | null>(null);
  const [selectedDataPoint, setSelectedDataPoint] = useState<any | null>(null);

  const { data: intelligence, isLoading } = useQuery({
    queryKey: ['forecast-intelligence'],
    queryFn: fetchForecastIntelligence,
    // Auto-refresh removed - chart data will be static after initial load
  });

  // Derive data for Override Configuration Panel
  const chartData = intelligence?.enhanced_forecast_data || [];

  // Determine if showing filtered view (specific product/location selected, not "Total")
  const isFilteredView = selectedProduct !== 'total' || selectedLocation !== 'total';

  // Event Handlers for Override Configuration Panel
  const handleOverrideSave = async (override: any) => {
    console.log('Override save requested:', override);

    // Show progressive toast notifications to simulate LakeBase write
    toast({
      title: "Writing to LakeBase",
      description: "Saving forecast override to database...",
    });

    setTimeout(() => {
      toast({
        title: "Executing SQL",
        description: "INSERT INTO fe_shared_demo.forecast_overrides...",
      });
    }, 1000);

    setTimeout(() => {
      toast({
        title: "Writing Audit Log",
        description: "Recording override history and metadata...",
      });
    }, 2000);

    setTimeout(() => {
      toast({
        title: "Override Created Successfully",
        description: `Forecast override for ${override.date} has been saved.`,
      });
    }, 3000);
  };

  const handleOverrideCancel = () => {
    // Panel is always visible when filters are selected, no action needed
    console.log('Override cancelled');
  };

  return (
    <div className="space-y-6">
      {/* Scale Formula Hero - Compact */}
      <Card className="bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-pink-500/10 border-blue-500/30 shadow-lg shadow-blue-500/10">
        <CardContent className="py-6">
          <div className="text-center space-y-3">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Brain className="h-5 w-5 text-blue-400" />
              <h3 className="text-lg font-semibold text-foreground">Forecast Intelligence at Scale</h3>
            </div>
            <div className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              {intelligence?.forecast_dimensions.stores || 0} stores × {formatNumber(intelligence?.forecast_dimensions.skus || 0)} SKUs × {intelligence?.forecast_dimensions.models || 0} models = <AnimatedCounter to={intelligence?.forecast_dimensions.total_forecasts || 0} formatFn={formatNumber} duration={3000} /> forecasts
            </div>
            <div className="text-sm text-muted-foreground">
              Processing millions of demand predictions in parallel across Paula's Choice product portfolio
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Instructional Alert */}
      <Alert className="bg-blue-500/10 border-blue-500/30">
        <Brain className="h-4 w-4" />
        <AlertDescription className="text-sm">
          <span className="font-semibold">Getting Started:</span> Select a specific product and location below to view detailed forecasts and configure manual overrides. Default view shows aggregated totals.
        </AlertDescription>
      </Alert>

      {/* Product and Location Filters - Enhanced */}
      <Card className="sticky top-4 z-10 bg-card/50 backdrop-blur-sm border-blue-500/20 shadow-lg">
        <CardContent className="py-5">
          <div className="flex items-center gap-8 justify-center">
            <div className="flex items-center gap-3">
              <Package className="h-5 w-5 text-amber-400" />
              <label className="text-sm font-semibold">Product:</label>
              <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                <SelectTrigger className="w-72 hover:border-blue-500/50 transition-colors">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {mockProducts.map(product => (
                    <SelectItem key={product.id} value={product.id}>
                      {product.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="h-8 w-px bg-gradient-to-b from-transparent via-blue-500/30 to-transparent" />

            <div className="flex items-center gap-3">
              <MapPin className="h-5 w-5 text-red-400" />
              <label className="text-sm font-semibold">Location:</label>
              <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                <SelectTrigger className="w-72 hover:border-blue-500/50 transition-colors">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {mockLocations.map(location => (
                    <SelectItem key={location.id} value={location.id}>
                      {location.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <MetricCard
          title="Model Accuracy (MAPE)"
          value={intelligence ? `${intelligence.model_performance[0]?.accuracy_mape.toFixed(1)}%` : '0%'}
          icon={Target}
          className={`${isLoading ? 'animate-pulse' : ''} bg-gradient-to-br from-green-500/10 to-green-600/10 border-green-500/20`}
          trend={-2.3}
          trendLabel="improvement"
        />

        <MetricCard
          title="Geographic Coverage"
          value={intelligence ? `${intelligence.coverage_metrics.geographic_coverage.toFixed(1)}%` : '0%'}
          icon={Layers}
          className={`${isLoading ? 'animate-pulse' : ''} bg-gradient-to-br from-blue-500/10 to-blue-600/10 border-blue-500/20`}
        />

        <MetricCard
          title="Seasonal Patterns"
          value={intelligence ? formatNumber(intelligence.coverage_metrics.seasonal_patterns_detected) : '0'}
          icon={Sparkles}
          className={`${isLoading ? 'animate-pulse' : ''} bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/20`}
          trend={12.5}
          trendLabel="patterns detected"
        />
      </div>

      {/* Section Separator */}
      <div className="flex items-center gap-3 py-2">
        <div className="h-px flex-1 bg-gradient-to-r from-transparent via-blue-500/30 to-transparent" />
        <h3 className="text-xs font-semibold text-muted-foreground tracking-wider px-3">MODEL PERFORMANCE</h3>
        <div className="h-px flex-1 bg-gradient-to-r from-transparent via-blue-500/30 to-transparent" />
      </div>

      {/* Forecast Accuracy and Out-of-Sample Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Forecast Accuracy - Left Column */}
        <ForecastAccuracy />

        {/* Out-of-Sample Analysis - Right Column */}
        <PredictedVsActual />
      </div>

      {/* Section Separator */}
      <div className="flex items-center gap-3 py-2">
        <div className="h-px flex-1 bg-gradient-to-r from-transparent via-blue-500/30 to-transparent" />
        <h3 className="text-xs font-semibold text-muted-foreground tracking-wider px-3">FORECAST MANAGEMENT</h3>
        <div className="h-px flex-1 bg-gradient-to-r from-transparent via-blue-500/30 to-transparent" />
      </div>

      {/* Forecast Management - Chart and Monthly Summary */}
      {chartData.length > 0 ? (
        <div className="space-y-6">
          {/* Demand Forecast Analysis Chart */}
          <Card className="bg-card/50 backdrop-blur-sm border-blue-500/20">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    Forecast Management
                  </CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">
                    Statistical forecasts, manual overrides, and final predictions
                  </p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <EnhancedForecastChartWithOverrides
                data={chartData}
                showOverrides={true}
                onOverrideClick={(date) => {
                  const dataPoint = chartData.find(d => d.date === date);
                  setSelectedForecastDate(date);
                  setSelectedDataPoint(dataPoint);
                }}
              />
            </CardContent>
          </Card>

          {/* Monthly Forecast Summary Table */}
          <Card className="bg-card/50 backdrop-blur-sm border-blue-500/20">
            <CardHeader>
              <CardTitle>Monthly Forecast Summary</CardTitle>
              <p className="text-sm text-muted-foreground">
                Historical performance and future predictions by month
              </p>
            </CardHeader>
            <CardContent>
              <ForecastSummaryTable data={chartData} />
            </CardContent>
          </Card>
        </div>
      ) : (
        <Card className="bg-card/50 backdrop-blur-sm border-border/50">
          <CardContent className="py-12 text-center">
            <Sparkles className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-semibold mb-2">No Forecast Data Available</h3>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              Forecast data is currently being generated. Please check back shortly or refresh the page to load the latest predictions.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Forecast Override Configuration Panel - Only visible when specific product/location selected */}
      {isFilteredView && chartData.length > 0 && (
        <Card className="bg-card/50 backdrop-blur-sm border-amber-500/20">
          <CardContent className="p-6">
            <ForecastOverridePanel
              productId={selectedProduct}
              locationId={selectedLocation}
              forecastDate={selectedForecastDate ? new Date(selectedForecastDate) : new Date(chartData.filter(d => !d.is_historical)[0]?.date || new Date())}
              originalForecast={selectedDataPoint?.forecast_value || chartData.filter(d => !d.is_historical)[0]?.forecast_value || 0}
              onSave={handleOverrideSave}
              onCancel={handleOverrideCancel}
            />
          </CardContent>
        </Card>
      )}

    </div>
  );
}
