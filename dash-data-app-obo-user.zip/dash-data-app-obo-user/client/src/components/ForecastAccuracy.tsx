import { useQuery } from '@tanstack/react-query';
import { Target, TrendingUp, AlertCircle, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface ModelPerformance {
  modelName: string;
  mape: number;
  rmse: number;
  bias: number;
  accuracy: number;
  isActive: boolean;
}

interface AccuracyMetrics {
  overallMape: number;
  overallRmse: number;
  overallBias: number;
  overallAccuracy: number;
  modelPerformance: ModelPerformance[];
  lastCalculated: string;
}

const fetchAccuracyMetrics = async (): Promise<AccuracyMetrics> => {
  const response = await fetch('/api/dashboard/forecast-accuracy');
  if (!response.ok) {
    throw new Error('Failed to fetch accuracy metrics');
  }
  return response.json();
};

export function ForecastAccuracy() {
  const { 
    data: metrics, 
    isLoading, 
    error 
  } = useQuery({
    queryKey: ['forecast-accuracy'],
    queryFn: fetchAccuracyMetrics,
    refetchInterval: 60000, // Refresh every minute
  });

  const getAccuracyColor = (accuracy: number) => {
    if (accuracy >= 90) return 'text-green-600 bg-green-100';
    if (accuracy >= 80) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getMapeColor = (mape: number) => {
    if (mape <= 5) return 'text-green-600';
    if (mape <= 10) return 'text-yellow-600';
    return 'text-red-600';
  };

  const formatNumber = (num: number, decimals: number = 1) => {
    return num.toFixed(decimals);
  };

  if (error) {
    return (
      <Card className="bg-card/50 backdrop-blur-sm border-destructive/20">
        <CardContent className="p-6">
          <div className="flex items-center space-x-2 text-destructive">
            <AlertCircle className="h-5 w-5" />
            <span>Failed to load forecast accuracy metrics</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card/50 backdrop-blur-sm border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2 text-foreground">
          <Target className="h-5 w-5 text-purple-400" />
          <span>Forecast Accuracy</span>
        </CardTitle>
        <CardDescription>
          Model performance metrics and accuracy indicators
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Overall Accuracy Metrics Row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="text-center p-4 rounded-lg bg-purple-500/10 border border-purple-500/20">
            <div className="flex items-center justify-center mb-2">
              <Target className="h-4 w-4 text-purple-400" />
            </div>
            <div className="text-2xl font-bold text-foreground">
              {isLoading ? '...' : `${formatNumber(metrics?.overallAccuracy ?? 0, 1)}%`}
            </div>
            <div className="text-xs text-muted-foreground">Overall Accuracy</div>
          </div>

          <div className="text-center p-4 rounded-lg bg-blue-500/10 border border-blue-500/20">
            <div className="flex items-center justify-center mb-2">
              <TrendingUp className="h-4 w-4 text-blue-400" />
            </div>
            <div className={`text-2xl font-bold ${isLoading ? 'text-foreground' : getMapeColor(metrics?.overallMape ?? 0)}`}>
              {isLoading ? '...' : `${formatNumber(metrics?.overallMape ?? 0, 1)}%`}
            </div>
            <div className="text-xs text-muted-foreground">MAPE</div>
          </div>

          <div className="text-center p-4 rounded-lg bg-green-500/10 border border-green-500/20">
            <div className="flex items-center justify-center mb-2">
              <AlertCircle className="h-4 w-4 text-green-400" />
            </div>
            <div className="text-2xl font-bold text-foreground">
              {isLoading ? '...' : formatNumber(metrics?.overallRmse ?? 0, 0)}
            </div>
            <div className="text-xs text-muted-foreground">RMSE</div>
          </div>

          <div className="text-center p-4 rounded-lg bg-orange-500/10 border border-orange-500/20">
            <div className="flex items-center justify-center mb-2">
              <TrendingUp className="h-4 w-4 text-orange-400" />
            </div>
            <div className="text-2xl font-bold text-foreground">
              {isLoading ? '...' : `${metrics?.overallBias ?? 0 > 0 ? '+' : ''}${formatNumber(metrics?.overallBias ?? 0, 1)}`}
            </div>
            <div className="text-xs text-muted-foreground">Forecast Bias</div>
          </div>
        </div>

        {/* Model Performance Table */}
        <div>
          <h4 className="text-sm font-semibold text-foreground mb-3 flex items-center space-x-2">
            <span>Model Performance Comparison</span>
            {!isLoading && (
              <Badge variant="outline" className="text-xs">
                {metrics?.modelPerformance?.filter(m => m.isActive).length || 0} active
              </Badge>
            )}
          </h4>
          
          <div className="space-y-2">
            <div className="grid grid-cols-6 gap-4 text-xs font-medium text-muted-foreground pb-2 border-b border-border/30">
              <div>Model</div>
              <div className="text-right">MAPE (%)</div>
              <div className="text-right">RMSE</div>
              <div className="text-right">Bias</div>
              <div className="text-right">Accuracy</div>
              <div className="text-center">Status</div>
            </div>
            
            {isLoading ? (
              <div className="space-y-2">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="grid grid-cols-6 gap-4 py-2 animate-pulse">
                    <div className="h-4 bg-muted/30 rounded"></div>
                    <div className="h-4 bg-muted/30 rounded"></div>
                    <div className="h-4 bg-muted/30 rounded"></div>
                    <div className="h-4 bg-muted/30 rounded"></div>
                    <div className="h-4 bg-muted/30 rounded"></div>
                    <div className="h-4 bg-muted/30 rounded"></div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {metrics?.modelPerformance?.map((model, index) => (
                  <div key={index} className="grid grid-cols-6 gap-4 py-2 text-sm hover:bg-muted/20 rounded-md px-2">
                    <div className="text-foreground font-medium flex items-center space-x-2">
                      <span>{model.modelName}</span>
                      {model.isActive && <CheckCircle className="h-3 w-3 text-green-400" />}
                    </div>
                    <div className={`text-right font-medium ${getMapeColor(model.mape)}`}>
                      {formatNumber(model.mape, 1)}%
                    </div>
                    <div className="text-right text-foreground">{formatNumber(model.rmse, 0)}</div>
                    <div className="text-right text-foreground">
                      {model.bias > 0 ? '+' : ''}{formatNumber(model.bias, 1)}
                    </div>
                    <div className="text-right text-foreground font-medium">
                      {formatNumber(model.accuracy, 1)}%
                    </div>
                    <div className="text-center">
                      <Badge variant="outline" className={getAccuracyColor(model.accuracy)}>
                        {model.accuracy >= 90 ? 'Excellent' : model.accuracy >= 80 ? 'Good' : 'Poor'}
                      </Badge>
                    </div>
                  </div>
                )) ?? (
                  <div className="py-8 text-center text-muted-foreground">
                    No model performance data available
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Metrics Explanation */}
        <div className="text-xs text-muted-foreground space-y-1 pt-4 border-t border-border/30">
          <div><strong>MAPE:</strong> Mean Absolute Percentage Error - Lower is better {"(<5% excellent)"}</div>
          <div><strong>RMSE:</strong> Root Mean Square Error - Measures prediction accuracy in units</div>
          <div><strong>Bias:</strong> Average forecast error - Positive means over-forecasting</div>
          <div className="pt-2 text-right">
            Last updated: {isLoading ? '...' : new Date(metrics?.lastCalculated || Date.now()).toLocaleTimeString()}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}