import {
  ComposedChart,
  Line,
  Area,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  ResponsiveContainer,
} from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Calculator, TrendingUp, Edit3 } from 'lucide-react';

interface DataPoint {
  date: string;
  actual_value: number | null;
  forecast_value: number;
  forecast_lower: number;
  forecast_upper: number;
  is_historical: boolean;
  override_value?: number | null;
  final_forecast?: number | null;
  has_override?: boolean;
}

interface EnhancedForecastChartWithOverridesProps {
  data: DataPoint[];
  title?: string;
  subtitle?: string;
  className?: string;
  showOverrides?: boolean;
  onOverrideClick?: (date: string) => void;
}

export function EnhancedForecastChartWithOverrides({
  data,
  title = "Demand Forecast Analysis with Overrides",
  subtitle = "Statistical forecast, manual overrides, and final predictions",
  className = '',
  showOverrides = true,
  onOverrideClick
}: EnhancedForecastChartWithOverridesProps) {
  if (!data || data.length === 0) {
    return (
      <Card className={`bg-card/50 backdrop-blur-sm ${className}`}>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-foreground">
            {title}
          </CardTitle>
          <CardDescription className="text-muted-foreground">
            {subtitle}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-96 w-full flex items-center justify-center text-muted-foreground">
            No data available
          </div>
        </CardContent>
      </Card>
    );
  }

  // Transform data for Recharts
  const chartData = data.map((point) => {
    const date = new Date(point.date);
    return {
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      fullDate: point.date,
      actual: point.actual_value,
      statisticalForecast: point.forecast_value,
      override: point.override_value ?? null,
      finalForecast: point.final_forecast ?? point.override_value ?? point.forecast_value,
      lower: point.forecast_lower,
      upper: point.forecast_upper,
      isHistorical: point.is_historical,
      hasOverride: Boolean(point.has_override) || (point.override_value != null && !isNaN(point.override_value)),
      // Separate confidence intervals
      historicalConfidence: point.is_historical ? [point.forecast_lower, point.forecast_upper] : null,
      futureConfidence: !point.is_historical ? [point.forecast_lower, point.forecast_upper] : null,
    };
  });

  // Find today's position
  const today = new Date().toISOString().split('T')[0];
  const todayIndex = data.findIndex(d => d.date >= today);
  const todayLabel = todayIndex >= 0 ? chartData[todayIndex]?.date : chartData[chartData.length / 2]?.date;

  // Calculate Y-axis domain
  const allValues = chartData.flatMap(d => [
    d.actual,
    d.statisticalForecast,
    d.finalForecast,
    d.override,
    d.upper,
    d.lower
  ]).filter(v => v !== null && v !== undefined);

  const minValue = Math.min(...allValues);
  const maxValue = Math.max(...allValues);
  const padding = (maxValue - minValue) * 0.1;
  const yDomain = [Math.floor(minValue - padding), Math.ceil(maxValue + padding)];

  // Count overrides
  const overrideCount = chartData.filter(d => d.override != null && !isNaN(d.override)).length;
  const overridePercentage = (overrideCount / chartData.filter(d => !d.isHistorical).length * 100).toFixed(1);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900/95 backdrop-blur-xl border border-slate-600/50 rounded-xl shadow-2xl p-4">
          <p className="text-sm font-bold text-white mb-3">{label}</p>
          <div className="space-y-2">
            {data.actual !== null && data.actual !== undefined && (
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-blue-400 shadow-lg shadow-blue-400/50"></div>
                <span className="text-slate-400 text-sm">Actual:</span>
                <span className="text-white font-semibold">
                  {data.actual?.toLocaleString()}
                </span>
              </div>
            )}
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-slate-400"></div>
              <span className="text-slate-400 text-sm">Statistical:</span>
              <span className="text-white font-semibold">
                {data.statisticalForecast?.toLocaleString()}
              </span>
            </div>
            {data.hasOverride && (
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-amber-400 shadow-lg shadow-amber-400/50"></div>
                <span className="text-slate-400 text-sm">Override:</span>
                <span className="text-white font-semibold">
                  {data.override?.toLocaleString()}
                </span>
              </div>
            )}
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-emerald-400 shadow-lg shadow-emerald-400/50"></div>
              <span className="text-slate-400 text-sm">Final:</span>
              <span className="text-white font-semibold">
                {data.finalForecast?.toLocaleString()}
              </span>
            </div>
            <div className="pt-2 mt-2 border-t border-slate-700/50">
              <p className="text-xs text-slate-500">
                Range: {data.lower?.toLocaleString()} - {data.upper?.toLocaleString()}
              </p>
              {data.hasOverride && (
                <div className="flex items-center gap-1 mt-1">
                  <Edit3 className="h-3 w-3 text-amber-500" />
                  <p className="text-xs text-amber-500">Manual override applied</p>
                </div>
              )}
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  const formatYAxis = (value: number) => {
    return `${(value / 1000).toFixed(0)}k`;
  };

  return (
    <Card className={`bg-gradient-to-br from-slate-900/50 via-slate-800/50 to-slate-900/50 backdrop-blur-sm border-slate-700/50 ${className}`}>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-xl font-bold bg-gradient-to-r from-blue-400 via-cyan-400 to-teal-400 bg-clip-text text-transparent">
              {title}
            </CardTitle>
            <CardDescription className="text-slate-400 mt-1">
              {subtitle}
            </CardDescription>
          </div>
          {showOverrides && overrideCount > 0 && (
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-amber-500/10 text-amber-400 border-amber-500/30">
                <Edit3 className="h-3 w-3 mr-1" />
                {overrideCount} Overrides
              </Badge>
              <Badge variant="outline" className="bg-slate-500/10 text-slate-400 border-slate-500/30">
                {overridePercentage}% Coverage
              </Badge>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[450px] w-full p-4 bg-slate-900/30 rounded-xl overflow-hidden relative">
          <ResponsiveContainer width="100%" height="100%" style={{ overflow: 'hidden' }}>
            <ComposedChart data={chartData} margin={{ top: 0, right: 30, left: 20, bottom: 30 }}>
              <defs>
                {/* Clip path to prevent overflow */}
                <clipPath id="chartClip" clipPathUnits="userSpaceOnUse">
                  <rect x="0" y="0" width="2000" height="450" />
                </clipPath>
                {/* Gradient for confidence bands */}
                <linearGradient id="confidenceGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#60A5FA" stopOpacity={0.3} />
                  <stop offset="50%" stopColor="#3B82F6" stopOpacity={0.1} />
                  <stop offset="100%" stopColor="#1E40AF" stopOpacity={0.02} />
                </linearGradient>

                <linearGradient id="forecastConfidenceGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#34D399" stopOpacity={0.4} />
                  <stop offset="50%" stopColor="#10B981" stopOpacity={0.2} />
                  <stop offset="100%" stopColor="#059669" stopOpacity={0.05} />
                </linearGradient>

                {/* Glow effects */}
                <filter id="glow">
                  <feGaussianBlur stdDeviation="4" result="coloredBlur"/>
                  <feMerge>
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>

                <filter id="overrideGlow">
                  <feGaussianBlur stdDeviation="6" result="coloredBlur"/>
                  <feMerge>
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>
              </defs>

              <CartesianGrid
                strokeDasharray="8 8"
                stroke="rgba(148, 163, 184, 0.08)"
                vertical={false}
                horizontal={false}
              />

              <XAxis
                dataKey="date"
                axisLine={{ stroke: 'rgba(148, 163, 184, 0.2)' }}
                tickLine={false}
                tick={{ fill: '#94A3B8', fontSize: 11, fontWeight: 500 }}
                interval="preserveStartEnd"
              />

              <YAxis
                domain={yDomain}
                axisLine={{ stroke: 'rgba(148, 163, 184, 0.2)' }}
                tickLine={false}
                tick={{ fill: '#94A3B8', fontSize: 12, fontWeight: 500 }}
                tickFormatter={formatYAxis}
              />

              {/* Confidence intervals */}
              <Area
                type="monotone"
                dataKey="historicalConfidence"
                stroke="none"
                fill="url(#confidenceGradient)"
                fillOpacity={0.6}
                name="Historical Confidence"
              />

              <Area
                type="monotone"
                dataKey="futureConfidence"
                stroke="none"
                fill="url(#forecastConfidenceGradient)"
                fillOpacity={0.8}
                name="Forecast Range"
              />

              {/* Statistical forecast (dashed line) */}
              <Line
                type="monotone"
                dataKey="statisticalForecast"
                stroke="#94A3B8"
                strokeWidth={2}
                strokeDasharray="8 4"
                dot={false}
                name="Statistical Forecast"
                opacity={0.6}
              />

              {/* Final forecast (solid bold line) */}
              <Line
                type="monotone"
                dataKey="finalForecast"
                stroke="#10B981"
                strokeWidth={3}
                dot={false}
                name="Final Forecast"
                filter="url(#glow)"
              />

              {/* Override points - shown as dots */}
              {showOverrides && (
                <Scatter
                  dataKey="override"
                  fill="#F59E0B"
                  name="Manual Override"
                  shape={(props: any) => {
                    if (!props.payload.hasOverride || props.payload.override == null || isNaN(props.payload.override)) return null;
                    return (
                      <circle
                        cx={props.cx}
                        cy={props.cy}
                        r={5}
                        fill="#F59E0B"
                        stroke="#A16207"
                        strokeWidth={1.5}
                        opacity={0.95}
                        onClick={() => onOverrideClick?.(props.payload.fullDate)}
                        style={{ cursor: onOverrideClick ? 'pointer' : 'default' }}
                      />
                    );
                  }}
                />
              )}

              {/* Historical actual values */}
              <Scatter
                dataKey="actual"
                fill="#60A5FA"
                name="Historical Actual"
                shape={(props: any) => {
                  if (props.payload.actual === null) return null;
                  return (
                    <circle
                      cx={props.cx}
                      cy={props.cy}
                      r={4}
                      fill="#60A5FA"
                      stroke="#1E40AF"
                      strokeWidth={1}
                      opacity={0.9}
                    />
                  );
                }}
              />

              {/* Today marker - vertical line only */}
              {todayLabel && (
                <ReferenceLine
                  x={todayLabel}
                  stroke="#F59E0B"
                  strokeWidth={2}
                  strokeDasharray="8 4"
                  strokeOpacity={0.6}
                  ifOverflow="discard"
                  label={{
                    value: "TODAY",
                    position: "top",
                    fill: "#F59E0B",
                    fontSize: 12,
                    fontWeight: 600,
                    offset: 5
                  }}
                />
              )}

              <Tooltip content={<CustomTooltip />} />

              <Legend
                wrapperStyle={{
                  paddingTop: '20px',
                  fontSize: '13px',
                }}
                iconType="line"
                formatter={(value: string) => (
                  <span className="text-slate-400 font-medium">{value}</span>
                )}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        {/* Override Summary */}
        {showOverrides && overrideCount > 0 && (
          <div className="mt-4 p-3 bg-amber-500/5 border border-amber-500/20 rounded-lg">
            <div className="flex items-center gap-2">
              <Calculator className="h-4 w-4 text-amber-500" />
              <p className="text-sm text-slate-400">
                <span className="font-semibold text-amber-400">{overrideCount}</span> manual overrides applied,
                affecting <span className="font-semibold text-amber-400">{overridePercentage}%</span> of future forecasts.
                Click on override points to view details.
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}