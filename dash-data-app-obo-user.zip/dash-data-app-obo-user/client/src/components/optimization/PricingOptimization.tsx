import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  Calculator,
  AlertCircle,
  Target,
  Zap,
  ArrowUp,
  ArrowDown
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
  Area,
  ComposedChart,
  Bar,
  Dot
} from 'recharts';

interface PricingOptimizationProps {
  productId: string;
  locationId: string;
  data: any;
  isLoading: boolean;
}

export function PricingOptimization({
  productId,
  locationId,
  data,
  isLoading
}: PricingOptimizationProps) {
  const currentPrice = data?.currentPrice || 29.99;
  const optimalPrice = data?.optimalPrice || 34.99;
  const elasticity = data?.elasticity || -1.5;
  const baseQuantity = 1000; // Base demand at current price

  const [simulatedPrice, setSimulatedPrice] = useState([currentPrice]);
  const [optimizationGoal, setOptimizationGoal] = useState<'revenue' | 'profit' | 'volume'>('revenue');

  // Find optimal price based on goal first
  const getOptimalByGoal = (goal: string) => {
    // Temporarily calculate points to find optimal
    const tempPoints = [];
    const minPrice = currentPrice * 0.7;
    const maxPrice = currentPrice * 1.5;
    const step = (maxPrice - minPrice) / 20;

    for (let price = minPrice; price <= maxPrice; price += step) {
      const priceRatio = price / currentPrice;
      const quantity = baseQuantity * Math.pow(priceRatio, elasticity);
      const revenue = price * quantity;
      const costPerUnit = 15;
      const profit = (price - costPerUnit) * quantity;

      tempPoints.push({
        price: parseFloat(price.toFixed(2)),
        quantity: Math.round(quantity),
        revenue: parseFloat(revenue.toFixed(2)),
        profit: parseFloat(profit.toFixed(2))
      });
    }

    switch (goal) {
      case 'revenue':
        return tempPoints.reduce((max, p) => p.revenue > max.revenue ? p : max, tempPoints[0]);
      case 'profit':
        return tempPoints.reduce((max, p) => p.profit > max.profit ? p : max, tempPoints[0]);
      case 'volume':
        return tempPoints.reduce((max, p) => p.quantity > max.quantity ? p : max, tempPoints[0]);
      default:
        return tempPoints[10];
    }
  };

  const optimalPoint = getOptimalByGoal(optimizationGoal);

  // Generate price-demand curve data with optimal price known
  const pricePoints = useMemo(() => {
    const points = [];
    const minPrice = currentPrice * 0.7;
    const maxPrice = currentPrice * 1.5;
    const step = (maxPrice - minPrice) / 20;

    for (let price = minPrice; price <= maxPrice; price += step) {
      const priceRatio = price / currentPrice;
      const quantity = baseQuantity * Math.pow(priceRatio, elasticity);
      const revenue = price * quantity;
      const costPerUnit = 15; // Assumed cost
      const profit = (price - costPerUnit) * quantity;

      points.push({
        price: parseFloat(price.toFixed(2)),
        quantity: Math.round(quantity),
        revenue: parseFloat(revenue.toFixed(2)),
        profit: parseFloat(profit.toFixed(2)),
        margin: parseFloat(((price - costPerUnit) / price * 100).toFixed(1)),
        // Add flags for special points
        isCurrent: Math.abs(price - currentPrice) < 0.5,
        isSimulated: Math.abs(price - simulatedPrice[0]) < 0.5,
        isOptimal: Math.abs(price - optimalPoint.price) < 0.5
      });
    }
    return points;
  }, [currentPrice, elasticity, simulatedPrice, optimalPoint.price]);

  const currentPoint = pricePoints.find(p => Math.abs(p.price - currentPrice) < 0.5) || pricePoints[10];
  const simulatedPoint = pricePoints.find(p => Math.abs(p.price - simulatedPrice[0]) < 0.5) || pricePoints[10];

  const revenueIncrease = ((optimalPoint.revenue - currentPoint.revenue) / currentPoint.revenue * 100).toFixed(1);
  const profitIncrease = ((optimalPoint.profit - currentPoint.profit) / currentPoint.profit * 100).toFixed(1);
  
  // Calculate simulated deltas
  const simulatedRevenueChange = ((simulatedPoint.revenue - currentPoint.revenue) / currentPoint.revenue * 100).toFixed(1);
  const simulatedProfitChange = ((simulatedPoint.profit - currentPoint.profit) / currentPoint.profit * 100).toFixed(1);
  const simulatedQuantityChange = ((simulatedPoint.quantity - currentPoint.quantity) / currentPoint.quantity * 100).toFixed(1);

  // Custom dot component for highlighting special points
  const CustomDot = (props: any) => {
    const { cx, cy, payload } = props;
    if (payload.isSimulated) {
      return (
        <g>
          <circle cx={cx} cy={cy} r={8} fill="#a855f7" fillOpacity={0.3} className="animate-pulse" />
          <circle cx={cx} cy={cy} r={5} fill="#a855f7" stroke="#fff" strokeWidth={2} />
        </g>
      );
    }
    if (payload.isCurrent) {
      return <circle cx={cx} cy={cy} r={4} fill="#f59e0b" stroke="#fff" strokeWidth={2} />;
    }
    if (payload.isOptimal) {
      return <circle cx={cx} cy={cy} r={4} fill="#10b981" stroke="#fff" strokeWidth={2} />;
    }
    return null;
  };

  return (
    <Card className={`${isLoading ? 'animate-pulse' : ''}`}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-green-500" />
            Pricing Optimization
          </div>
          <div className="flex gap-2">
            {['revenue', 'profit', 'volume'].map(goal => (
              <Button
                key={goal}
                size="sm"
                variant={optimizationGoal === goal ? "default" : "outline"}
                onClick={() => setOptimizationGoal(goal as any)}
              >
                {goal.charAt(0).toUpperCase() + goal.slice(1)}
              </Button>
            ))}
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Current vs Optimal Comparison */}
        <div className="grid grid-cols-3 gap-4">
          <div className="p-3 bg-muted/50 rounded-lg">
            <div className="text-xs text-muted-foreground mb-1">Current Price</div>
            <div className="text-xl font-bold">${currentPrice}</div>
            <div className="text-xs text-muted-foreground">
              {currentPoint.quantity} units
            </div>
            <div className="text-xs text-green-500">
              ${currentPoint.revenue.toLocaleString()} revenue
            </div>
          </div>

          <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-lg">
            <div className="text-xs text-green-400 mb-1">Optimal Price</div>
            <div className="text-xl font-bold text-green-500">${optimalPoint.price}</div>
            <div className="text-xs text-muted-foreground">
              {optimalPoint.quantity} units
            </div>
            <div className="text-xs text-green-400">
              ${optimalPoint.revenue.toLocaleString()} revenue
            </div>
          </div>

          <div className="p-3 bg-blue-500/10 rounded-lg">
            <div className="text-xs text-blue-400 mb-1">Expected Impact</div>
            <div className="flex items-center gap-1">
              {parseFloat(revenueIncrease) > 0 ? (
                <TrendingUp className="h-4 w-4 text-green-500" />
              ) : (
                <TrendingDown className="h-4 w-4 text-red-500" />
              )}
              <span className="text-lg font-bold text-green-500">+{revenueIncrease}%</span>
            </div>
            <div className="text-xs text-muted-foreground">Revenue increase</div>
            <div className="text-xs text-blue-400">+{profitIncrease}% profit</div>
          </div>
        </div>

        {/* Price Elasticity Curve */}
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={pricePoints}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis
                dataKey="price"
                stroke="#888"
                label={{ value: 'Price ($)', position: 'insideBottom', offset: -5 }}
              />
              <YAxis
                yAxisId="left"
                stroke="#888"
                label={{ value: 'Quantity', angle: -90, position: 'insideLeft' }}
              />
              <YAxis
                yAxisId="right"
                orientation="right"
                stroke="#888"
                label={{ value: 'Revenue ($)', angle: 90, position: 'insideRight' }}
              />
              <Tooltip
                contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                labelStyle={{ color: '#888' }}
                formatter={(value: any, name: string) => {
                  if (typeof value === 'number') {
                    return [`${value.toLocaleString()}`, name];
                  }
                  return [value, name];
                }}
                content={(props: any) => {
                  const { active, payload } = props;
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-card p-3 rounded-lg border border-border">
                        <p className="text-sm font-medium mb-1">Price: ${data.price}</p>
                        <div className="space-y-1 text-xs">
                          <p>Quantity: {data.quantity.toLocaleString()} units</p>
                          <p className="text-green-400">Revenue: ${data.revenue.toLocaleString()}</p>
                          <p className="text-blue-400">Profit: ${data.profit.toLocaleString()}</p>
                          <p>Margin: {data.margin}%</p>
                          {data.isSimulated && (
                            <div className="pt-1 mt-1 border-t border-border">
                              <p className="text-purple-400 font-medium">Simulated Impact:</p>
                              <p>Revenue: {parseFloat(simulatedRevenueChange) >= 0 ? '+' : ''}{simulatedRevenueChange}%</p>
                              <p>Volume: {parseFloat(simulatedQuantityChange) >= 0 ? '+' : ''}{simulatedQuantityChange}%</p>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Area
                yAxisId="left"
                type="linear"
                dataKey="quantity"
                fill="#3b82f6"
                fillOpacity={0.3}
                stroke="#3b82f6"
                strokeWidth={2}
                name="Demand"
                dot={<CustomDot />}
              />
              <Line
                yAxisId="right"
                type="linear"
                dataKey={optimizationGoal === 'profit' ? 'profit' : 'revenue'}
                stroke="#10b981"
                strokeWidth={2}
                dot={<CustomDot />}
                name={optimizationGoal === 'profit' ? 'Profit' : 'Revenue'}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        {/* Price Simulator */}
        <div className="p-4 bg-muted/50 rounded-lg space-y-3">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Calculator className="h-4 w-4 text-purple-500" />
              <span className="text-sm font-medium">Price Simulator</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold">${simulatedPrice[0].toFixed(2)}</span>
              {simulatedPrice[0] !== currentPrice && (
                <Badge variant="secondary" className="text-xs">
                  {((simulatedPrice[0] - currentPrice) / currentPrice * 100).toFixed(1)}%
                </Badge>
              )}
            </div>
          </div>

          <Slider
            value={simulatedPrice}
            onValueChange={setSimulatedPrice}
            min={currentPrice * 0.7}
            max={currentPrice * 1.5}
            step={0.5}
            className="w-full"
          />

          <div className="grid grid-cols-3 gap-2 text-xs">
            <div>
              <span className="text-muted-foreground">Expected Demand:</span>
              <div className="flex items-center gap-1">
                <span className="font-semibold">{simulatedPoint.quantity.toLocaleString()} units</span>
                {simulatedPrice[0] !== currentPrice && (
                  <span className={`flex items-center ${parseFloat(simulatedQuantityChange) >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {parseFloat(simulatedQuantityChange) >= 0 ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
                    {Math.abs(parseFloat(simulatedQuantityChange))}%
                  </span>
                )}
              </div>
            </div>
            <div>
              <span className="text-muted-foreground">Expected Revenue:</span>
              <div className="flex items-center gap-1">
                <span className="font-semibold text-green-500">${simulatedPoint.revenue.toLocaleString()}</span>
                {simulatedPrice[0] !== currentPrice && (
                  <span className={`flex items-center ${parseFloat(simulatedRevenueChange) >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {parseFloat(simulatedRevenueChange) >= 0 ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
                    {Math.abs(parseFloat(simulatedRevenueChange))}%
                  </span>
                )}
              </div>
            </div>
            <div>
              <span className="text-muted-foreground">Profit Margin:</span>
              <div className="flex items-center gap-1">
                <span className="font-semibold">{simulatedPoint.margin}%</span>
                {simulatedPrice[0] !== currentPrice && (
                  <span className="text-xs text-muted-foreground">
                    ({(simulatedPoint.margin - currentPoint.margin).toFixed(1)}pp)
                  </span>
                )}
              </div>
            </div>
          </div>
          
          {simulatedPrice[0] !== currentPrice && (
            <div className="pt-2 border-t border-border">
              <div className="text-xs text-purple-400 font-medium mb-1">Impact vs Current:</div>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <span className="text-muted-foreground">Revenue Δ:</span>
                  <span className={`font-medium ${parseFloat(simulatedRevenueChange) >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                    ${(simulatedPoint.revenue - currentPoint.revenue).toFixed(0)}
                  </span>
                </div>
                <div>
                  <span className="text-muted-foreground">Profit Δ:</span>
                  <span className={`font-medium ${parseFloat(simulatedProfitChange) >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                    ${(simulatedPoint.profit - currentPoint.profit).toFixed(0)}
                  </span>
                </div>
                <div>
                  <span className="text-muted-foreground">Units Δ:</span>
                  <span className={`font-medium ${parseFloat(simulatedQuantityChange) >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {(simulatedPoint.quantity - currentPoint.quantity > 0 ? '+' : '')}{simulatedPoint.quantity - currentPoint.quantity}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Elasticity Indicator */}
        <div className="flex items-center justify-between p-3 bg-background/50 rounded-lg">
          <div className="flex items-center gap-2">
            <Zap className="h-4 w-4 text-amber-500" />
            <span className="text-sm">Price Elasticity</span>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant={Math.abs(elasticity) > 1 ? "destructive" : "default"}>
              {Math.abs(elasticity) > 1 ? 'Elastic' : 'Inelastic'}
            </Badge>
            <span className="text-sm font-mono">{elasticity}</span>
          </div>
        </div>

        {/* Recommendation Alert */}
        <Alert className="border-green-500/50">
          <Target className="h-4 w-4" />
          <AlertDescription>
            <strong>Recommendation:</strong> Adjust price from ${currentPrice} to ${optimalPoint.price}
            to maximize {optimizationGoal}. This would increase {optimizationGoal} by {
              optimizationGoal === 'revenue' ? revenueIncrease :
              optimizationGoal === 'profit' ? profitIncrease :
              ((optimalPoint.quantity - currentPoint.quantity) / currentPoint.quantity * 100).toFixed(1)
            }%
            {optimizationGoal === 'volume' && ' in sales volume'}.
          </AlertDescription>
        </Alert>

        {/* Additional Insights */}
        <div className="text-xs text-muted-foreground space-y-1">
          <div>• A 1% price increase leads to a {Math.abs(elasticity).toFixed(1)}% demand decrease</div>
          <div>• Break-even point: ${(15 / (1 - 1/Math.abs(elasticity))).toFixed(2)}</div>
          <div>• Confidence interval: ±5% based on historical variance</div>
        </div>
      </CardContent>
    </Card>
  );
}