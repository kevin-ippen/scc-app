import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Package,
  TrendingUp,
  ShieldCheck,
  RefreshCw,
  AlertCircle,
  Calculator,
  ArrowUp,
  ArrowDown
} from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
  Area,
  ComposedChart
} from 'recharts';

interface InventoryOptimizationProps {
  productId: string;
  locationId: string;
  data: any;
  isLoading: boolean;
}

export function InventoryOptimization({
  productId,
  locationId,
  data,
  isLoading
}: InventoryOptimizationProps) {
  const [showDetails, setShowDetails] = useState(false);
  const [serviceLevel, setServiceLevel] = useState(95); // 95% service level

  // Mock data for visualization
  const inventoryData = [
    { day: 'Mon', stock: 150, demand: 20, safetyStock: 85, reorderPoint: 120 },
    { day: 'Tue', stock: 130, demand: 25, safetyStock: 85, reorderPoint: 120 },
    { day: 'Wed', stock: 105, demand: 30, safetyStock: 85, reorderPoint: 120 },
    { day: 'Thu', stock: 175, demand: 15, safetyStock: 85, reorderPoint: 120 }, // Reorder arrived
    { day: 'Fri', stock: 160, demand: 22, safetyStock: 85, reorderPoint: 120 },
    { day: 'Sat', stock: 138, demand: 35, safetyStock: 85, reorderPoint: 120 },
    { day: 'Sun', stock: 103, demand: 28, safetyStock: 85, reorderPoint: 120 }
  ];

  const currentStock = data?.currentStock || 150;
  const optimalStock = data?.optimalStock || 235;
  const safetyStock = data?.safetyStock || 85;
  const reorderPoint = data?.reorderPoint || 120;
  const reorderQuantity = data?.reorderQuantity || 200;

  const stockDifference = optimalStock - currentStock;
  const stockoutRisk = currentStock < safetyStock ? 'High' : currentStock < reorderPoint ? 'Medium' : 'Low';
  const daysOfSupply = Math.floor(currentStock / 25); // Assuming 25 units/day average

  // Calculate Z-score for service level
  const getZScore = (serviceLevel: number) => {
    const zScores: Record<number, number> = {
      90: 1.28,
      95: 1.65,
      99: 2.33
    };
    return zScores[serviceLevel] || 1.65;
  };

  return (
    <Card className={`${isLoading ? 'animate-pulse' : ''}`}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Package className="h-5 w-5 text-blue-500" />
            Inventory Optimization
          </div>
          <Badge variant={stockoutRisk === 'Low' ? 'default' : stockoutRisk === 'Medium' ? 'secondary' : 'destructive'}>
            {stockoutRisk} Risk
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Key Metrics */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Current Stock</span>
              {stockDifference < 0 ? (
                <ArrowDown className="h-4 w-4 text-red-500" />
              ) : (
                <ArrowUp className="h-4 w-4 text-green-500" />
              )}
            </div>
            <div className="text-2xl font-bold">{currentStock} units</div>
            <div className="text-xs text-muted-foreground">{daysOfSupply} days supply</div>
          </div>

          <div className="space-y-1">
            <span className="text-sm text-muted-foreground">Optimal Stock</span>
            <div className="text-2xl font-bold text-green-500">{optimalStock} units</div>
            <div className="text-xs text-muted-foreground">Target level</div>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-1">
              <ShieldCheck className="h-3 w-3 text-blue-500" />
              <span className="text-sm text-muted-foreground">Safety Stock</span>
            </div>
            <div className="text-lg font-semibold">{safetyStock} units</div>
            <div className="text-xs text-muted-foreground">Buffer for uncertainty</div>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-1">
              <RefreshCw className="h-3 w-3 text-purple-500" />
              <span className="text-sm text-muted-foreground">Reorder Point</span>
            </div>
            <div className="text-lg font-semibold">{reorderPoint} units</div>
            <div className="text-xs text-muted-foreground">Order when reaching</div>
          </div>
        </div>

        {/* Stock Level Visualization */}
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={inventoryData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="day" stroke="#888" />
              <YAxis stroke="#888" />
              <Tooltip
                contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                labelStyle={{ color: '#888' }}
              />
              <Area
                type="monotone"
                dataKey="stock"
                fill="#3b82f6"
                fillOpacity={0.3}
                stroke="#3b82f6"
                strokeWidth={2}
              />
              <ReferenceLine
                y={reorderPoint}
                stroke="#a855f7"
                strokeDasharray="5 5"
                label={{ value: "Reorder", position: "right", fill: "#a855f7" }}
              />
              <ReferenceLine
                y={safetyStock}
                stroke="#f59e0b"
                strokeDasharray="5 5"
                label={{ value: "Safety", position: "right", fill: "#f59e0b" }}
              />
              <Bar dataKey="demand" fill="#10b981" opacity={0.6} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        {/* Optimization Recommendations */}
        <Alert className={stockDifference > 0 ? "border-amber-500/50" : "border-green-500/50"}>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            {stockDifference > 0 ? (
              <>
                <strong>Action Required:</strong> Increase stock by {stockDifference} units to reach optimal level.
                This will reduce stockout risk from {stockoutRisk} to Low.
              </>
            ) : (
              <>
                <strong>Well Stocked:</strong> Current inventory exceeds optimal level by {Math.abs(stockDifference)} units.
                Consider reducing next order quantity.
              </>
            )}
          </AlertDescription>
        </Alert>

        {/* Economic Order Quantity */}
        <div className="p-4 bg-muted/50 rounded-lg space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Calculator className="h-4 w-4 text-green-500" />
              <span className="text-sm font-medium">Economic Order Quantity (EOQ)</span>
            </div>
            <span className="text-xl font-bold text-green-500">{reorderQuantity} units</span>
          </div>
          <div className="text-xs text-muted-foreground">
            Optimal order size balancing holding costs and ordering costs
          </div>
          <Progress value={65} className="h-2" />
          <div className="text-xs text-muted-foreground">
            Next order in {Math.floor((currentStock - reorderPoint) / 25)} days
          </div>
        </div>

        {/* Service Level Configuration */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Service Level Target</span>
            <div className="flex gap-2">
              {[90, 95, 99].map(level => (
                <Button
                  key={level}
                  size="sm"
                  variant={serviceLevel === level ? "default" : "outline"}
                  onClick={() => setServiceLevel(level)}
                >
                  {level}%
                </Button>
              ))}
            </div>
          </div>
          <div className="text-xs text-muted-foreground">
            Higher service levels require more safety stock (Z-score: {getZScore(serviceLevel).toFixed(2)})
          </div>
        </div>

        {/* Detailed Calculations */}
        {showDetails && (
          <div className="mt-4 p-4 bg-background/50 rounded-lg space-y-2 text-sm">
            <div className="font-semibold mb-2">Calculation Details:</div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>Lead Time:</div>
              <div>7 days</div>
              <div>Average Daily Demand:</div>
              <div>25 units/day</div>
              <div>Demand Std Dev:</div>
              <div>8 units</div>
              <div>Z-Score ({serviceLevel}% SL):</div>
              <div>{getZScore(serviceLevel)}</div>
              <div>Safety Stock Formula:</div>
              <div>Z × σ × √LT = {safetyStock}</div>
              <div>Reorder Point Formula:</div>
              <div>(Avg Daily × LT) + SS = {reorderPoint}</div>
            </div>
          </div>
        )}

        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowDetails(!showDetails)}
          className="w-full"
        >
          {showDetails ? 'Hide' : 'Show'} Calculation Details
        </Button>
      </CardContent>
    </Card>
  );
}