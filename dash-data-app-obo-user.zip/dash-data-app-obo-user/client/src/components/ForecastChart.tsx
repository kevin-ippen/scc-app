import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';

interface ChartDataPoint {
  date: string;
  yhat: number;
  yhat_lower: number;
  yhat_upper: number;
}

interface ForecastChartProps {
  data: ChartDataPoint[];
  className?: string;
}

export function ForecastChart({ data, className = '' }: ForecastChartProps) {
  // Transform data for Recharts
  const chartData = data.map((point) => {
    const date = new Date(point.date);
    return {
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      forecast: Math.round(point.yhat),
      lower: Math.round(point.yhat_lower),
      upper: Math.round(point.yhat_upper),
      // For the confidence interval area
      confidenceInterval: [Math.round(point.yhat_lower), Math.round(point.yhat_upper)],
    };
  });

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-background/95 backdrop-blur-sm border border-border rounded-lg shadow-lg p-3">
          <p className="text-sm font-medium text-foreground mb-1">{label}</p>
          <div className="space-y-1">
            <p className="text-sm">
              <span className="text-primary">●</span>
              <span className="text-foreground ml-2">
                Forecast: {data.forecast?.toLocaleString()}
              </span>
            </p>
            <p className="text-xs text-muted-foreground">
              Range: {data.lower?.toLocaleString()} - {data.upper?.toLocaleString()}
            </p>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className={`metric-card ${className}`}>
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-foreground">
          Daily Demand Forecast
        </CardTitle>
        <CardDescription className="text-muted-foreground">
          AI-generated predictions with confidence intervals
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
              <defs>
                <linearGradient id="forecastGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--chart-blue))" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(var(--chart-blue))" stopOpacity={0.1} />
                </linearGradient>
                <linearGradient id="confidenceGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--chart-blue-light))" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="hsl(var(--chart-blue-light))" stopOpacity={0.05} />
                </linearGradient>
              </defs>
              
              <XAxis 
                dataKey="date"
                axisLine={false}
                tickLine={false}
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
              />
              <YAxis 
                axisLine={false}
                tickLine={false}
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
              />
              
              {/* Confidence interval area */}
              <Area
                type="monotone"
                dataKey="confidenceInterval"
                stroke="none"
                fill="url(#confidenceGradient)"
                fillOpacity={0.4}
              />
              
              {/* Main forecast line and area */}
              <Area
                type="monotone"
                dataKey="forecast"
                stroke="hsl(var(--chart-blue))"
                strokeWidth={2}
                fill="url(#forecastGradient)"
                fillOpacity={0.6}
              />
              
              <Tooltip content={<CustomTooltip />} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        
        <div className="flex items-center justify-center mt-4 text-xs text-muted-foreground gap-6">
          <div className="flex items-center gap-2">
            <div className="w-3 h-2 bg-primary/60 rounded-sm"></div>
            <span>Forecast Line</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-2 bg-primary/20 rounded-sm"></div>
            <span>Confidence Interval</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}