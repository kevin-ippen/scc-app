import { useQuery } from '@tanstack/react-query';
import { AlertTriangle, Package, MapPin, Clock, RefreshCw } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

interface StockAlert {
  productId: string;
  productName: string;
  category: string;
  currentStock: number;
  reorderPoint: number;
  warehouse: string;
  location: string;
  leadTimeDays: number;
  priority: 'critical' | 'warning' | 'info';
  lastRestocked: string;
  daysUntilStockout: number;
}

interface AlertMetrics {
  alerts: StockAlert[];
  totalAlerts: number;
  criticalAlerts: number;
  warningAlerts: number;
  totalValue: number;
  lastUpdated: string;
}

const fetchStockAlerts = async (): Promise<AlertMetrics> => {
  const response = await fetch('/api/dashboard/stock-alerts');
  if (!response.ok) {
    throw new Error('Failed to fetch stock alerts');
  }
  return response.json();
};

export function LowStockAlerts() {
  const { 
    data: metrics, 
    isLoading, 
    error,
    refetch 
  } = useQuery({
    queryKey: ['stock-alerts'],
    queryFn: fetchStockAlerts,
    refetchInterval: 30000, // Refresh every 30 seconds for alerts
  });

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'text-red-600 bg-red-100 border-red-200';
      case 'warning': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      case 'info': return 'text-blue-600 bg-blue-100 border-blue-200';
      default: return 'text-muted-foreground bg-muted border-border';
    }
  };

  const getStockPercentage = (current: number, reorder: number) => {
    return Math.round((current / reorder) * 100);
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('en-US').format(num);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  if (error) {
    return (
      <Card className="bg-card/50 backdrop-blur-sm border-destructive/20">
        <CardContent className="p-6">
          <div className="flex items-center space-x-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            <span>Failed to load stock alerts</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card/50 backdrop-blur-sm border-border/50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="h-5 w-5 text-orange-400" />
            <div>
              <CardTitle className="text-foreground">Low Stock Alerts</CardTitle>
              <CardDescription>
                Products requiring immediate attention
              </CardDescription>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Badge variant="outline" className="text-red-600 bg-red-100">
              {isLoading ? '...' : metrics?.criticalAlerts ?? 0} Critical
            </Badge>
            <Badge variant="outline" className="text-yellow-600 bg-yellow-100">
              {isLoading ? '...' : metrics?.warningAlerts ?? 0} Warning
            </Badge>
            <Button
              variant="outline"
              size="sm"
              onClick={() => refetch()}
              disabled={isLoading}
              className="h-8 px-3"
            >
              <RefreshCw className={`h-3 w-3 ${isLoading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Alert Summary */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="text-center p-3 rounded-lg bg-red-500/10 border border-red-500/20">
            <div className="text-2xl font-bold text-foreground">
              {isLoading ? '...' : formatNumber(metrics?.totalAlerts ?? 0)}
            </div>
            <div className="text-xs text-muted-foreground">Total Alerts</div>
          </div>
          
          <div className="text-center p-3 rounded-lg bg-red-500/10 border border-red-500/20">
            <div className="text-2xl font-bold text-red-400">
              {isLoading ? '...' : formatNumber(metrics?.criticalAlerts ?? 0)}
            </div>
            <div className="text-xs text-muted-foreground">Critical</div>
          </div>
          
          <div className="text-center p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
            <div className="text-2xl font-bold text-yellow-400">
              {isLoading ? '...' : formatNumber(metrics?.warningAlerts ?? 0)}
            </div>
            <div className="text-xs text-muted-foreground">Warning</div>
          </div>
          
          <div className="text-center p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
            <div className="text-2xl font-bold text-foreground">
              {isLoading ? '...' : formatCurrency(metrics?.totalValue ?? 0)}
            </div>
            <div className="text-xs text-muted-foreground">Total Value</div>
          </div>
        </div>

        {/* Alerts Table */}
        <div>
          <div className="space-y-2">
            <div className="grid grid-cols-8 gap-3 text-xs font-medium text-muted-foreground pb-3 border-b border-border/30">
              <div>Product</div>
              <div>Category</div>
              <div className="text-center">Stock</div>
              <div className="text-center">Reorder</div>
              <div className="text-center">Location</div>
              <div className="text-center">Lead Time</div>
              <div className="text-center">Stockout</div>
              <div className="text-center">Priority</div>
            </div>
            
            {isLoading ? (
              <div className="space-y-3">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="grid grid-cols-8 gap-3 py-3 animate-pulse">
                    <div className="h-4 bg-muted/30 rounded"></div>
                    <div className="h-4 bg-muted/30 rounded"></div>
                    <div className="h-4 bg-muted/30 rounded"></div>
                    <div className="h-4 bg-muted/30 rounded"></div>
                    <div className="h-4 bg-muted/30 rounded"></div>
                    <div className="h-4 bg-muted/30 rounded"></div>
                    <div className="h-4 bg-muted/30 rounded"></div>
                    <div className="h-4 bg-muted/30 rounded"></div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {metrics?.alerts?.map((alert, index) => (
                  <div key={index} className="grid grid-cols-8 gap-3 py-3 text-sm hover:bg-muted/20 rounded-md px-2 border-l-4 border-transparent hover:border-l-orange-400">
                    <div className="space-y-1">
                      <div className="text-foreground font-medium text-xs">
                        {alert.productName}
                      </div>
                      <div className="text-muted-foreground text-xs">
                        {alert.productId}
                      </div>
                    </div>
                    
                    <div className="text-muted-foreground">{alert.category}</div>
                    
                    <div className="text-center">
                      <div className="text-foreground font-medium">{formatNumber(alert.currentStock)}</div>
                      <div className="text-xs text-muted-foreground">
                        {getStockPercentage(alert.currentStock, alert.reorderPoint)}%
                      </div>
                    </div>
                    
                    <div className="text-center text-foreground font-medium">
                      {formatNumber(alert.reorderPoint)}
                    </div>
                    
                    <div className="text-center">
                      <div className="text-foreground text-xs">{alert.warehouse}</div>
                      <div className="text-muted-foreground text-xs">{alert.location}</div>
                    </div>
                    
                    <div className="text-center">
                      <div className="flex items-center justify-center space-x-1">
                        <Clock className="h-3 w-3 text-muted-foreground" />
                        <span className="text-foreground text-xs">{alert.leadTimeDays}d</span>
                      </div>
                    </div>
                    
                    <div className="text-center">
                      <div className="text-foreground font-medium text-xs">
                        {alert.daysUntilStockout > 0 ? `${alert.daysUntilStockout}d` : 'Now'}
                      </div>
                    </div>
                    
                    <div className="text-center">
                      <Badge className={getPriorityColor(alert.priority)}>
                        {alert.priority}
                      </Badge>
                    </div>
                  </div>
                )) ?? (
                  <div className="py-8 text-center text-muted-foreground">
                    <Package className="h-8 w-8 mx-auto mb-2 text-green-400" />
                    <div>No stock alerts - All inventory levels are healthy!</div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between text-xs text-muted-foreground pt-4 border-t border-border/30">
          <div className="flex items-center space-x-4">
            <div>
              <span className="font-medium">Critical:</span> Stock below 25% of reorder point
            </div>
            <div>
              <span className="font-medium">Warning:</span> Stock below 50% of reorder point
            </div>
          </div>
          
          <div>
            Last updated: {isLoading ? '...' : new Date(metrics?.lastUpdated || Date.now()).toLocaleTimeString()}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}