import { LucideIcon, TrendingUp, TrendingDown } from 'lucide-react';
import { Card, CardContent } from './ui/card';

interface MetricCardProps {
  title: string;
  value: string | number;
  icon?: LucideIcon;
  trend?: number;
  trendLabel?: string;
  className?: string;
}

export function MetricCard({ 
  title, 
  value, 
  icon: Icon, 
  trend, 
  trendLabel,
  className = '' 
}: MetricCardProps) {
  const formatValue = (val: string | number) => {
    if (typeof val === 'number') {
      // Handle large numbers with appropriate formatting
      if (val >= 1000000) {
        return (val / 1000000).toLocaleString('en-US', { 
          minimumFractionDigits: 1, 
          maximumFractionDigits: 1 
        }) + 'M';
      } else if (val >= 1000) {
        return val.toLocaleString('en-US');
      }
      return val.toString();
    }
    return val;
  };

  const getTrendColor = (trendValue?: number) => {
    if (trendValue === undefined) return 'trend-neutral';
    if (trendValue > 0) return 'trend-up';
    if (trendValue < 0) return 'trend-down';
    return 'trend-neutral';
  };

  const getTrendIcon = (trendValue?: number) => {
    if (trendValue === undefined) return null;
    if (trendValue > 0) return <TrendingUp className="h-3 w-3" />;
    if (trendValue < 0) return <TrendingDown className="h-3 w-3" />;
    return null;
  };

  return (
    <Card className={`metric-card min-h-[120px] ${className}`}>
      <CardContent className="p-6 h-full flex flex-col justify-between">
        <div className="flex items-center justify-between space-y-0 pb-2">
          <h3 className="tracking-tight text-sm font-medium text-muted-foreground">
            {title}
          </h3>
          {Icon && (
            <Icon className="h-4 w-4 text-muted-foreground" />
          )}
        </div>
        
        <div className="space-y-1">
          <div className="text-2xl font-bold text-foreground">
            {formatValue(value)}
          </div>
          
          {trend !== undefined && (
            <p className={`text-xs flex items-center gap-1 ${getTrendColor(trend)}`}>
              {getTrendIcon(trend)}
              <span>
                {trend > 0 ? '+' : ''}{trend.toFixed(1)}%
              </span>
              {trendLabel && (
                <span className="text-muted-foreground ml-1">
                  {trendLabel}
                </span>
              )}
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}