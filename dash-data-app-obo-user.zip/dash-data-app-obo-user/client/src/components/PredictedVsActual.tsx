import { useQuery } from '@tanstack/react-query';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Calendar, Filter } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

interface ComparisonDataPoint {
  date: string;
  actualDemand: number;
  predictedDemand: number;
  accuracy: number;
}

interface ComparisonMetrics {
  data: ComparisonDataPoint[];
  overallAccuracy: number;
  avgError: number;
  dateRange: {
    start: string;
    end: string;
  };
  totalDataPoints: number;
}

const fetchComparisonData = async (days: number = 30): Promise<ComparisonMetrics> => {
  const response = await fetch(`/api/dashboard/predicted-vs-actual?days=${days}`);
  if (!response.ok) {
    throw new Error('Failed to fetch comparison data');
  }
  return response.json();
};

export function PredictedVsActual() {
  const [timeRange, setTimeRange] = useState<number>(30);
  
  const { 
    data: metrics, 
    isLoading, 
    error,
    refetch 
  } = useQuery({
    queryKey: ['predicted-vs-actual', timeRange],
    queryFn: () => fetchComparisonData(timeRange),
    refetchInterval: 300000, // Refresh every 5 minutes
  });

  const timeRangeOptions = [
    { label: '7 Days', value: 7 },
    { label: '30 Days', value: 30 },
    { label: '90 Days', value: 90 },
  ];

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('en-US').format(Math.round(num));
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  // Custom tooltip for the chart
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-background/95 backdrop-blur-sm border border-border/50 rounded-lg p-3 shadow-lg">
          <p className="text-foreground font-medium">{formatDate(label)}</p>
          <div className="space-y-1 mt-2">
            <p className="text-sm">
              <span className="text-blue-400">Actual: </span>
              <span className="text-foreground font-medium">{formatNumber(data.actualDemand)}</span>
            </p>
            <p className="text-sm">
              <span className="text-purple-400">Predicted: </span>
              <span className="text-foreground font-medium">{formatNumber(data.predictedDemand)}</span>
            </p>
            <p className="text-sm">
              <span className="text-muted-foreground">Accuracy: </span>
              <span className="text-foreground font-medium">{data.accuracy.toFixed(1)}%</span>
            </p>
          </div>
        </div>
      );
    }
    return null;
  };

  if (error) {
    return (
      <Card className="bg-card/50 backdrop-blur-sm border-destructive/20">
        <CardContent className="p-6">
          <div className="flex items-center space-x-2 text-destructive">
            <TrendingUp className="h-5 w-5" />
            <span>Failed to load comparison data</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card/50 backdrop-blur-sm border-border/50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <TrendingUp className="h-5 w-5 text-green-400" />
            <div>
              <CardTitle className="text-foreground">Out-of-Sample Analysis</CardTitle>
              <CardDescription>
                Forecast accuracy comparison over time
              </CardDescription>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <div className="flex space-x-1">
              {timeRangeOptions.map((option) => (
                <Button
                  key={option.value}
                  variant={timeRange === option.value ? "default" : "outline"}
                  size="sm"
                  onClick={() => setTimeRange(option.value)}
                  className="h-8 px-3 text-xs"
                >
                  {option.label}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Summary Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-3 rounded-lg bg-green-500/10 border border-green-500/20">
            <div className="text-xl font-bold text-foreground">
              {isLoading ? '...' : `${metrics?.overallAccuracy?.toFixed(1) ?? '0'}%`}
            </div>
            <div className="text-xs text-muted-foreground">Overall Accuracy</div>
          </div>
          
          <div className="text-center p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
            <div className="text-xl font-bold text-foreground">
              {isLoading ? '...' : formatNumber(Math.abs(metrics?.avgError ?? 0))}
            </div>
            <div className="text-xs text-muted-foreground">Avg Error (units)</div>
          </div>
          
          <div className="text-center p-3 rounded-lg bg-purple-500/10 border border-purple-500/20">
            <div className="text-xl font-bold text-foreground">
              {isLoading ? '...' : formatNumber(metrics?.totalDataPoints ?? 0)}
            </div>
            <div className="text-xs text-muted-foreground">Data Points</div>
          </div>
        </div>

        {/* Chart */}
        <div className="h-80">
          {isLoading ? (
            <div className="h-full bg-muted/10 rounded-lg animate-pulse flex items-center justify-center">
              <div className="text-muted-foreground">Loading chart data...</div>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={metrics?.data ?? []}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis 
                  dataKey="date" 
                  tickFormatter={formatDate}
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: 'rgb(156, 163, 175)', fontSize: 12 }}
                />
                <YAxis 
                  tickFormatter={formatNumber}
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: 'rgb(156, 163, 175)', fontSize: 12 }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend 
                  wrapperStyle={{ 
                    paddingTop: '20px',
                    fontSize: '14px',
                    color: 'rgb(156, 163, 175)'
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="actualDemand" 
                  stroke="rgb(59, 130, 246)" 
                  strokeWidth={2}
                  name="Actual Demand"
                  dot={{ fill: 'rgb(59, 130, 246)', strokeWidth: 2, r: 3 }}
                  activeDot={{ r: 5, fill: 'rgb(59, 130, 246)' }}
                />
                <Line 
                  type="monotone" 
                  dataKey="predictedDemand" 
                  stroke="rgb(168, 85, 247)" 
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  name="Predicted Demand"
                  dot={{ fill: 'rgb(168, 85, 247)', strokeWidth: 2, r: 3 }}
                  activeDot={{ r: 5, fill: 'rgb(168, 85, 247)' }}
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Date Range Info */}
        <div className="flex items-center justify-between text-xs text-muted-foreground pt-4 border-t border-border/30">
          <div className="flex items-center space-x-1">
            <Calendar className="h-3 w-3" />
            <span>
              {isLoading ? 'Loading...' : 
                metrics ? `${formatDate(metrics.dateRange.start)} - ${formatDate(metrics.dateRange.end)}` : 
                'No data available'
              }
            </span>
          </div>
          
          <div className="flex items-center space-x-2">
            <Badge variant="outline" className="text-xs">
              {timeRange} day view
            </Badge>
            <span>Updated every 5 minutes</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}