import { useState, useEffect } from 'react';

interface AnimatedCounterProps {
  from?: number;
  to: number;
  duration?: number;
  formatFn?: (value: number) => string;
  className?: string;
}

export function AnimatedCounter({ 
  from = 0, 
  to, 
  duration = 2000,
  formatFn = (value) => value.toLocaleString(),
  className = ""
}: AnimatedCounterProps) {
  const [count, setCount] = useState(from);

  useEffect(() => {
    let startTime: number | null = null;
    let animationId: number;

    const animate = (timestamp: number) => {
      if (startTime === null) startTime = timestamp;
      
      const progress = Math.min((timestamp - startTime) / duration, 1);
      
      // Easing function for smooth animation
      const easeOut = 1 - Math.pow(1 - progress, 3);
      
      const current = from + (to - from) * easeOut;
      setCount(Math.floor(current));

      if (progress < 1) {
        animationId = requestAnimationFrame(animate);
      } else {
        setCount(to);
      }
    };

    animationId = requestAnimationFrame(animate);
    
    return () => {
      if (animationId) {
        cancelAnimationFrame(animationId);
      }
    };
  }, [from, to, duration]);

  return (
    <span className={className}>
      {formatFn(count)}
    </span>
  );
}