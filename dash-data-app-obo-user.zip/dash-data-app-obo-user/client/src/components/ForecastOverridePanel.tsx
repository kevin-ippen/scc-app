import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  CalendarIcon,
  Save,
  X,
  Edit2,
  TrendingUp,
  AlertCircle,
  Calculator,
  FileText,
  Database
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { useToast } from '@/components/ui/use-toast';

interface ForecastOverride {
  override_id?: string;
  product_id: string;
  location_id: string;
  forecast_date: Date | string;
  original_forecast: number;
  override_value: number;
  override_type: 'absolute' | 'incremental' | 'percentage';
  calculation_method: 'replace' | 'average' | 'weighted' | 'incremental';
  final_forecast?: number;
  override_reason: string;
  business_justification?: string;
  approval_status?: string;
  created_by?: string;
  created_at?: string;
}

interface ForecastOverridePanelProps {
  productId: string;
  locationId: string;
  forecastDate: Date;
  originalForecast: number;
  currentOverride?: ForecastOverride;
  onSave?: (override: ForecastOverride) => void;
  onCancel?: () => void;
}

export function ForecastOverridePanel({
  productId,
  locationId,
  forecastDate,
  originalForecast,
  currentOverride,
  onSave,
  onCancel
}: ForecastOverridePanelProps) {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(!currentOverride);
  const [isSaving, setIsSaving] = useState(false);
  const [sqlCommand, setSqlCommand] = useState<string | null>(null);
  const [overrideValue, setOverrideValue] = useState(currentOverride?.override_value || originalForecast);
  const [overrideType, setOverrideType] = useState<'absolute' | 'incremental' | 'percentage'>(
    currentOverride?.override_type || 'absolute'
  );
  const [calculationMethod, setCalculationMethod] = useState<'replace' | 'average' | 'weighted' | 'incremental'>(
    currentOverride?.calculation_method || 'replace'
  );
  const [reason, setReason] = useState(currentOverride?.override_reason || '');
  const [justification, setJustification] = useState(currentOverride?.business_justification || '');
  const [finalForecast, setFinalForecast] = useState<number>(currentOverride?.final_forecast || originalForecast);

  // Calculate final forecast whenever inputs change
  useEffect(() => {
    const calculated = calculateFinalForecast(
      originalForecast,
      overrideValue,
      calculationMethod,
      overrideType
    );
    setFinalForecast(calculated);
  }, [originalForecast, overrideValue, calculationMethod, overrideType]);

  const calculateFinalForecast = (
    original: number,
    override: number,
    method: string,
    type: string
  ): number => {
    let actualOverride = override;

    // Convert based on type
    if (type === 'percentage') {
      actualOverride = original * (1 + override / 100);
    } else if (type === 'incremental') {
      actualOverride = original + override;
    }

    // Apply calculation method
    switch (method) {
      case 'replace':
        return actualOverride;
      case 'average':
        return (original + actualOverride) / 2;
      case 'weighted':
        return (original * 0.7) + (actualOverride * 0.3);
      case 'incremental':
        return original + (actualOverride - original);
      default:
        return actualOverride;
    }
  };

  const handleSave = () => {
    // Validate reason field
    if (!reason.trim()) {
      toast({
        title: "Validation Error",
        description: "Please provide a reason for the override",
        variant: "destructive"
      });
      return;
    }

    // Create override object
    const override: ForecastOverride = {
      ...currentOverride,
      product_id: productId,
      location_id: locationId,
      forecast_date: forecastDate,
      original_forecast: originalForecast,
      override_value: overrideValue,
      override_type: overrideType,
      calculation_method: calculationMethod,
      final_forecast: finalForecast,
      override_reason: reason,
      business_justification: justification,
      created_by: 'current_user' // Would come from auth context
    };

    // Generate SQL command for display
    const sql = `INSERT INTO fe_shared_demo.forecast_overrides
  (product_id, location_id, forecast_date, original_forecast,
   override_value, override_type, calculation_method, final_forecast,
   override_reason, business_justification, created_by, created_at)
VALUES
  ('${productId}', '${locationId}', '${format(new Date(forecastDate), 'yyyy-MM-dd')}', ${originalForecast},
   ${overrideValue}, '${overrideType}', '${calculationMethod}', ${finalForecast.toFixed(2)},
   '${reason}', '${justification || 'NULL'}', 'current_user', NOW());`;

    setSqlCommand(sql);

    // Let parent component handle the save with progressive toasts
    if (onSave) {
      onSave(override);
    }

    // Close editing mode
    setIsEditing(false);
  };

  const getImpactColor = () => {
    const percentChange = ((finalForecast - originalForecast) / originalForecast) * 100;
    if (Math.abs(percentChange) < 5) return 'text-yellow-600';
    if (Math.abs(percentChange) < 15) return 'text-orange-600';
    return 'text-red-600';
  };

  const getImpactBadge = () => {
    const percentChange = ((finalForecast - originalForecast) / originalForecast) * 100;
    const sign = percentChange > 0 ? '+' : '';
    return `${sign}${percentChange.toFixed(1)}%`;
  };

  return (
    <Card className="w-full bg-card/90 backdrop-blur-sm border-border">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CardTitle className="text-lg font-semibold bg-gradient-to-r from-blue-400 to-emerald-400 bg-clip-text text-transparent">
              Forecast Override
            </CardTitle>
            <Badge variant="outline" className="bg-amber-500/10 border-amber-500/30 text-amber-400">
              <Database className="h-3 w-3 mr-1" />
              LakeBase
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            {currentOverride?.approval_status && (
              <Badge variant={currentOverride.approval_status === 'approved' ? 'default' : 'secondary'}>
                {currentOverride.approval_status}
              </Badge>
            )}
            {!isEditing && (
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setIsEditing(true)}
              >
                <Edit2 className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Product & Location Info */}
        <div className="grid grid-cols-2 gap-4 p-3 bg-muted/50 rounded-lg">
          <div>
            <Label className="text-xs text-muted-foreground">Product ID</Label>
            <p className="text-sm font-medium text-foreground">{productId}</p>
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">Location</Label>
            <p className="text-sm font-medium text-foreground">{locationId}</p>
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">Forecast Date</Label>
            <p className="text-sm font-medium text-foreground">
              {format(new Date(forecastDate), 'MMM dd, yyyy')}
            </p>
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">Original Forecast</Label>
            <p className="text-sm font-medium text-foreground">
              {originalForecast.toLocaleString()}
            </p>
          </div>
        </div>

        {/* Override Configuration */}
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Override Type</Label>
              <Select
                value={overrideType}
                onValueChange={(v) => setOverrideType(v as any)}
                disabled={!isEditing}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="absolute">Absolute Value</SelectItem>
                  <SelectItem value="incremental">Incremental (+/-)</SelectItem>
                  <SelectItem value="percentage">Percentage Change</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Calculation Method</Label>
              <Select
                value={calculationMethod}
                onValueChange={(v) => setCalculationMethod(v as any)}
                disabled={!isEditing}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="replace">Replace</SelectItem>
                  <SelectItem value="average">Average</SelectItem>
                  <SelectItem value="weighted">Weighted (70/30)</SelectItem>
                  <SelectItem value="incremental">Incremental</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label>Override Value</Label>
            <div className="relative">
              <Input
                type="number"
                value={overrideValue}
                onChange={(e) => setOverrideValue(parseFloat(e.target.value))}
                disabled={!isEditing}
                className="pr-12"
              />
              {overrideType === 'percentage' && (
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">%</span>
              )}
            </div>
          </div>

          <div>
            <Label>Reason for Override</Label>
            <Textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              disabled={!isEditing}
              placeholder="e.g., Upcoming promotion, competitor closure, seasonal event..."
              className="min-h-[80px]"
            />
          </div>

          <div>
            <Label>Business Justification (Optional)</Label>
            <Textarea
              value={justification}
              onChange={(e) => setJustification(e.target.value)}
              disabled={!isEditing}
              placeholder="Additional context or business rationale..."
              className="min-h-[60px]"
            />
          </div>
        </div>

        {/* Impact Summary */}
        <div className="p-4 bg-muted/50 rounded-lg border border-border">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">Final Forecast</span>
            <div className="flex items-center gap-2">
              <Calculator className="h-4 w-4 text-muted-foreground" />
              <span className={cn("text-lg font-bold", getImpactColor())}>
                {finalForecast.toLocaleString()}
              </span>
              <Badge variant="outline" className={getImpactColor()}>
                {getImpactBadge()}
              </Badge>
            </div>
          </div>

          <div className="flex items-start gap-2 mt-3">
            <AlertCircle className="h-4 w-4 text-amber-500 mt-0.5" />
            <p className="text-xs text-muted-foreground">
              This override will {finalForecast > originalForecast ? 'increase' : 'decrease'} the forecast by{' '}
              <span className="font-semibold">
                {Math.abs(finalForecast - originalForecast).toLocaleString()}
              </span>{' '}
              units using the <span className="font-semibold">{calculationMethod}</span> method.
            </p>
          </div>
        </div>

        {/* SQL Command Display */}
        {sqlCommand && isSaving && (
          <div className="p-3 bg-card/80 rounded-lg border border-amber-500/30">
            <div className="flex items-center gap-2 mb-2">
              <Database className="h-4 w-4 text-amber-400 animate-pulse" />
              <span className="text-xs font-medium text-amber-400">Executing on LakeBase</span>
            </div>
            <pre className="text-xs text-muted-foreground font-mono overflow-x-auto whitespace-pre-wrap">
              {sqlCommand}
            </pre>
          </div>
        )}

        {/* Actions */}
        {isEditing && (
          <div className="flex justify-end gap-2 pt-2">
            <Button
              variant="ghost"
              onClick={() => {
                setIsEditing(false);
                setSqlCommand(null);
                if (onCancel) onCancel();
              }}
              disabled={isSaving}
            >
              <X className="h-4 w-4 mr-1" />
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              disabled={isSaving}
              className="bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 disabled:opacity-50"
            >
              {isSaving ? (
                <>
                  <Database className="h-4 w-4 mr-1 animate-pulse" />
                  Writing to LakeBase...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-1" />
                  Save Override
                </>
              )}
            </Button>
          </div>
        )}

        {/* Metadata */}
        {currentOverride?.created_at && (
          <div className="text-xs text-muted-foreground pt-2 border-t border-border">
            Created by {currentOverride.created_by} on {format(new Date(currentOverride.created_at), 'MMM dd, yyyy')}
          </div>
        )}
      </CardContent>
    </Card>
  );
}