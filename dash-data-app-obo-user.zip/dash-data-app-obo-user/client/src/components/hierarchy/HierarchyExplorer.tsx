import { useState } from 'react';
import { ChevronRight, ChevronDown, Building2, Package, Box, AlertCircle, CheckCircle, AlertTriangle } from 'lucide-react';
import { HierarchyNode } from '@/data/mockForecastData';
import { Card } from '@/components/ui/card';

interface HierarchyExplorerProps {
  data: HierarchyNode[];
  onNodeSelect?: (node: HierarchyNode) => void;
  defaultExpanded?: string[];
}

// Format numbers
const formatNumber = (num: number): string => {
  return new Intl.NumberFormat('en-US').format(num);
};

// Get icon by node type
const getNodeIcon = (type: string) => {
  switch (type) {
    case 'partner':
      return Building2;
    case 'category':
      return Package;
    case 'brand':
      return Box;
    default:
      return Package;
  }
};

// Get indent level
const getIndentClass = (level: number) => {
  const indents = [
    'pl-2',
    'pl-8',
    'pl-16',
    'pl-24'
  ];
  return indents[level] || 'pl-2';
};

// Stock risk badge
const StockRiskBadge = ({ risk }: { risk: 'low' | 'medium' | 'high' }) => {
  const config = {
    low: { icon: CheckCircle, color: 'text-green-500', bg: 'bg-green-500/10' },
    medium: { icon: AlertTriangle, color: 'text-amber-500', bg: 'bg-amber-500/10' },
    high: { icon: AlertCircle, color: 'text-red-500', bg: 'bg-red-500/10' }
  };

  const { icon: Icon, color, bg } = config[risk];

  return (
    <div className={`flex items-center gap-1 px-2 py-0.5 rounded ${bg}`}>
      <Icon className={`h-3 w-3 ${color}`} />
    </div>
  );
};

// Accuracy badge with color
const AccuracyBadge = ({ accuracy }: { accuracy: number }) => {
  const getColor = () => {
    if (accuracy >= 100 && accuracy <= 110) return 'text-green-500 bg-green-500/10';
    if (accuracy >= 90 && accuracy < 100) return 'text-amber-500 bg-amber-500/10';
    if (accuracy > 110) return 'text-blue-500 bg-blue-500/10';
    return 'text-red-500 bg-red-500/10';
  };

  return (
    <div className={`px-2 py-0.5 rounded text-xs font-semibold ${getColor()}`}>
      {accuracy.toFixed(1)}%
    </div>
  );
};

// Recursive tree node component
function TreeNode({
  node,
  level = 0,
  expandedIds,
  selectedId,
  onToggle,
  onSelect,
}: {
  node: HierarchyNode;
  level?: number;
  expandedIds: Set<string>;
  selectedId: string | null;
  onToggle: (id: string) => void;
  onSelect: (node: HierarchyNode) => void;
}) {
  const isExpanded = expandedIds.has(node.id);
  const isSelected = selectedId === node.id;
  const hasChildren = node.children && node.children.length > 0;
  const Icon = getNodeIcon(node.type);

  const handleClick = () => {
    onSelect(node);
    if (hasChildren) {
      onToggle(node.id);
    }
  };

  return (
    <div>
      {/* Node Row */}
      <div
        className={`
          flex items-center gap-3 py-2 px-2 cursor-pointer
          hover:bg-blue-500/10 transition-colors border-b border-border/50
          ${isSelected ? 'bg-blue-500/20' : ''}
          ${getIndentClass(level)}
        `}
        onClick={handleClick}
      >
        {/* Expand/Collapse Icon */}
        <div className="w-4 h-4 flex items-center justify-center">
          {hasChildren && (
            isExpanded ? (
              <ChevronDown className="h-4 w-4 text-blue-400" />
            ) : (
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            )
          )}
        </div>

        {/* Node Icon */}
        <Icon className={`h-4 w-4 ${
          node.type === 'partner' ? 'text-blue-500' :
          node.type === 'category' ? 'text-purple-500' :
          node.type === 'brand' ? 'text-emerald-500' :
          'text-amber-500'
        }`} />

        {/* Node Name */}
        <div className="flex-1 min-w-0">
          <div className={`font-medium ${
            node.type === 'partner' ? 'text-blue-300 text-base' :
            node.type === 'category' ? 'text-purple-300' :
            'text-foreground'
          }`}>
            {node.name}
          </div>
        </div>

        {/* Metrics */}
        <div className="flex items-center gap-4 text-sm">
          <div className="text-right min-w-[80px]">
            <div className="text-muted-foreground text-xs">Unit Sales</div>
            <div className="font-mono font-semibold">{formatNumber(node.metrics.unitSales)}</div>
          </div>

          <div className="text-right min-w-[80px]">
            <div className="text-muted-foreground text-xs">Forecast (SHA)</div>
            <div className="font-mono text-green-400">{formatNumber(node.metrics.forecastSHA)}</div>
          </div>

          <div className="text-right min-w-[80px]">
            <div className="text-muted-foreground text-xs">Forecast (GAM)</div>
            <div className="font-mono text-purple-400">{formatNumber(node.metrics.forecastGAM)}</div>
          </div>

          <div className="text-right min-w-[70px]">
            <div className="text-muted-foreground text-xs mb-0.5">Accuracy</div>
            <AccuracyBadge accuracy={node.metrics.accuracy} />
          </div>

          <div className="min-w-[50px] flex justify-center">
            <StockRiskBadge risk={node.metrics.stockRisk} />
          </div>
        </div>
      </div>

      {/* Children (Recursive) */}
      {hasChildren && isExpanded && (
        <div>
          {node.children!.map((child) => (
            <TreeNode
              key={child.id}
              node={child}
              level={level + 1}
              expandedIds={expandedIds}
              selectedId={selectedId}
              onToggle={onToggle}
              onSelect={onSelect}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function HierarchyExplorer({ data, onNodeSelect, defaultExpanded = [] }: HierarchyExplorerProps) {
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set(defaultExpanded));
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const handleToggle = (id: string) => {
    setExpandedIds((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const handleSelect = (node: HierarchyNode) => {
    setSelectedId(node.id);
    if (onNodeSelect) {
      onNodeSelect(node);
    }
  };

  return (
    <Card className="bg-card/30 backdrop-blur-sm border-border overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 py-3 px-4 bg-blue-500/10 border-b border-border">
        <div className="flex-1 flex items-center gap-3">
          <div className="w-4"></div>
          <div className="w-4"></div>
          <div className="font-semibold text-blue-300">Hierarchy</div>
        </div>
        <div className="flex items-center gap-4 text-xs text-muted-foreground font-medium">
          <div className="min-w-[80px] text-right">Unit Sales</div>
          <div className="min-w-[80px] text-right">Forecast (SHA)</div>
          <div className="min-w-[80px] text-right">Forecast (GAM)</div>
          <div className="min-w-[70px] text-right">Accuracy</div>
          <div className="min-w-[50px] text-center">Risk</div>
        </div>
      </div>

      {/* Tree */}
      <div className="max-h-[600px] overflow-y-auto">
        {data.map((node) => (
          <TreeNode
            key={node.id}
            node={node}
            level={0}
            expandedIds={expandedIds}
            selectedId={selectedId}
            onToggle={handleToggle}
            onSelect={handleSelect}
          />
        ))}
      </div>
    </Card>
  );
}
