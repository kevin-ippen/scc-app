import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface DataPoint {
  date: string;
  actual_value: number | null;
  forecast_value: number;
  forecast_lower: number;
  forecast_upper: number;
  is_historical: boolean;
}

interface MonthlyData {
  month: string;
  year: number;
  historicalData: number | null;
  forecastValue: number;
  forecastLower: number;
  forecastUpper: number;
  variance: number | null;
  isFuture: boolean;
  isPartialForecast: boolean;
}

interface ForecastSummaryTableProps {
  data: DataPoint[];
  title?: string;
  className?: string;
}

export function ForecastSummaryTable({
  data,
  title = "Monthly Forecast Summary",
  className = ''
}: ForecastSummaryTableProps) {
  // Aggregate data by month
  const aggregateByMonth = (data: DataPoint[]): MonthlyData[] => {
    const monthlyMap = new Map<string, {
      dates: DataPoint[],
      month: string,
      year: number,
      hasHistorical: boolean,
      hasForecast: boolean
    }>();

    // Group by month
    data.forEach(point => {
      const date = new Date(point.date);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      const monthName = date.toLocaleDateString('en-US', { month: 'short' });
      const year = date.getFullYear();

      if (!monthlyMap.has(monthKey)) {
        monthlyMap.set(monthKey, {
          dates: [],
          month: monthName,
          year: year,
          hasHistorical: false,
          hasForecast: false
        });
      }

      const monthData = monthlyMap.get(monthKey)!;
      monthData.dates.push(point);

      if (point.is_historical && point.actual_value !== null) {
        monthData.hasHistorical = true;
      }
      if (point.forecast_value !== null) {
        monthData.hasForecast = true;
      }
    });

    // Calculate monthly aggregates
    const currentDate = new Date();
    const currentMonthKey = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}`;

    return Array.from(monthlyMap.entries())
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([key, value]) => {
        const historicalPoints = value.dates.filter(d => d.is_historical && d.actual_value !== null);
        const forecastPoints = value.dates.filter(d => d.forecast_value !== null);

        const historicalAvg = historicalPoints.length > 0
          ? historicalPoints.reduce((sum, d) => sum + (d.actual_value || 0), 0) / historicalPoints.length
          : null;

        const forecastAvg = forecastPoints.length > 0
          ? forecastPoints.reduce((sum, d) => sum + d.forecast_value, 0) / forecastPoints.length
          : 0;

        const lowerAvg = forecastPoints.length > 0
          ? forecastPoints.reduce((sum, d) => sum + d.forecast_lower, 0) / forecastPoints.length
          : 0;

        const upperAvg = forecastPoints.length > 0
          ? forecastPoints.reduce((sum, d) => sum + d.forecast_upper, 0) / forecastPoints.length
          : 0;

        // Determine if month is in the future (no historical data)
        const isFuture = key > currentMonthKey;

        // Check if month is partially in forecast horizon
        const isPartialForecast = value.hasHistorical && value.hasForecast;

        // Calculate variance between historical and forecast if both exist
        const variance = (historicalAvg !== null && forecastAvg !== null && forecastAvg > 0)
          ? ((forecastAvg - historicalAvg) / historicalAvg) * 100
          : null;

        return {
          month: value.month,
          year: value.year,
          historicalData: historicalAvg,
          forecastValue: forecastAvg,
          forecastLower: lowerAvg,
          forecastUpper: upperAvg,
          variance,
          isFuture,
          isPartialForecast
        };
      })
      .slice(-6); // Show last 6 months
  };

  const formatNumber = (num: number | null): string => {
    if (num === null) return '-';
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(0)}K`;
    return num.toFixed(0);
  };

  const getVarianceIcon = (variance: number | null) => {
    if (variance === null) return null;
    if (Math.abs(variance) < 1) return <Minus className="h-3 w-3 text-muted-foreground" />;
    if (variance > 0) return <TrendingUp className="h-3 w-3 text-green-500" />;
    return <TrendingDown className="h-3 w-3 text-red-500" />;
  };

  const monthlyData = aggregateByMonth(data);

  return (
    <Card className={`bg-card/50 backdrop-blur-sm ${className}`}>
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-foreground">
          {title}
        </CardTitle>
        <CardDescription className="text-muted-foreground">
          Historical performance and future predictions by month
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b-2 border-border">
                <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground min-w-[140px]">
                  {/* Empty cell for row headers */}
                </th>
                {monthlyData.map((month) => (
                  <th
                    key={`${month.month}-${month.year}`}
                    className="text-center py-3 px-4 text-sm font-medium min-w-[120px]"
                  >
                    <div className="flex flex-col items-center">
                      <span className="text-foreground font-semibold">
                        {month.month}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {month.year}
                      </span>
                      {month.isFuture && (
                        <Badge variant="outline" className="mt-1 text-xs">
                          Future
                        </Badge>
                      )}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {/* Historical Data Row */}
              <tr className="border-b border-border/50 hover:bg-muted/10 transition-colors">
                <td className="py-3 px-4 font-medium text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                    <span>Historical Data</span>
                  </div>
                </td>
                {monthlyData.map((month) => (
                  <td
                    key={`hist-${month.month}-${month.year}`}
                    className="text-center py-3 px-4"
                  >
                    <span className={`font-semibold ${
                      month.historicalData !== null
                        ? 'text-blue-500'
                        : month.isFuture
                          ? 'text-muted-foreground/40 italic text-sm'
                          : 'text-muted-foreground'
                    }`}>
                      {month.historicalData !== null
                        ? formatNumber(month.historicalData)
                        : month.isFuture
                          ? 'N/A'
                          : '-'
                      }
                    </span>
                  </td>
                ))}
              </tr>

              {/* Forecast Row */}
              <tr className="border-b border-border/50 hover:bg-muted/10 transition-colors">
                <td className="py-3 px-4 font-medium text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-green-500"></div>
                    <span>Forecast</span>
                  </div>
                </td>
                {monthlyData.map((month) => (
                  <td
                    key={`forecast-${month.month}-${month.year}`}
                    className="text-center py-3 px-4"
                  >
                    <div>
                      <span className="font-semibold text-green-500">
                        {formatNumber(month.forecastValue)}
                      </span>
                      {month.variance !== null && (
                        <div className="flex items-center justify-center gap-1 mt-1">
                          {getVarianceIcon(month.variance)}
                          <span className={`text-xs ${
                            Math.abs(month.variance) < 1
                              ? 'text-muted-foreground'
                              : month.variance > 0
                                ? 'text-green-500'
                                : 'text-red-500'
                          }`}>
                            {Math.abs(month.variance) >= 1 && (
                              `${month.variance > 0 ? '+' : ''}${month.variance.toFixed(1)}%`
                            )}
                          </span>
                        </div>
                      )}
                      <div className="text-xs text-muted-foreground/70 mt-1">
                        [{formatNumber(month.forecastLower)} - {formatNumber(month.forecastUpper)}]
                      </div>
                    </div>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>

        <div className="mt-6 space-y-3">
          {/* Legend */}
          <div className="flex flex-wrap items-center gap-6 text-xs text-muted-foreground">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-blue-500"></div>
              <span>Historical Data - Actual recorded values</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500"></div>
              <span>Forecast - Model predictions with confidence intervals</span>
            </div>
          </div>

          {/* Note */}
          <div className="text-xs text-muted-foreground bg-muted/30 rounded-lg p-3">
            <strong>Note:</strong> Historical values shown for past months. Future months display forecasts only.
            Confidence intervals shown in brackets represent the predicted range based on model uncertainty.
          </div>
        </div>
      </CardContent>
    </Card>
  );
}