import React from 'react';
import { usePersona, usePersonaSwitcher } from '@/context/PersonaContext';
import { getAllPersonas } from '@/config/personas';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';

export function PersonaSwitcher() {
  const { currentPersona } = usePersona();
  const setPersona = usePersonaSwitcher();
  const personas = getAllPersonas();

  const handlePersonaChange = (personaId: string) => {
    const persona = personas.find(p => p.id === personaId);
    if (persona) {
      setPersona(persona);
    }
  };

  return (
    <div className="flex items-center gap-3 px-4 py-2 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-lg border border-blue-500/30">
      <Label htmlFor="persona-select" className="text-blue-300 whitespace-nowrap font-bold text-sm">
        Switch Role:
      </Label>
      <Select value={currentPersona.id} onValueChange={handlePersonaChange}>
        <SelectTrigger
          id="persona-select"
          className="w-[300px] h-12 bg-blue-500/20 backdrop-blur-sm border-2 border-blue-400/50 hover:bg-blue-500/30 hover:border-blue-400 transition-all text-foreground font-semibold shadow-lg"
        >
          <div className="flex items-center gap-2 py-1">
            <currentPersona.icon className="h-5 w-5 text-blue-300 flex-shrink-0" />
            <span className="truncate"><SelectValue /></span>
          </div>
        </SelectTrigger>
        <SelectContent className="w-[320px] bg-card border-white/20">
          {personas.map((persona) => {
            const Icon = persona.icon;
            return (
              <SelectItem
                key={persona.id}
                value={persona.id}
                className="py-2 text-foreground hover:bg-white/10"
              >
                <div className="flex items-center gap-3">
                  <Icon className="h-4 w-4 text-foreground/70 flex-shrink-0" />
                  <div className="flex flex-col">
                    <span className="font-medium text-foreground">{persona.label}</span>
                    {persona.description && (
                      <span className="text-xs text-foreground/60">
                        {persona.description}
                      </span>
                    )}
                  </div>
                </div>
              </SelectItem>
            );
          })}
        </SelectContent>
      </Select>
    </div>
  );
}