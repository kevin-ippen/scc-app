import {
  ComposedChart,
  Line,
  Area,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  ResponsiveContainer,
  Dot,
} from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';

interface DataPoint {
  date: string;
  actual_value: number | null;
  forecast_value: number;
  forecast_lower: number;
  forecast_upper: number;
  is_historical: boolean;
}

interface EnhancedForecastChartProps {
  data: DataPoint[];
  title?: string;
  subtitle?: string;
  className?: string;
}

export function EnhancedForecastChart({
  data,
  title = "Demand Forecast Analysis",
  subtitle = "Historical performance and future predictions with confidence intervals",
  className = ''
}: EnhancedForecastChartProps) {
  if (!data || data.length === 0) {
    return (
      <Card className={`bg-card/50 backdrop-blur-sm ${className}`}>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-foreground">
            {title}
          </CardTitle>
          <CardDescription className="text-muted-foreground">
            {subtitle}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-96 w-full flex items-center justify-center text-muted-foreground">
            No data available
          </div>
        </CardContent>
      </Card>
    );
  }

  // Transform data for Recharts
  const chartData = data.map((point) => {
    const date = new Date(point.date);
    return {
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      fullDate: point.date,
      actual: point.actual_value,
      forecast: point.forecast_value,
      lower: point.forecast_lower,
      upper: point.forecast_upper,
      isHistorical: point.is_historical,
      // Separate confidence intervals for historical and future
      historicalConfidence: point.is_historical ? [point.forecast_lower, point.forecast_upper] : null,
      futureConfidence: !point.is_historical ? [point.forecast_lower, point.forecast_upper] : null,
    };
  });

  // Find today's date position for the reference line
  const today = new Date().toISOString().split('T')[0];
  const todayIndex = data.findIndex(d => d.date >= today);
  const todayLabel = todayIndex >= 0 ? chartData[todayIndex]?.date : chartData[chartData.length / 2]?.date;

  // Calculate Y-axis domain with padding to prevent touching top
  const allValues = chartData.flatMap(d => [
    d.actual,
    d.forecast,
    d.upper,
    d.lower
  ]).filter(v => v !== null && v !== undefined);

  const minValue = Math.min(...allValues);
  const maxValue = Math.max(...allValues);
  const padding = (maxValue - minValue) * 0.1; // Add 10% padding
  const yDomain = [Math.floor(minValue - padding), Math.ceil(maxValue + padding)];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-card/95 backdrop-blur-xl border border-border rounded-xl shadow-2xl p-4">
          <p className="text-sm font-bold text-foreground mb-3">{label}</p>
          <div className="space-y-2">
            {data.actual && (
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-blue-400 shadow-lg shadow-blue-400/50"></div>
                <span className="text-muted-foreground text-sm">Actual:</span>
                <span className="text-foreground font-semibold">
                  {data.actual?.toLocaleString()}
                </span>
              </div>
            )}
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-emerald-400 shadow-lg shadow-emerald-400/50"></div>
              <span className="text-muted-foreground text-sm">Forecast:</span>
              <span className="text-foreground font-semibold">
                {data.forecast?.toLocaleString()}
              </span>
            </div>
            <div className="pt-2 mt-2 border-t border-border">
              <p className="text-xs text-muted-foreground">
                Range: {data.lower?.toLocaleString()} - {data.upper?.toLocaleString()}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Type: <span className={data.isHistorical ? 'text-blue-400' : 'text-emerald-400'}>
                  {data.isHistorical ? 'Historical' : 'Predicted'}
                </span>
              </p>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  const formatYAxis = (value: number) => {
    return `${(value / 1000).toFixed(0)}k`;
  };

  return (
    <Card className={`bg-card/50 backdrop-blur-sm border-border ${className}`}>
      <CardHeader>
        <CardTitle className="text-xl font-bold bg-gradient-to-r from-blue-400 via-cyan-400 to-teal-400 bg-clip-text text-transparent">
          {title}
        </CardTitle>
        <CardDescription className="text-muted-foreground">
          {subtitle}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[450px] w-full p-4 bg-muted/30 rounded-xl">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartData} margin={{ top: 30, right: 30, left: 20, bottom: 30 }}>
              <defs>
                {/* Enhanced gradient for historical confidence bands */}
                <linearGradient id="confidenceGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#60A5FA" stopOpacity={0.3} />
                  <stop offset="50%" stopColor="#3B82F6" stopOpacity={0.1} />
                  <stop offset="100%" stopColor="#1E40AF" stopOpacity={0.02} />
                </linearGradient>

                {/* Enhanced gradient for future forecast confidence bands */}
                <linearGradient id="forecastConfidenceGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#34D399" stopOpacity={0.4} />
                  <stop offset="50%" stopColor="#10B981" stopOpacity={0.2} />
                  <stop offset="100%" stopColor="#059669" stopOpacity={0.05} />
                </linearGradient>

                {/* Glow effects */}
                <filter id="glow">
                  <feGaussianBlur stdDeviation="4" result="coloredBlur"/>
                  <feMerge>
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>

                <filter id="dotGlow">
                  <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                  <feMerge>
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>
              </defs>

              <CartesianGrid
                strokeDasharray="8 8"
                stroke="rgba(148, 163, 184, 0.08)"
                vertical={false}
              />

              <XAxis
                dataKey="date"
                axisLine={{ stroke: 'rgba(148, 163, 184, 0.2)' }}
                tickLine={false}
                tick={{ fill: '#94A3B8', fontSize: 11, fontWeight: 500 }}
                interval="preserveStartEnd"
              />

              <YAxis
                domain={yDomain}
                axisLine={{ stroke: 'rgba(148, 163, 184, 0.2)' }}
                tickLine={false}
                tick={{ fill: '#94A3B8', fontSize: 12, fontWeight: 500 }}
                tickFormatter={formatYAxis}
              />

              {/* Historical confidence interval */}
              <Area
                type="monotone"
                dataKey="historicalConfidence"
                stroke="none"
                fill="url(#confidenceGradient)"
                fillOpacity={0.6}
                name="Historical Confidence"
              />

              {/* Future forecast confidence interval - more prominent */}
              <Area
                type="monotone"
                dataKey="futureConfidence"
                stroke="none"
                fill="url(#forecastConfidenceGradient)"
                fillOpacity={0.8}
                name="Forecast Range"
              />

              {/* Enhanced forecast line with glow effect */}
              <Line
                type="monotone"
                dataKey="forecast"
                stroke="url(#forecastLineGradient)"
                strokeWidth={3}
                strokeDasharray="0"
                dot={false}
                name="Forecast"
                filter="url(#glow)"
              />

              <defs>
                <linearGradient id="forecastLineGradient" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#60A5FA" />
                  <stop offset="50%" stopColor="#34D399" />
                  <stop offset="100%" stopColor="#10B981" />
                </linearGradient>
              </defs>

              {/* Enhanced historical actual values with glow */}
              <Scatter
                dataKey="actual"
                fill="#60A5FA"
                name="Historical Actual"
                shape={(props: any) => {
                  if (props.payload.actual === null) return null;
                  return (
                    <circle
                      cx={props.cx}
                      cy={props.cy}
                      r={4}
                      fill="#60A5FA"
                      stroke="#1E40AF"
                      strokeWidth={1}
                      filter="url(#dotGlow)"
                      opacity={0.9}
                    />
                  );
                }}
              />

              {/* Enhanced today marker */}
              {todayLabel && (
                <ReferenceLine
                  x={todayLabel}
                  stroke="#F59E0B"
                  strokeWidth={2}
                  strokeDasharray="8 4"
                  strokeOpacity={0.6}
                  label={{
                    value: "TODAY",
                    position: "top",
                    fill: "#F59E0B",
                    fontSize: 12,
                    fontWeight: 600,
                    offset: 10
                  }}
                />
              )}

              <Tooltip content={<CustomTooltip />} />

              <Legend
                wrapperStyle={{
                  paddingTop: '20px',
                  fontSize: '13px',
                }}
                iconType="line"
                formatter={(value: string) => (
                  <span className="text-muted-foreground font-medium">{value}</span>
                )}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}