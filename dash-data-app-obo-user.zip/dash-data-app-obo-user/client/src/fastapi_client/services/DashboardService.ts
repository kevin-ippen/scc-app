/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DashboardMetrics } from '../models/DashboardMetrics';
import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';
export class DashboardService {
    /**
     * Get Dashboard Metrics
     * Get all dashboard metrics for the demand forecasting executive dashboard.
     *
     * Uses REAL Databricks data only. No automatic fallback to mock data.
     *
     * Returns:
     * DashboardMetrics: Complete set of metrics including KPIs and chart data
     *
     * Raises:
     * HTTPException: If unable to fetch metrics from Databricks data source
     * @returns DashboardMetrics Successful Response
     * @throws ApiError
     */
    public static getDashboardMetricsApiDashboardMetricsGet(): CancelablePromise<DashboardMetrics> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/dashboard/metrics',
        });
    }
    /**
     * Refresh Dashboard Metrics
     * Trigger a refresh of dashboard metrics.
     *
     * Returns:
     * Dictionary containing refresh status and updated metrics
     * @returns any Successful Response
     * @throws ApiError
     */
    public static refreshDashboardMetricsApiDashboardRefreshPost(): CancelablePromise<Record<string, any>> {
        return __request(OpenAPI, {
            method: 'POST',
            url: '/api/dashboard/refresh',
        });
    }
    /**
     * Dashboard Health
     * Check the health of the dashboard service.
     *
     * Returns:
     * Dictionary containing health status
     * @returns string Successful Response
     * @throws ApiError
     */
    public static dashboardHealthApiDashboardHealthGet(): CancelablePromise<Record<string, string>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/dashboard/health',
        });
    }
    /**
     * Test Databricks Connection
     * Test Databricks connection, warehouse access, and table accessibility.
     *
     * Returns:
     * Dictionary containing detailed connection test results
     * @returns any Successful Response
     * @throws ApiError
     */
    public static testDatabricksConnectionApiDashboardTestConnectionGet(): CancelablePromise<Record<string, any>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/dashboard/test-connection',
        });
    }
}
