/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CancelablePromise } from '../core/CancelablePromise';
import { OpenAPI } from '../core/OpenAPI';
import { request as __request } from '../core/request';
export class SupplyChainService {
    /**
     * Get Overview Metrics
     * Get supply chain overview metrics including KPI cards and category performance.
     *
     * Returns enterprise dashboard overview with:
     * - Current stock levels, inventory turnover, alerts
     * - Category performance heatmap data
     * - Low stock alerts table
     * @returns any Successful Response
     * @throws ApiError
     */
    public static getOverviewMetricsApiSupplyChainOverviewGet(): CancelablePromise<Record<string, any>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/supply-chain/overview',
        });
    }
    /**
     * Get Scale Metrics
     * Get real-time scale processing metrics.
     *
     * Returns scale operations data with:
     * - Active parallel jobs count
     * - Forecasts per second throughput
     * - Cluster utilization metrics
     * - Job execution history
     * @returns any Successful Response
     * @throws ApiError
     */
    public static getScaleMetricsApiSupplyChainScaleMetricsGet(): CancelablePromise<Record<string, any>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/supply-chain/scale-metrics',
        });
    }
    /**
     * Get Forecast Intelligence
     * Get forecast intelligence and model performance metrics.
     *
     * Returns forecasting data with:
     * - Forecast dimensions (stores × SKUs × models)
     * - Model comparison matrix
     * - Predicted vs actual trends
     * - Category demand distribution
     * @returns any Successful Response
     * @throws ApiError
     */
    public static getForecastIntelligenceApiSupplyChainForecastIntelligenceGet(): CancelablePromise<Record<string, any>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/supply-chain/forecast-intelligence',
        });
    }
    /**
     * Get Business Impact
     * Get business impact and ROI metrics.
     *
     * Returns business impact data with:
     * - Cost savings and efficiency improvements
     * - Processing time comparisons
     * - Scale simulator scenarios
     * - Investment ROI timeline
     * @returns any Successful Response
     * @throws ApiError
     */
    public static getBusinessImpactApiSupplyChainBusinessImpactGet(): CancelablePromise<Record<string, any>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/supply-chain/business-impact',
        });
    }
    /**
     * Get Filters
     * Get available filter options for dashboard components.
     *
     * Returns filter options including:
     * - Product categories
     * - Forecast models
     * - Regions and store types
     * - Time horizons
     * @returns any Successful Response
     * @throws ApiError
     */
    public static getFiltersApiSupplyChainFiltersGet(): CancelablePromise<Record<string, any>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/supply-chain/filters',
        });
    }
    /**
     * Get Realtime Metrics
     * Get a single snapshot of real-time metrics.
     *
     * Returns current real-time metrics for dashboard updates.
     * @returns any Successful Response
     * @throws ApiError
     */
    public static getRealtimeMetricsApiSupplyChainRealtimeGet(): CancelablePromise<Record<string, any>> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/supply-chain/realtime',
        });
    }
    /**
     * Stream Realtime Metrics
     * Server-sent events stream for real-time metrics updates.
     *
     * Provides continuous stream of real-time metrics for live dashboard updates.
     * @returns any Successful Response
     * @throws ApiError
     */
    public static streamRealtimeMetricsApiSupplyChainStreamGet(): CancelablePromise<any> {
        return __request(OpenAPI, {
            method: 'GET',
            url: '/api/supply-chain/stream',
        });
    }
}
