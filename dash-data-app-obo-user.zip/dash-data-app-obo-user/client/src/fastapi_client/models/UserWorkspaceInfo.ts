/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { UserInfo } from './UserInfo';
/**
 * User and workspace information.
 */
export type UserWorkspaceInfo = {
    user: UserInfo;
    workspace: Record<string, any>;
};

