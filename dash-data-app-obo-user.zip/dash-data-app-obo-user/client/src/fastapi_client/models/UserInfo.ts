/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Databricks user information.
 */
export type UserInfo = {
    userName: string;
    displayName?: (string | null);
    active: boolean;
    emails?: Array<string>;
};

