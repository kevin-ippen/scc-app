/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Model for forecast chart data point.
 */
export type ChartDataPoint = {
    date: string;
    yhat: number;
    yhat_lower: number;
    yhat_upper: number;
};

