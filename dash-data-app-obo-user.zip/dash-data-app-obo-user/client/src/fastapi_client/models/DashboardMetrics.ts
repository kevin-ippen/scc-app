/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ChartDataPoint } from './ChartDataPoint';
/**
 * Model for dashboard metrics response.
 */
export type DashboardMetrics = {
    lastUpdated: string;
    projectedMonthlyRevenue: number;
    totalForecastedUnits: number;
    overallDemandTrend: number;
    highVolatilityProducts: number;
    forecastChartData: Array<ChartDataPoint>;
};

