import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Persona, DEFAULT_PERSONA, getPersonaById, TabKey } from '@/config/personas';

interface PersonaContextType {
  currentPersona: Persona;
  setPersona: (persona: Persona) => void;
  isTabAllowed: (tabKey: TabKey) => boolean;
}

const PersonaContext = createContext<PersonaContextType | undefined>(undefined);

const PERSONA_STORAGE_KEY = 'selectedPersona';

export function PersonaProvider({ children }: { children: ReactNode }) {
  const [currentPersona, setCurrentPersona] = useState<Persona>(() => {
    // Try to load from localStorage
    const storedPersonaId = localStorage.getItem(PERSONA_STORAGE_KEY);
    if (storedPersonaId) {
      const persona = getPersonaById(storedPersonaId);
      if (persona) {
        return persona;
      }
    }
    return DEFAULT_PERSONA;
  });

  useEffect(() => {
    // Save to localStorage whenever persona changes
    localStorage.setItem(PERSONA_STORAGE_KEY, currentPersona.id);
  }, [currentPersona]);

  const setPersona = (persona: Persona) => {
    setCurrentPersona(persona);
  };

  const isTabAllowed = (tabKey: TabKey): boolean => {
    return currentPersona.allowedTabs.includes(tabKey);
  };

  return (
    <PersonaContext.Provider value={{ currentPersona, setPersona, isTabAllowed }}>
      {children}
    </PersonaContext.Provider>
  );
}

export function usePersona() {
  const context = useContext(PersonaContext);
  if (context === undefined) {
    throw new Error('usePersona must be used within a PersonaProvider');
  }
  return context;
}

export function usePersonaSwitcher() {
  const { setPersona } = usePersona();
  return setPersona;
}