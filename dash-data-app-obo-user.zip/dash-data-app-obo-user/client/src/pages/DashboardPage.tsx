import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useState, useEffect } from 'react';
import {
  DollarSign,
  Package,
  TrendingDown,
  AlertTriangle,
  Target,
  Warehouse
} from 'lucide-react';

import { DashboardHeader } from '../components/DashboardHeader';
import { MetricCard } from '../components/MetricCard';
import { ForecastChart } from '../components/ForecastChart';
import { InventoryHealth } from '../components/InventoryHealth';
import { LowStockAlerts } from '../components/LowStockAlerts';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScaleOperationsTab } from '@/components/tabs/ScaleOperationsTab';
import { ForecastIntelligenceTab } from '@/components/tabs/ForecastIntelligenceTab';
import { BusinessImpactTab } from '@/components/tabs/BusinessImpactTab';
import { AdvancedAnalyticsTab } from '@/components/tabs/AdvancedAnalyticsTab';
import { usePersona } from '../context/PersonaContext';
import { TabKey } from '../config/personas';

// API types (will be replaced by generated client)
interface ChartDataPoint {
  date: string;
  yhat: number;
  yhat_lower: number;
  yhat_upper: number;
}

interface DashboardMetrics {
  lastUpdated: string;
  projectedMonthlyRevenue: number;
  totalForecastedUnits: number;
  overallDemandTrend: number;
  highVolatilityProducts: number;
  forecastAccuracy: number;
  currentStockLevels: number;
  forecastChartData: ChartDataPoint[];
}

// Real API call for dashboard metrics (matches backend API)
const fetchDashboardMetrics = async (): Promise<DashboardMetrics> => {
  const response = await fetch('/api/dashboard/metrics');
  if (!response.ok) {
    throw new Error('Failed to fetch dashboard metrics from API');
  }
  return response.json();
};

export function DashboardPage() {
  const queryClient = useQueryClient();
  const { currentPersona, isTabAllowed } = usePersona();
  const [activeTab, setActiveTab] = useState<TabKey>(currentPersona.defaultTab);

  // Always realign selected tab with the persona currently in view.
  useEffect(() => {
    if (!isTabAllowed(activeTab)) {
      setActiveTab(currentPersona.defaultTab);
    }
  }, [currentPersona, activeTab, isTabAllowed]);

  const resolvedTab = isTabAllowed(activeTab) ? activeTab : currentPersona.defaultTab;

  const { 
    data: metrics, 
    isLoading, 
    error,
    refetch 
  } = useQuery({
    queryKey: ['dashboard-metrics'],
    queryFn: fetchDashboardMetrics,
    refetchInterval: 3000, // Refresh every 3 seconds for live feel (matches supply chain tabs)
    retry: 3,
  });

  const handleRefresh = async () => {
    await refetch();
    // Optionally trigger backend refresh
    try {
      await fetch('/api/dashboard/refresh', { method: 'POST' });
      // Invalidate and refetch after backend refresh
      setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: ['dashboard-metrics'] });
      }, 2000);
    } catch (error) {
      console.error('Failed to trigger backend refresh:', error);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('en-US').format(num);
  };

  if (error) {
    return (
      <div className="min-h-screen dashboard-gradient p-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="text-center">
              <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-foreground mb-2">
                Failed to Load Dashboard
              </h2>
              <p className="text-muted-foreground mb-4">
                Unable to fetch dashboard metrics. Please try again.
              </p>
              <button
                onClick={handleRefresh}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90"
              >
                Retry
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen dashboard-gradient p-8">
      <div className="max-w-7xl mx-auto">
        <DashboardHeader
          lastUpdated={metrics?.lastUpdated}
          onRefresh={handleRefresh}
          isLoading={isLoading}
        />

        {/* Databricks Scale-Focused Dashboard Tabs */}
        <Tabs value={resolvedTab} onValueChange={(value) => setActiveTab(value as TabKey)} className="space-y-6">
          <TabsList className="grid w-full grid-cols-auto bg-card/50 backdrop-blur-sm" style={{
            gridTemplateColumns: `repeat(${currentPersona.allowedTabs.length}, minmax(0, 1fr))`
          }}>
            {isTabAllowed('advanced-analytics') && (
              <TabsTrigger
                value="advanced-analytics"
                className="data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-700 dark:data-[state=active]:text-amber-300 font-medium text-foreground"
              >
                Advanced Analytics & Optimization
              </TabsTrigger>
            )}
            {isTabAllowed('forecast-intelligence') && (
              <TabsTrigger
                value="forecast-intelligence"
                className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-700 dark:data-[state=active]:text-purple-300 font-medium text-foreground"
              >
                Forecast Intelligence
              </TabsTrigger>
            )}
            {isTabAllowed('business-impact') && (
              <TabsTrigger
                value="business-impact"
                className="data-[state=active]:bg-emerald-500/20 data-[state=active]:text-emerald-700 dark:data-[state=active]:text-emerald-300 font-medium text-foreground"
              >
                Business Impact
              </TabsTrigger>
            )}
            {isTabAllowed('scale-operations') && (
              <TabsTrigger
                value="scale-operations"
                className="data-[state=active]:bg-blue-500/20 data-[state=active]:text-blue-700 dark:data-[state=active]:text-blue-300 font-medium relative text-foreground"
                title="Technical Deep Dive - ML Operations & Infrastructure"
              >
                <span className="flex items-center gap-2">
                  Scale Operations
                  <span className="text-xs opacity-60">(Tech Ops)</span>
                </span>
              </TabsTrigger>
            )}
          </TabsList>

          {isTabAllowed('advanced-analytics') && (
            <TabsContent value="advanced-analytics" className="space-y-6">
              <AdvancedAnalyticsTab />
            </TabsContent>
          )}

          {isTabAllowed('forecast-intelligence') && (
            <TabsContent value="forecast-intelligence" className="space-y-6">
              <ForecastIntelligenceTab />
            </TabsContent>
          )}

          {isTabAllowed('business-impact') && (
            <TabsContent value="business-impact" className="space-y-6">
            {/* Top metrics row - Symmetric 6 column grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <MetricCard
                title="Projected Monthly Revenue"
                value={metrics ? formatCurrency(metrics.projectedMonthlyRevenue) : '$0'}
                icon={DollarSign}
                className={isLoading ? 'animate-pulse' : ''}
              />

              <MetricCard
                title="Total Forecasted Units"
                value={metrics ? formatNumber(metrics.totalForecastedUnits) : '0'}
                icon={Package}
                className={isLoading ? 'animate-pulse' : ''}
              />

              <MetricCard
                title="Overall Demand Trend"
                value={metrics?.overallDemandTrend != null ? `${metrics.overallDemandTrend.toFixed(1)}%` : '0%'}
                icon={TrendingDown}
                trend={metrics?.overallDemandTrend}
                trendLabel="20.3%"
                className={isLoading ? 'animate-pulse' : ''}
              />

              <MetricCard
                title="High-Volatility Products"
                value={metrics?.highVolatilityProducts ?? '0'}
                icon={AlertTriangle}
                className={isLoading ? 'animate-pulse' : ''}
              />

              <MetricCard
                title="Forecast Accuracy"
                value={metrics?.forecastAccuracy != null ? `${metrics.forecastAccuracy.toFixed(1)}%` : '90.0%'}
                icon={Target}
                className={isLoading ? 'animate-pulse' : ''}
              />

              <MetricCard
                title="Current Stock Levels"
                value={metrics?.currentStockLevels != null ? formatNumber(metrics.currentStockLevels) : '0'}
                icon={Warehouse}
                className={isLoading ? 'animate-pulse' : ''}
              />
            </div>

              {/* Business Impact tab content with Inventory Health */}
              <BusinessImpactTab inventoryHealth={<InventoryHealth />} />
            </TabsContent>
          )}

          {isTabAllowed('scale-operations') && (
            <TabsContent value="scale-operations" className="space-y-6">
              <ScaleOperationsTab />
            </TabsContent>
          )}
        </Tabs>
      </div>
    </div>
  );
}
