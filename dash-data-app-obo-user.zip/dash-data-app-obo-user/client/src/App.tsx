import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { DashboardPage } from "./pages/DashboardPage";
import { Toaster } from "./components/ui/toaster";
import { PersonaProvider } from "./context/PersonaContext";
import { ThemeProvider } from "./context/ThemeContext";
import { GenieAssistant } from "./components/GenieAssistant";

// Create a query client instance
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      retry: 2,
    },
  },
});

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <PersonaProvider>
          <div className="min-h-screen bg-background">
            <DashboardPage />
            <GenieAssistant />
            <Toaster />
          </div>
        </PersonaProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
