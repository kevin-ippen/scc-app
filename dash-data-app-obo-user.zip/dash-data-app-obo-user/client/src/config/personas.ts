import { Code2, LineChart, Building2, LucideIcon } from 'lucide-react';

export type TabKey = 'forecast-intelligence' | 'advanced-analytics' | 'business-impact' | 'scale-operations';

export interface Persona {
  id: string;
  label: string;
  icon: LucideIcon;
  allowedTabs: TabKey[];
  defaultTab: TabKey;
  description?: string;
}

export const PERSONAS: Record<string, Persona> = {
  DATA_TEAMS: {
    id: 'data-teams',
    label: 'Data Teams (DE/MLE/DS)',
    icon: Code2,
    allowedTabs: ['forecast-intelligence', 'scale-operations'],
    defaultTab: 'forecast-intelligence',
    description: 'Engineering & ML Operations view'
  },
  DEMAND_PLANNING: {
    id: 'demand-planning',
    label: 'Demand Planning Teams',
    icon: LineChart,
    allowedTabs: ['forecast-intelligence', 'advanced-analytics'],
    defaultTab: 'advanced-analytics',
    description: 'Forecasting & analytics focus'
  },
  BUSINESS_LEADERSHIP: {
    id: 'business-leadership',
    label: 'Business & Leadership',
    icon: Building2,
    allowedTabs: ['business-impact'],
    defaultTab: 'business-impact',
    description: 'Executive metrics & ROI'
  }
};

export const DEFAULT_PERSONA = PERSONAS.DEMAND_PLANNING;

export const getPersonaById = (id: string): Persona | undefined => {
  return Object.values(PERSONAS).find(p => p.id === id);
};

export const getAllPersonas = (): Persona[] => {
  return Object.values(PERSONAS);
};