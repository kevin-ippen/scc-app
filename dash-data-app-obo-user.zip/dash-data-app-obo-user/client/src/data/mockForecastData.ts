// Mock forecast data for business-grade table views
// Hierarchy: Category → Brand → SKU

export interface ProductForecast {
  id: string;
  partner: string;
  category: string;
  brand: string;
  product: string;
  unitSales: number;
  forecastSHA: number; // Seasonal Historical Average
  forecastGAM: number; // GAM model
  forecastPartner: number; // Partner model
  accuracy: number; // Percentage
  stockRisk: 'low' | 'medium' | 'high';
}

export interface HierarchyNode {
  id: string;
  type: 'partner' | 'category' | 'brand' | 'sku';
  name: string;
  children?: HierarchyNode[];
  metrics: {
    unitSales: number;
    forecast: number;
    forecastSHA: number;
    forecastGAM: number;
    forecastPartner: number;
    accuracy: number;
    stockRisk: 'low' | 'medium' | 'high';
  };
}

export interface MonthlyForecast {
  id: string;
  partner: string;
  category: string;
  product: string;
  metric: 'SHA' | 'GAM' | 'Partner';
  monthlyValues: Record<string, number>;
}

// Generate monthly forecast values
const generateMonthlyValues = (baseValue: number, seasonality = 0.2): Record<string, number> => {
  const months = [
    '2023-01', '2023-02', '2023-03', '2023-04', '2023-05', '2023-06',
    '2023-07', '2023-08', '2023-09', '2023-10', '2023-11', '2023-12'
  ];

  const values: Record<string, number> = {};
  months.forEach((month, index) => {
    const seasonalFactor = Math.sin((index / 12) * Math.PI * 2) * seasonality;
    const randomVariation = (Math.random() - 0.5) * 0.1;
    values[month] = Math.round(
      baseValue * (1 + seasonalFactor + randomVariation)
    );
  });

  return values;
};

// Product Forecast Data (Summary Table)
export const mockProductForecasts: ProductForecast[] = [
  // Chocolate Category - Edible Gear Brand
  {
    id: 'chocolate-edible-gear-lip-rookies',
    partner: 'Partner A',
    category: 'Chocolate',
    brand: 'Edible Gear',
    product: 'Chocolate Lip Rookies',
    unitSales: 124060,
    forecastSHA: 150196,
    forecastGAM: 127349,
    forecastPartner: 127349,
    accuracy: 102.8,
    stockRisk: 'low'
  },
  // Beverages Category - CoolWav Brand
  {
    id: 'beverages-coolwav-sparkling-citrus',
    partner: 'Partner B',
    category: 'Beverages',
    brand: 'CoolWav',
    product: 'CoolWave Sparkling Citrus',
    unitSales: 98450,
    forecastSHA: 103373,
    forecastGAM: 116408,
    forecastPartner: 105120,
    accuracy: 105.0,
    stockRisk: 'low'
  },
  {
    id: 'beverages-coolwav-tropical-punch',
    partner: 'Partner C',
    category: 'Beverages',
    brand: 'CoolWav',
    product: 'CoolWave Tropical Punch',
    unitSales: 87230,
    forecastSHA: 89147,
    forecastGAM: 102387,
    forecastPartner: 93450,
    accuracy: 102.2,
    stockRisk: 'medium'
  },
  // Snacks Category - CrunchMates Brand
  {
    id: 'snacks-crunchmales-bbq-chips',
    partner: 'Partner A',
    category: 'Snacks',
    brand: 'CrunchMates',
    product: 'CrunchMates BBQ Chips',
    unitSales: 146328,
    forecastSHA: 145326,
    forecastGAM: 148921,
    forecastPartner: 149876,
    accuracy: 99.3,
    stockRisk: 'medium'
  },
  {
    id: 'snacks-crunchmales-salt-vinegar',
    partner: 'Partner B',
    category: 'Snacks',
    brand: 'CrunchMates',
    product: 'CrunchMates Salt & Vinegar',
    unitSales: 112450,
    forecastSHA: 108920,
    forecastGAM: 119283,
    forecastPartner: 115632,
    accuracy: 96.9,
    stockRisk: 'low'
  },
  // Sweets Category
  {
    id: 'sweets-candy-co-gummy-bears',
    partner: 'Partner C',
    category: 'Sweets',
    brand: 'Candy Co',
    product: 'Premium Gummy Bears',
    unitSales: 146328,
    forecastSHA: 144396,
    forecastGAM: 151847,
    forecastPartner: 148920,
    accuracy: 101.7,
    stockRisk: 'low'
  },
  {
    id: 'sweets-candy-co-sour-worms',
    partner: 'Partner A',
    category: 'Sweets',
    brand: 'Candy Co',
    product: 'Sour Worms',
    unitSales: 89234,
    forecastSHA: 86450,
    forecastGAM: 94120,
    forecastPartner: 91876,
    accuracy: 96.9,
    stockRisk: 'medium'
  },
  // Ice Cream Category
  {
    id: 'icecream-frozen-delights-vanilla',
    partner: 'Partner B',
    category: 'Ice Cream',
    brand: 'Frozen Delights',
    product: 'Premium Vanilla Bean',
    unitSales: 55201,
    forecastSHA: 92612,
    forecastGAM: 65363,
    forecastPartner: 52442,
    accuracy: 167.5,
    stockRisk: 'high'
  },
  {
    id: 'icecream-frozen-delights-chocolate',
    partner: 'Partner C',
    category: 'Ice Cream',
    brand: 'Frozen Delights',
    product: 'Double Chocolate',
    unitSales: 48920,
    forecastSHA: 81234,
    forecastGAM: 57621,
    forecastPartner: 46382,
    accuracy: 166.1,
    stockRisk: 'high'
  },
  // Additional products
  {
    id: 'chocolate-edible-gear-dark-chocolate',
    partner: 'Partner A',
    category: 'Chocolate',
    brand: 'Edible Gear',
    product: 'Dark Chocolate Bars',
    unitSales: 78450,
    forecastSHA: 82130,
    forecastGAM: 86920,
    forecastPartner: 81234,
    accuracy: 104.7,
    stockRisk: 'low'
  },
  {
    id: 'beverages-coolwav-lemon-lime',
    partner: 'Partner B',
    category: 'Beverages',
    brand: 'CoolWav',
    product: 'CoolWave Lemon Lime',
    unitSales: 65234,
    forecastSHA: 68920,
    forecastGAM: 72341,
    forecastPartner: 67890,
    accuracy: 105.6,
    stockRisk: 'low'
  }
];

// Hierarchy Data (for HierarchyExplorer)
export const mockHierarchy: HierarchyNode[] = [
  {
    id: 'partner-a',
    type: 'partner',
    name: 'Partner A',
    metrics: {
      unitSales: 496896,
      forecast: 603042,
      forecastSHA: 601041,
      forecastGAM: 630613,
      forecastPartner: 616094,
      accuracy: 121.1,
      stockRisk: 'low'
    },
    children: [
      {
        id: 'category-chocolate',
        type: 'category',
        name: 'Chocolate',
        metrics: {
          unitSales: 124060,
          forecastSHA: 150196,
          forecastGAM: 127349,
          forecastPartner: 127349,
          accuracy: 121.8,
          stockRisk: 'low'
        },
        children: [
          {
            id: 'brand-edible-gear',
            type: 'brand',
            name: 'Edible Gear',
            metrics: {
              unitSales: 124060,
              forecastSHA: 150196,
              forecastGAM: 127349,
              forecastPartner: 127349,
              accuracy: 121.8,
              stockRisk: 'low'
            },
            children: [
              {
                id: 'sku-chocolate-lip-rookies',
                type: 'sku',
                name: 'Chocolate Lip Rookies',
                metrics: {
                  unitSales: 124060,
                  forecastSHA: 150196,
                  forecastGAM: 127349,
                  forecastPartner: 127349,
                  accuracy: 121.8,
                  stockRisk: 'low'
                }
              }
            ]
          }
        ]
      },
      {
        id: 'category-beverages',
        type: 'category',
        name: 'Beverages',
        metrics: {
          unitSales: 185680,
          forecastSHA: 192520,
          forecastGAM: 218795,
          forecastPartner: 198570,
          accuracy: 103.7,
          stockRisk: 'low'
        },
        children: [
          {
            id: 'brand-coolwav',
            type: 'brand',
            name: 'CoolWav',
            metrics: {
              unitSales: 185680,
              forecastSHA: 192520,
              forecastGAM: 218795,
              forecastPartner: 198570,
              accuracy: 103.7,
              stockRisk: 'low'
            },
            children: [
              {
                id: 'sku-sparkling-citrus',
                type: 'sku',
                name: 'CoolWave Sparkling Citrus',
                metrics: {
                  unitSales: 98450,
                  forecastSHA: 103373,
                  forecastGAM: 116408,
                  forecastPartner: 105120,
                  accuracy: 105.0,
                  stockRisk: 'low'
                }
              },
              {
                id: 'sku-tropical-punch',
                type: 'sku',
                name: 'CoolWave Tropical Punch',
                metrics: {
                  unitSales: 87230,
                  forecastSHA: 89147,
                  forecastGAM: 102387,
                  forecastPartner: 93450,
                  accuracy: 102.2,
                  stockRisk: 'medium'
                }
              }
            ]
          }
        ]
      },
      {
        id: 'category-snacks',
        type: 'category',
        name: 'Snacks',
        metrics: {
          unitSales: 258778,
          forecastSHA: 254246,
          forecastGAM: 268204,
          forecastPartner: 265508,
          accuracy: 98.3,
          stockRisk: 'medium'
        },
        children: [
          {
            id: 'brand-crunchmates',
            type: 'brand',
            name: 'CrunchMates',
            metrics: {
              unitSales: 258778,
              forecastSHA: 254246,
              forecastGAM: 268204,
              forecastPartner: 265508,
              accuracy: 98.3,
              stockRisk: 'medium'
            },
            children: [
              {
                id: 'sku-bbq-chips',
                type: 'sku',
                name: 'CrunchMates BBQ Chips',
                metrics: {
                  unitSales: 146328,
                  forecastSHA: 145326,
                  forecastGAM: 148921,
                  forecastPartner: 149876,
                  accuracy: 99.3,
                  stockRisk: 'medium'
                }
              },
              {
                id: 'sku-salt-vinegar',
                type: 'sku',
                name: 'CrunchMates Salt & Vinegar',
                metrics: {
                  unitSales: 112450,
                  forecastSHA: 108920,
                  forecastGAM: 119283,
                  forecastPartner: 115632,
                  accuracy: 96.9,
                  stockRisk: 'low'
                }
              }
            ]
          }
        ]
      },
      {
        id: 'category-sweets',
        type: 'category',
        name: 'Sweets',
        metrics: {
          unitSales: 235562,
          forecastSHA: 230846,
          forecastGAM: 245967,
          forecastPartner: 240796,
          accuracy: 99.3,
          stockRisk: 'low'
        },
        children: [
          {
            id: 'brand-candy-co',
            type: 'brand',
            name: 'Candy Co',
            metrics: {
              unitSales: 235562,
              forecastSHA: 230846,
              forecastGAM: 245967,
              forecastPartner: 240796,
              accuracy: 99.3,
              stockRisk: 'low'
            },
            children: [
              {
                id: 'sku-gummy-bears',
                type: 'sku',
                name: 'Premium Gummy Bears',
                metrics: {
                  unitSales: 146328,
                  forecastSHA: 144396,
                  forecastGAM: 151847,
                  forecastPartner: 148920,
                  accuracy: 101.7,
                  stockRisk: 'low'
                }
              },
              {
                id: 'sku-sour-worms',
                type: 'sku',
                name: 'Sour Worms',
                metrics: {
                  unitSales: 89234,
                  forecastSHA: 86450,
                  forecastGAM: 94120,
                  forecastPartner: 91876,
                  accuracy: 96.9,
                  stockRisk: 'medium'
                }
              }
            ]
          }
        ]
      },
      {
        id: 'category-icecream',
        type: 'category',
        name: 'Ice Cream',
        metrics: {
          unitSales: 104121,
          forecastSHA: 173846,
          forecastGAM: 122984,
          forecastPartner: 98824,
          accuracy: 166.9,
          stockRisk: 'high'
        },
        children: [
          {
            id: 'brand-frozen-delights',
            type: 'brand',
            name: 'Frozen Delights',
            metrics: {
              unitSales: 104121,
              forecastSHA: 173846,
              forecastGAM: 122984,
              forecastPartner: 98824,
              accuracy: 166.9,
              stockRisk: 'high'
            },
            children: [
              {
                id: 'sku-vanilla-bean',
                type: 'sku',
                name: 'Premium Vanilla Bean',
                metrics: {
                  unitSales: 55201,
                  forecastSHA: 92612,
                  forecastGAM: 65363,
                  forecastPartner: 52442,
                  accuracy: 167.5,
                  stockRisk: 'high'
                }
              },
              {
                id: 'sku-double-chocolate',
                type: 'sku',
                name: 'Double Chocolate',
                metrics: {
                  unitSales: 48920,
                  forecastSHA: 81234,
                  forecastGAM: 57621,
                  forecastPartner: 46382,
                  accuracy: 166.1,
                  stockRisk: 'high'
                }
              }
            ]
          }
        ]
      }
    ]
  }
];

// Monthly Forecast Data
export const mockMonthlyForecasts: MonthlyForecast[] = [
  {
    id: 'chocolate-lip-rookies-sha',
    partner: 'Partner A',
    category: 'Chocolate',
    product: 'Chocolate Lip Rookies',
    metric: 'SHA',
    monthlyValues: generateMonthlyValues(7579, 0.15)
  },
  {
    id: 'chocolate-lip-rookies-gam',
    partner: 'Partner A',
    category: 'Chocolate',
    product: 'Chocolate Lip Rookies',
    metric: 'GAM',
    monthlyValues: generateMonthlyValues(1167, 0.2)
  },
  {
    id: 'chocolate-lip-rookies-partner',
    partner: 'Partner A',
    category: 'Chocolate',
    product: 'Chocolate Lip Rookies',
    metric: 'Partner',
    monthlyValues: generateMonthlyValues(10216, 0.1)
  },
  {
    id: 'coolwave-citrus-sha',
    partner: 'Partner A',
    category: 'Beverages',
    product: 'CoolWave Sparkling Citrus',
    metric: 'SHA',
    monthlyValues: generateMonthlyValues(8620, 0.25)
  },
  {
    id: 'coolwave-citrus-gam',
    partner: 'Partner A',
    category: 'Beverages',
    product: 'CoolWave Sparkling Citrus',
    metric: 'GAM',
    monthlyValues: generateMonthlyValues(9705, 0.2)
  },
  {
    id: 'coolwave-citrus-partner',
    partner: 'Partner A',
    category: 'Beverages',
    product: 'CoolWave Sparkling Citrus',
    metric: 'Partner',
    monthlyValues: generateMonthlyValues(8760, 0.15)
  }
];

// Helper functions
export const getProductsByCategory = (category: string): ProductForecast[] => {
  return mockProductForecasts.filter(p => p.category === category);
};

export const getProductsByPartner = (partner: string): ProductForecast[] => {
  return mockProductForecasts.filter(p => p.partner === partner);
};

export const getCategoryMetrics = (category: string) => {
  const products = getProductsByCategory(category);
  const totalSales = products.reduce((sum, p) => sum + p.unitSales, 0);
  const avgAccuracy = products.reduce((sum, p) => sum + p.accuracy, 0) / products.length;

  return {
    totalSales,
    avgAccuracy,
    productCount: products.length
  };
};
